package net.blue.chaoticd.item;

import net.blue.chaoticd.ChaoticDimensions;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroup {

    //Chaotic Dimensions Ores ItemGroup
    public static final class_1761 CHAOTIC_ORES = class_2378.method_10230(class_7923.field_44687,
            new class_2960(ChaoticDimensions.MOD_ID, "shadow_gem1"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("chaoticd_ores"))
                    .method_47320(() -> new class_1799(ModItems.SHADOW_GEM)).method_47317((displayContext, entries) -> {

                        entries.method_45421(ModItems.RUBY);
                        entries.method_45421(ModItems.ALUMINIUM_INGOT);
                        entries.method_45421(ModItems.TITANIUM_INGOT);
                        entries.method_45421(ModItems.ROSALITA_GEM);
                        entries.method_45421(ModItems.CHLOROPHYTE_INGOT);
                        entries.method_45421(ModItems.LAVA_INGOT);
                        entries.method_45421(ModItems.WATER_INGOT);
                        entries.method_45421(ModItems.SHADOW_GEM);
                        entries.method_45421(ModItems.SHADOW_NUGGET);
                        entries.method_45421(ModItems.ENTERALDA);
                        entries.method_45421(ModItems.DERMAN_GEM);
                        entries.method_45421(ModItems.SUN_TEAR);
                        entries.method_45421(ModItems.VYLAM_GEM);
                        entries.method_45421(ModItems.VORTEX_GEM);
                        entries.method_45421(ModItems.HERO_GEM);

                    }).method_47324());

    //Utility Chaotic Items Group
    public static final class_1761 CHAOTIC_ITEMS = class_2378.method_10230(class_7923.field_44687,
            new class_2960(ChaoticDimensions.MOD_ID, "shadow_gem2"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("chaoticd_items"))
                    .method_47320(() -> new class_1799(ModItems.DIMENSION_APPLE)).method_47317((displayContext, entries) -> {

                        entries.method_45421(ModItems.GOLD_SPECIAL_APPLE);
                        entries.method_45421(ModItems.DIMENSION_APPLE);
                        entries.method_45421(ModItems.BEDROCK_STICK);

                    }).method_47324());

    //Chaotic Dimensions Armors Group
    public static final class_1761 CHAOTIC_ARMORS = class_2378.method_10230(class_7923.field_44687,
            new class_2960(ChaoticDimensions.MOD_ID, "hero_gem"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("chaoticd_armors"))
                    .method_47320(() -> new class_1799(ModItems.RUBY)).method_47317((displayContext, entries) -> {



                    }).method_47324());

    public static void registerItemGroups() {
        ChaoticDimensions.LOGGER.info("Registering Item Groups for " + ChaoticDimensions.MOD_ID);
    }

}
