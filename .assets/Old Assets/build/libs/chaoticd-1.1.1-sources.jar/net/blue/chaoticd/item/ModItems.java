package net.blue.chaoticd.item;

import net.blue.chaoticd.ChaoticDimensions;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModItems {

    //All ChaoticDimensions items
    public static final class_1792 ROSALITA_GEM =registerItem("rosalita_gem", new class_1792(new FabricItemSettings()));
    public static final class_1792 ALUMINIUM_INGOT =registerItem("aluminium_ingot", new class_1792(new FabricItemSettings()));
    public static final class_1792 CHLOROPHYTE_INGOT =registerItem("chlorophyte_ingot", new class_1792(new FabricItemSettings()));
    public static final class_1792 HERO_GEM =registerItem("hero_gem", new class_1792(new FabricItemSettings()));
    public static final class_1792 RUBY =registerItem("ruby", new class_1792(new FabricItemSettings()));
    public static final class_1792 LAVA_INGOT =registerItem("lava_ingot", new class_1792(new FabricItemSettings()));
    public static final class_1792 WATER_INGOT =registerItem("water_ingot", new class_1792(new FabricItemSettings()));
    public static final class_1792 SHADOW_GEM =registerItem("shadow_gem", new class_1792(new FabricItemSettings()));
    public static final class_1792 SHADOW_NUGGET =registerItem("shadow_nugget", new class_1792(new FabricItemSettings()));
    public static final class_1792 SUN_TEAR =registerItem("sun_tear", new class_1792(new FabricItemSettings()));
    public static final class_1792 TITANIUM_INGOT =registerItem("titanium_ingot", new class_1792(new FabricItemSettings()));
    public static final class_1792 VORTEX_GEM =registerItem("vortex_gem", new class_1792(new FabricItemSettings()));
    public static final class_1792 VYLAM_GEM =registerItem("vylam_gem", new class_1792(new FabricItemSettings()));
    public static final class_1792 GOLD_SPECIAL_APPLE =registerItem("gold_especial_apple", new class_1792(new FabricItemSettings()));
    public static final class_1792 ENTERALDA =registerItem("enteralda", new class_1792(new FabricItemSettings()));
    public static final class_1792 DIMENSION_APPLE =registerItem("dimension_apple", new class_1792(new FabricItemSettings()));
    public static final class_1792 DERMAN_GEM =registerItem("derman_gem", new class_1792(new FabricItemSettings()));
    public static final class_1792 BEDROCK_STICK =registerItem("bedrock_stick", new class_1792(new FabricItemSettings()));

    //Ruby Items

    //Emerald Items

    //Chlorophyte Items

    //Titanium Items

    //Aluminium Items

    //Lava Items

    //Shadow Items

    //Hero Items

    //Vylam Items

    //Vortex Items

    //Derman Items

    //Water Items

    //Rosalita Items


    //Registering Items in ItemGroups vanilla
    private static void addItemsToIngredientItemGroup(FabricItemGroupEntries entries) {
        ;
    }

    //---------------------------------------------------------------------------------------------------------------//

    //RegistersItems and RegisterGroups
    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(ChaoticDimensions.MOD_ID, name), item);
    }
    public static void registerModItems() {
        ChaoticDimensions.LOGGER.info("Registering Mod Items for " + ChaoticDimensions.MOD_ID);
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register(ModItems::addItemsToIngredientItemGroup);
    }
}
