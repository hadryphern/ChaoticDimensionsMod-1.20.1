package net.blue.chaoticd;

import net.blue.chaoticd.item.ModItemGroup;
import net.blue.chaoticd.item.ModItems;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChaoticDimensions implements ModInitializer {
	public static final String MOD_ID = "chaoticd";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {

		ModItems.registerModItems();
		ModItemGroup.registerItemGroups();


	}
}