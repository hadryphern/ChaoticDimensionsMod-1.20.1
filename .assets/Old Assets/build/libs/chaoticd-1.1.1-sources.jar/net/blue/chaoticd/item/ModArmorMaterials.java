package net.blue.chaoticd.item;

import net.blue.chaoticd.ChaoticDimensions;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import java.util.function.Supplier;

public enum ModArmorMaterials implements class_1741 {
    ;

    private final String name;
    private final int durabilityMultiplier;
    private final int[] protectionAmounts;
    private final int enchantability;
    private final class_3414 equipSound;
    private final float toughness;
    private final float knockbackResistence;
    private final Supplier<class_1856> repairIngredient;

    private static final int[] BASE_DURABILITY = { 11, 16, 15, 13 };

    ModArmorMaterials(String name, int durabilityMultiplier, int[] protectionAmounts, int enchantability, class_3414 equipSound,
                      float toughness, float knockbackResistence, Supplier<class_1856> repairIngredient) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.protectionAmounts = protectionAmounts;
        this.enchantability = enchantability;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistence = knockbackResistence;
        this.repairIngredient = repairIngredient;
    }


    @Override
    public int method_48402(class_1738.class_8051 type) {
        return BASE_DURABILITY[type.ordinal()] * this.durabilityMultiplier;
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        return protectionAmounts[type.ordinal()];
    }

    @Override
    public int method_7699() {
        return this.enchantability;
    }

    @Override
    public class_3414 method_7698() {
        return this.equipSound;
    }

    @Override
    public class_1856 method_7695() {
        return this.repairIngredient.get();
    }

    @Override
    public String method_7694() {
        return ChaoticDimensions.MOD_ID + ":" + this.name;
    }

    @Override
    public float method_7700() {
        return this.toughness;
    }

    @Override
    public float method_24355() {
        return this.knockbackResistence;
    }
}
