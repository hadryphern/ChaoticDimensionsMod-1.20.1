package net.blue.chaoticd.block;

import net.blue.chaoticd.ChaoticDimensions;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlocks {




























    //------------------------------------------------------------------------------------------------------------------

    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, new class_2960(ChaoticDimensions.MOD_ID, name ), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(ChaoticDimensions.MOD_ID, name),
                new class_1747(block, new FabricItemSettings()));
    }

    public static void registerModBlocks() {
        ChaoticDimensions.LOGGER.info("Registering ModBlocks for " + ChaoticDimensions.MOD_ID);
    }

}
