package net.blue.chaoticd.datagen;

import net.blue.chaoticd.item.ModItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {

    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

        itemModelGenerator.method_25733(ModItems.ALUMINIUM_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.TITANIUM_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.BEDROCK_STICK, class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.SHADOW_GEM, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.SHADOW_NUGGET, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.SUN_TEAR, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.ROSALITA_GEM, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DERMAN_GEM, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.ENTERALDA, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CHLOROPHYTE_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.HERO_GEM, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RUBY, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.LAVA_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.WATER_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.VORTEX_GEM, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.VYLAM_GEM, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.GOLD_SPECIAL_APPLE, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DIMENSION_APPLE, class_4943.field_22938);

    }
}
