package software.bernie.geckolib.network;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public abstract class AbstractPacket {

    public abstract PacketByteBuf encode();

    public abstract Identifier getPacketID();
}
