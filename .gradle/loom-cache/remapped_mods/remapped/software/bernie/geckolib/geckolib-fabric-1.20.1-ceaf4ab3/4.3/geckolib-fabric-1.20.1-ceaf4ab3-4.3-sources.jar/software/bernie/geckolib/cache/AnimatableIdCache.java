package software.bernie.geckolib.cache;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;
import software.bernie.geckolib.core.animatable.instance.SingletonAnimatableInstanceCache;

/**
 * Storage class that keeps track of the last animatable id used, and provides new ones on request.<br>
 * Generally only used for {@link net.minecraft.item.Item Items}, but any
 * {@link SingletonAnimatableInstanceCache singleton} will likely use this.
 */
public final class AnimatableIdCache extends PersistentState {
	private static final String DATA_KEY = "geckolib_id_cache";
	private long lastId;

	private AnimatableIdCache() {
		this(new NbtCompound());
	}

	private AnimatableIdCache(NbtCompound tag) {
		this.lastId = tag.getLong("last_id");
	}

	/**
	 * Get the next free id from the id cache
	 * @param level An arbitrary ServerLevel. It doesn't matter which one
	 * @return The next free ID, which is immediately reserved for use after calling this method
	 */
	public static long getFreeId(ServerWorld level) {
		return getCache(level).getNextId();
	}

	private long getNextId() {
		markDirty();

		return ++this.lastId;
	}

	@Override
	public NbtCompound writeNbt(NbtCompound tag) {
		tag.putLong("last_id", this.lastId);

		return tag;
	}

	private static AnimatableIdCache getCache(ServerWorld level) {
		PersistentStateManager storage = level.getServer().getOverworld().getPersistentStateManager();
		AnimatableIdCache cache = storage.getOrCreate(AnimatableIdCache::new, AnimatableIdCache::new, DATA_KEY);

		if (cache.lastId == 0) {
			AnimatableIdCache legacyCache = storage.get(AnimatableIdCache::fromLegacy, "geckolib_ids");

			if (legacyCache != null)
				cache.lastId = legacyCache.lastId;
		}

		return cache;
	}

	/**
	 * Legacy wrapper for existing worlds pre-4.0.<br>
	 * Remove this at some point in the future
	 */
	private static AnimatableIdCache fromLegacy(NbtCompound tag) {
		AnimatableIdCache legacyCache = new AnimatableIdCache();

		for (String key : tag.getKeys()) {
			if (tag.contains(key, NbtElement.NUMBER_TYPE))
				legacyCache.lastId = Math.max(legacyCache.lastId, tag.getInt(key));
		}

		return legacyCache;
	}
}
