package net.blue.chaoticd.worldgen.water;

import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.List;
import net.blue.chaoticd.content.ModBlocks;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3486;
import net.minecraft.class_3612;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

/** Generates contained lakes, tiny pond islands and edge waterfalls in the Aurora Dimension. */
public final class AuroraWaterFeature extends class_3031<AuroraWaterConfiguration> {
    private static final int WORLDGEN_FLAGS = 19;
    private static final double POND_RADIUS_RATIO = 0.72D;

    public AuroraWaterFeature(Codec<AuroraWaterConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<AuroraWaterConfiguration> context) {
        return switch (context.method_33656().mode()) {
            case SURFACE_LAKE -> placeSurfaceLake(context);
            case POND_ISLAND -> placePondIsland(context);
            case WATERFALL -> placeWaterfall(context);
        };
    }

    private static boolean placeSurfaceLake(
        class_5821<AuroraWaterConfiguration> context
    ) {
        class_5281 level = context.method_33652();
        class_5819 random = context.method_33654();
        AuroraWaterConfiguration config = context.method_33656();

        class_2338 surfaceAir = surfaceAir(
            level,
            context.method_33655().method_10263(),
            context.method_33655().method_10260()
        );

        if (surfaceAir == null
            || !isAuroraTerrain(level.method_8320(surfaceAir.method_10074()))) {
            return false;
        }

        int radiusX = between(
            random,
            config.minRadius(),
            config.maxRadius()
        );

        int radiusZ = Math.max(
            config.minRadius(),
            radiusX - random.method_43048(3)
        );

        int maximumDepth = between(
            random,
            config.minDepth(),
            config.maxDepth()
        );

        int waterY = surfaceAir.method_10264() - 1;

        if (!canCarveLake(
            level,
            surfaceAir,
            radiusX,
            radiusZ,
            maximumDepth
        )) {
            return false;
        }

        for (int dx = -radiusX; dx <= radiusX; dx++) {
            for (int dz = -radiusZ; dz <= radiusZ; dz++) {
                double distance = normalizedDistance(
                    dx,
                    dz,
                    radiusX,
                    radiusZ
                );

                int x = surfaceAir.method_10263() + dx;
                int z = surfaceAir.method_10260() + dz;

                if (distance <= 0.76D) {
                    double centerFactor =
                        1.0D - distance / 0.76D;

                    int localDepth =
                        config.minDepth()
                            + (int) Math.round(
                                centerFactor
                                    * (maximumDepth - config.minDepth())
                            );

                    localDepth = Math.max(1, localDepth);
                    int floorY = waterY - localDepth;

                    setBlock(
                        level,
                        new class_2338(x, floorY, z),
                        ModBlocks.PASTEL_AURORA_STONE.method_9564()
                    );

                    setBlock(
                        level,
                        new class_2338(x, floorY - 1, z),
                        ModBlocks.PASTEL_AURORA_STONE.method_9564()
                    );

                    for (int y = floorY + 1; y <= waterY; y++) {
                        setWater(
                            level,
                            new class_2338(x, y, z),
                            false
                        );
                    }

                    maybePlaceSeagrass(
                        level,
                        random,
                        new class_2338(x, floorY, z),
                        waterY
                    );

                    for (int y = waterY + 1; y <= waterY + 2; y++) {
                        class_2338 clear = new class_2338(x, y, z);

                        if (!level.method_8320(clear).method_26215()) {
                            setBlock(
                                level,
                                clear,
                                class_2246.field_10124.method_9564()
                            );
                        }
                    }
                } else if (distance <= 1.0D) {
                    class_2338 rim = new class_2338(x, waterY, z);

                    setBlock(
                        level,
                        rim,
                        ModBlocks.PASTEL_GRASS.method_9564()
                    );

                    setBlock(
                        level,
                        rim.method_10074(),
                        ModBlocks.PASTEL_SOIL.method_9564()
                    );
                }
            }
        }

        addLilyPads(
            level,
            random,
            surfaceAir,
            radiusX,
            radiusZ,
            waterY
        );

        return true;
    }

    private static boolean canCarveLake(
        class_5281 level,
        class_2338 center,
        int radiusX,
        int radiusZ,
        int maximumDepth
    ) {
        int centerGroundY = center.method_10264() - 1;

        for (int dx = -radiusX - 1; dx <= radiusX + 1; dx++) {
            for (int dz = -radiusZ - 1; dz <= radiusZ + 1; dz++) {
                double distance = normalizedDistance(
                    dx,
                    dz,
                    radiusX + 1,
                    radiusZ + 1
                );

                if (distance > 1.0D) {
                    continue;
                }

                int x = center.method_10263() + dx;
                int z = center.method_10260() + dz;

                int localGroundY =
                    level.method_8624(
                        class_2902.class_2903.field_13194,
                        x,
                        z
                    ) - 1;

                if (Math.abs(localGroundY - centerGroundY) > 2) {
                    return false;
                }

                for (
                    int y = centerGroundY - maximumDepth - 2;
                    y <= centerGroundY + 2;
                    y++
                ) {
                    class_2338 pos = new class_2338(x, y, z);

                    if (!level.method_37368(pos)) {
                        return false;
                    }
                }

                if (distance <= 0.80D) {
                    class_2680 deepSupport = level.method_8320(
                        new class_2338(
                            x,
                            centerGroundY - maximumDepth - 2,
                            z
                        )
                    );

                    if (!isAuroraTerrain(deepSupport)) {
                        return false;
                    }

                    for (
                        int y = centerGroundY - maximumDepth;
                        y <= centerGroundY + 1;
                        y++
                    ) {
                        if (!level.method_8316(
                            new class_2338(x, y, z)
                        ).method_15769()) {
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    }

    private static boolean placePondIsland(
        class_5821<AuroraWaterConfiguration> context
    ) {
        class_5281 level = context.method_33652();
        class_5819 random = context.method_33654();
        AuroraWaterConfiguration config = context.method_33656();
        class_2338 center = context.method_33655();

        int radiusX = between(
            random,
            config.minRadius(),
            config.maxRadius()
        );

        int radiusZ = Math.max(
            config.minRadius(),
            radiusX - random.method_43048(3)
        );

        int maximumDepth = between(
            random,
            config.minDepth(),
            config.maxDepth()
        );

        if (!isClearForPondIsland(
            level,
            center,
            radiusX,
            radiusZ,
            maximumDepth
        )) {
            return false;
        }

        int waterY = center.method_10264();

        for (int dx = -radiusX; dx <= radiusX; dx++) {
            for (int dz = -radiusZ; dz <= radiusZ; dz++) {
                double distance = normalizedDistance(
                    dx,
                    dz,
                    radiusX,
                    radiusZ
                );

                if (distance > 1.0D) {
                    continue;
                }

                int x = center.method_10263() + dx;
                int z = center.method_10260() + dz;

                int undersideDepth =
                    2 + (int) Math.round(
                        (1.0D - distance) * (maximumDepth + 2)
                    );

                int bottomY = waterY - undersideDepth;
                boolean pond = distance <= POND_RADIUS_RATIO;

                if (pond) {
                    double pondFactor =
                        1.0D - distance / POND_RADIUS_RATIO;

                    int pondDepth =
                        config.minDepth()
                            + (int) Math.round(
                                pondFactor
                                    * (maximumDepth - config.minDepth())
                            );

                    pondDepth = Math.max(1, pondDepth);
                    int floorY = waterY - pondDepth;

                    for (int y = bottomY; y <= floorY; y++) {
                        setBlock(
                            level,
                            new class_2338(x, y, z),
                            ModBlocks.PASTEL_AURORA_STONE
                                .method_9564()
                        );
                    }

                    for (int y = floorY + 1; y <= waterY; y++) {
                        setWater(
                            level,
                            new class_2338(x, y, z),
                            false
                        );
                    }

                    maybePlaceSeagrass(
                        level,
                        random,
                        new class_2338(x, floorY, z),
                        waterY
                    );
                } else {
                    for (
                        int y = bottomY;
                        y < waterY - 1;
                        y++
                    ) {
                        setBlock(
                            level,
                            new class_2338(x, y, z),
                            ModBlocks.PASTEL_AURORA_STONE
                                .method_9564()
                        );
                    }

                    setBlock(
                        level,
                        new class_2338(x, waterY - 1, z),
                        ModBlocks.PASTEL_SOIL.method_9564()
                    );

                    setBlock(
                        level,
                        new class_2338(x, waterY, z),
                        ModBlocks.PASTEL_GRASS.method_9564()
                    );
                }
            }
        }

        addLilyPads(
            level,
            random,
            center.method_10084(),
            radiusX,
            radiusZ,
            waterY
        );

        return true;
    }

    private static boolean isClearForPondIsland(
        class_5281 level,
        class_2338 center,
        int radiusX,
        int radiusZ,
        int maximumDepth
    ) {
        for (int dx = -radiusX - 2; dx <= radiusX + 2; dx++) {
            for (int dz = -radiusZ - 2; dz <= radiusZ + 2; dz++) {
                double distance = normalizedDistance(
                    dx,
                    dz,
                    radiusX + 2,
                    radiusZ + 2
                );

                if (distance > 1.0D) {
                    continue;
                }

                for (
                    int y = center.method_10264() - maximumDepth - 5;
                    y <= center.method_10264() + 3;
                    y++
                ) {
                    class_2338 pos = new class_2338(
                        center.method_10263() + dx,
                        y,
                        center.method_10260() + dz
                    );

                    if (!level.method_37368(pos)
                        || !level.method_8320(pos).method_26215()) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    private static boolean placeWaterfall(
        class_5821<AuroraWaterConfiguration> context
    ) {
        class_5281 level = context.method_33652();
        class_5819 random = context.method_33654();
        AuroraWaterConfiguration config = context.method_33656();

        List<WaterfallCandidate> candidates = new ArrayList<>();

        int searchRadius = config.maxRadius();

        int requiredDrop = between(
            random,
            config.minDepth(),
            config.maxDepth()
        );

        for (int dx = -searchRadius; dx <= searchRadius; dx++) {
            for (int dz = -searchRadius; dz <= searchRadius; dz++) {
                int x = context.method_33655().method_10263() + dx;
                int z = context.method_33655().method_10260() + dz;

                class_2338 surfaceAir = surfaceAir(level, x, z);

                if (surfaceAir == null
                    || !level.method_8316(surfaceAir).method_15769()) {
                    continue;
                }

                class_2338 basin = surfaceAir.method_10074();

                if (!isAuroraTerrain(level.method_8320(basin))) {
                    continue;
                }

                for (class_2350 direction : class_2350.class_2353.field_11062) {
                    class_2338 outflow = basin.method_10093(direction);

                    if (hasOpenDrop(
                        level,
                        outflow,
                        requiredDrop
                    ) && hasSolidWaterfallBanks(
                        level,
                        basin,
                        direction
                    )) {
                        candidates.add(
                            new WaterfallCandidate(
                                basin,
                                direction
                            )
                        );
                    }
                }
            }
        }

        if (candidates.isEmpty()) {
            return false;
        }

        WaterfallCandidate candidate =
            candidates.get(random.method_43048(candidates.size()));

        class_2338 optionalWideSource = null;

        class_2350 tangent =
            candidate.direction().method_10166() == class_2350.class_2351.field_11048
                ? class_2350.field_11043
                : class_2350.field_11034;

        if (random.method_43057() < 0.35F) {
            class_2350 side = random.method_43056()
                ? tangent
                : tangent.method_10153();

            class_2338 wideSource =
                candidate.source().method_10093(side);

            if (isAuroraTerrain(level.method_8320(wideSource))
                && level.method_8320(wideSource.method_10084()).method_26215()
                && hasOpenDrop(
                    level,
                    wideSource.method_10093(candidate.direction()),
                    requiredDrop
                )
                && hasSolidWaterfallBanks(
                    level,
                    wideSource,
                    candidate.direction()
                )) {
                optionalWideSource = wideSource;
            }
        }

        setWater(
            level,
            candidate.source(),
            true
        );

        if (optionalWideSource != null) {
            setWater(
                level,
                optionalWideSource,
                true
            );
        }

        return true;
    }

    private static boolean hasSolidWaterfallBanks(
        class_5281 level,
        class_2338 source,
        class_2350 outflowDirection
    ) {
        class_2350 tangent =
            outflowDirection.method_10166() == class_2350.class_2351.field_11048
                ? class_2350.field_11043
                : class_2350.field_11034;

        return isAuroraTerrain(
            level.method_8320(
                source.method_10093(outflowDirection.method_10153())
            )
        )
            && isAuroraTerrain(
                level.method_8320(source.method_10093(tangent))
            )
            && isAuroraTerrain(
                level.method_8320(
                    source.method_10093(tangent.method_10153())
                )
            )
            && level.method_8320(source.method_10084()).method_26215();
    }

    private static boolean hasOpenDrop(
        class_5281 level,
        class_2338 outside,
        int minimumDrop
    ) {
        for (int depth = 0; depth <= minimumDrop; depth++) {
            class_2338 pos = outside.method_10087(depth);

            if (!level.method_37368(pos)
                || !level.method_8320(pos).method_26215()) {
                return false;
            }
        }

        return true;
    }

    private static void maybePlaceSeagrass(
        class_5281 level,
        class_5819 random,
        class_2338 floor,
        int waterY
    ) {
        class_2338 plant = floor.method_10084();

        if (waterY - floor.method_10264() >= 2
            && random.method_43057() < 0.10F
            && level.method_8320(plant).method_27852(class_2246.field_10382)
            && level.method_8316(plant).method_15771()) {
            setBlock(
                level,
                plant,
                class_2246.field_10376.method_9564()
            );
        }
    }

    private static void addLilyPads(
        class_5281 level,
        class_5819 random,
        class_2338 center,
        int radiusX,
        int radiusZ,
        int waterY
    ) {
        int attempts = Math.max(
            2,
            (radiusX + radiusZ) / 2
        );

        for (int attempt = 0; attempt < attempts; attempt++) {
            int dx =
                random.method_43048(radiusX * 2 + 1) - radiusX;

            int dz =
                random.method_43048(radiusZ * 2 + 1) - radiusZ;

            if (normalizedDistance(
                dx,
                dz,
                radiusX,
                radiusZ
            ) > 0.50D) {
                continue;
            }

            class_2338 water = new class_2338(
                center.method_10263() + dx,
                waterY,
                center.method_10260() + dz
            );

            class_2338 pad = water.method_10084();

            if (level.method_8316(water).method_15767(class_3486.field_15517)
                && level.method_8316(water).method_15771()
                && level.method_8320(pad).method_26215()
                && level.method_37368(pad)) {
                setBlock(
                    level,
                    pad,
                    class_2246.field_10588.method_9564()
                );
            }
        }
    }

    private static class_2338 surfaceAir(
        class_5281 level,
        int x,
        int z
    ) {
        int y = level.method_8624(
            class_2902.class_2903.field_13194,
            x,
            z
        );

        if (y <= level.method_31607() + 2
            || y >= level.method_31600() - 2) {
            return null;
        }

        return new class_2338(x, y, z);
    }

    private static boolean isAuroraTerrain(class_2680 state) {
        return state.method_27852(ModBlocks.PASTEL_GRASS)
            || state.method_27852(ModBlocks.PASTEL_SOIL)
            || state.method_27852(ModBlocks.PASTEL_AURORA_STONE);
    }

    private static void setWater(
        class_5281 level,
        class_2338 pos,
        boolean scheduleFlow
    ) {
        setBlock(
            level,
            pos,
            class_2246.field_10382.method_9564()
        );

        if (scheduleFlow) {
            level.method_39281(
                pos,
                class_3612.field_15910,
                1
            );
        }
    }

    private static void setBlock(
        class_5281 level,
        class_2338 pos,
        class_2680 state
    ) {
        level.method_8652(
            pos,
            state,
            WORLDGEN_FLAGS
        );
    }

    private static int between(
        class_5819 random,
        int minimum,
        int maximum
    ) {
        return minimum
            + random.method_43048(maximum - minimum + 1);
    }

    private static double normalizedDistance(
        int dx,
        int dz,
        int radiusX,
        int radiusZ
    ) {
        double normalizedX =
            dx / (double) Math.max(1, radiusX);

        double normalizedZ =
            dz / (double) Math.max(1, radiusZ);

        return Math.sqrt(
            normalizedX * normalizedX
                + normalizedZ * normalizedZ
        );
    }

    private record WaterfallCandidate(
        class_2338 source,
        class_2350 direction
    ) {
    }
}