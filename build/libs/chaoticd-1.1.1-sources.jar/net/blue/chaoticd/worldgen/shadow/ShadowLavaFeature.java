package net.blue.chaoticd.worldgen.shadow;

import com.mojang.serialization.Codec;
import net.blue.chaoticd.content.ModBlocks;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3612;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

/** Carves rare, contained lava pools into sufficiently thick Shadow terrain. */
public final class ShadowLavaFeature extends class_3031<ShadowLavaConfiguration> {
    private static final int WORLDGEN_FLAGS = 19;

    public ShadowLavaFeature(Codec<ShadowLavaConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<ShadowLavaConfiguration> context) {
        class_5281 level = context.method_33652();
        class_5819 random = context.method_33654();
        ShadowLavaConfiguration config = context.method_33656();

        int centerX = context.method_33655().method_10263();
        int centerZ = context.method_33655().method_10260();
        int surfaceY = level.method_8624(
            class_2902.class_2903.field_13194,
            centerX,
            centerZ
        ) - 1;

        class_2338 surface = new class_2338(centerX, surfaceY, centerZ);

        if (!isShadowTerrain(level.method_8320(surface))) {
            return false;
        }

        int radiusX = between(random, config.minRadius(), config.maxRadius());
        int radiusZ = Math.max(config.minRadius(), radiusX - random.method_43048(3));
        int maximumDepth = between(random, config.minDepth(), config.maxDepth());

        if (!canCarve(level, surface, radiusX, radiusZ, maximumDepth)) {
            return false;
        }

        for (int dx = -radiusX; dx <= radiusX; dx++) {
            for (int dz = -radiusZ; dz <= radiusZ; dz++) {
                double distance = normalizedDistance(dx, dz, radiusX, radiusZ);

                if (distance > 1.0D) {
                    continue;
                }

                int x = centerX + dx;
                int z = centerZ + dz;

                if (distance <= 0.72D) {
                    double centerFactor = 1.0D - distance / 0.72D;
                    int localDepth = config.minDepth()
                        + (int)Math.round(
                            centerFactor * (maximumDepth - config.minDepth())
                        );

                    localDepth = Math.max(1, localDepth);
                    int floorY = surfaceY - localDepth;

                    setBlock(
                        level,
                        new class_2338(x, floorY, z),
                        ModBlocks.SHADOW_STONE.method_9564()
                    );

                    for (int y = floorY + 1; y <= surfaceY; y++) {
                        class_2338 lavaPos = new class_2338(x, y, z);
                        setBlock(level, lavaPos, class_2246.field_10164.method_9564());
                        level.method_39281(lavaPos, class_3612.field_15908, 1);
                    }

                    class_2338 above = new class_2338(x, surfaceY + 1, z);
                    if (!level.method_8320(above).method_26215()) {
                        setBlock(level, above, class_2246.field_10124.method_9564());
                    }
                } else {
                    setBlock(
                        level,
                        new class_2338(x, surfaceY, z),
                        ModBlocks.SHADOW_STONE.method_9564()
                    );
                }
            }
        }

        return true;
    }

    private static boolean canCarve(
        class_5281 level,
        class_2338 center,
        int radiusX,
        int radiusZ,
        int depth
    ) {
        for (int dx = -radiusX - 1; dx <= radiusX + 1; dx++) {
            for (int dz = -radiusZ - 1; dz <= radiusZ + 1; dz++) {
                double distance = normalizedDistance(
                    dx,
                    dz,
                    radiusX + 1,
                    radiusZ + 1
                );

                if (distance > 1.0D) {
                    continue;
                }

                int x = center.method_10263() + dx;
                int z = center.method_10260() + dz;
                int localSurfaceY = level.method_8624(
                    class_2902.class_2903.field_13194,
                    x,
                    z
                ) - 1;

                if (Math.abs(localSurfaceY - center.method_10264()) > 2) {
                    return false;
                }

                for (int y = center.method_10264() - depth - 2; y <= center.method_10264(); y++) {
                    class_2338 pos = new class_2338(x, y, z);

                    if (!level.method_37368(pos)
                        || !isShadowTerrain(level.method_8320(pos))
                        || !level.method_8316(pos).method_15769()) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    private static boolean isShadowTerrain(class_2680 state) {
        return state.method_27852(ModBlocks.SHADOW_GRASS)
            || state.method_27852(ModBlocks.SHADOW_SOIL)
            || state.method_27852(ModBlocks.SHADOW_STONE);
    }

    private static void setBlock(class_5281 level, class_2338 pos, class_2680 state) {
        level.method_8652(pos, state, WORLDGEN_FLAGS);
    }

    private static int between(class_5819 random, int minimum, int maximum) {
        return minimum + random.method_43048(maximum - minimum + 1);
    }

    private static double normalizedDistance(
        int dx,
        int dz,
        int radiusX,
        int radiusZ
    ) {
        double normalizedX = dx / (double)Math.max(1, radiusX);
        double normalizedZ = dz / (double)Math.max(1, radiusZ);
        return Math.sqrt(
            normalizedX * normalizedX
                + normalizedZ * normalizedZ
        );
    }
}
