package net.blue.chaoticd.worldgen.tree;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import net.blue.chaoticd.worldgen.tree.AuroraTreeConfiguration.CanopySettings;
import net.blue.chaoticd.worldgen.tree.AuroraTreeConfiguration.FoliageChoice;
import net.blue.chaoticd.worldgen.tree.AuroraTreeConfiguration.ShapeSettings;
import net.blue.chaoticd.worldgen.tree.AuroraTreeConfiguration.TreeProfile;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2397;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

/** Pure, deterministic geometry planner for Aurora trees. It never reads or writes a world. */
public final class AuroraTreePlanner {
    private static final long TREE_SALT = 0x4155524F52415F54L;
    private static final class_2350[] NEIGHBORS = class_2350.values();

    private AuroraTreePlanner() {
    }

    public static TreePlan plan(AuroraTreeConfiguration configuration, long worldSeed, class_2338 origin) {
        class_5819 random = class_5819.method_43049(mix64(worldSeed ^ origin.method_10063() ^ TREE_SALT));
        TreeProfile profile = chooseWeighted(configuration.profiles(), TreeProfile::weight, random);
        FoliageChoice foliage = chooseWeighted(configuration.foliagePalette(), FoliageChoice::weight, random);
        int height = between(random, profile.size().minHeight(), profile.size().maxHeight());
        int baseWidth = between(random, profile.size().minTrunkWidth(), profile.size().maxTrunkWidth());
        int segments = Math.min(height, between(random, profile.size().minSegments(), profile.size().maxSegments()));

        LinkedHashMap<class_2338, class_2680> logs = new LinkedHashMap<>();
        LinkedHashSet<class_2338> requiredGround = new LinkedHashSet<>();
        ArrayList<class_2338> trunkCenters = new ArrayList<>(height);
        ShapeSettings shape = profile.shape();
        growTrunk(configuration.trunkState(), origin, height, baseWidth, segments, shape,
            configuration.maxHorizontalReach(), random, logs, requiredGround, trunkCenters);

        ArrayList<class_2338> branchTips = new ArrayList<>();
        growBranches(configuration.trunkState(), profile, origin, trunkCenters,
            configuration.maxHorizontalReach(), random, logs, branchTips);
        growRoots(configuration.trunkState(), profile, origin, baseWidth,
            configuration.maxHorizontalReach(), random, logs, requiredGround);
        branchTips.removeIf(tip -> isFullyEnclosedByLogs(tip, logs.keySet()));

        LinkedHashSet<class_2338> leafCandidates = new LinkedHashSet<>();
        createCanopy(profile.canopy(), trunkCenters.get(trunkCenters.size() - 1), origin,
            configuration.maxHorizontalReach(), random, leafCandidates);
        createBranchFoliage(profile.canopy(), branchTips, origin, configuration.maxHorizontalReach(),
            random, leafCandidates);
        leafCandidates.removeAll(logs.keySet());
        LinkedHashMap<class_2338, class_2680> leaves = connectLeavesToLogs(
            foliage.state(), logs.keySet(), leafCandidates);

        return new TreePlan(
            profile.name(),
            height,
            baseWidth,
            segments,
            immutableOrderedMap(logs),
            immutableOrderedMap(leaves),
            Collections.unmodifiableSet(new LinkedHashSet<>(requiredGround)),
            List.copyOf(trunkCenters),
            List.copyOf(branchTips)
        );
    }

    private static void growTrunk(class_2680 trunkState, class_2338 origin, int height, int baseWidth,
                                  int segments, ShapeSettings shape, int maxHorizontalReach, class_5819 random,
                                  Map<class_2338, class_2680> logs, Set<class_2338> requiredGround,
                                  List<class_2338> centers) {
        boolean inclined = random.method_43057() < shape.inclinationChance();
        boolean curved = random.method_43057() < shape.bendChance();
        double angle = random.method_43058() * Math.PI * 2.0;
        double driftX = 0.0;
        double driftZ = 0.0;
        double velocityX = inclined ? Math.cos(angle) * shape.bendStrength() * 0.55 : 0.0;
        double velocityZ = inclined ? Math.sin(angle) * shape.bendStrength() * 0.55 : 0.0;
        double targetX = velocityX;
        double targetZ = velocityZ;
        int segmentLength = Math.max(1, height / segments);
        class_2338 previousCenter = origin;

        for (int y = 0; y < height; y++) {
            if (curved && y > 0 && y % segmentLength == 0) {
                angle += (random.method_43058() - 0.5) * 1.45;
                double strength = shape.bendStrength() * (0.35 + random.method_43058() * 0.65);
                targetX = clamp(velocityX * 0.55 + Math.cos(angle) * strength, -0.44, 0.44);
                targetZ = clamp(velocityZ * 0.55 + Math.sin(angle) * strength, -0.44, 0.44);
            }
            velocityX += (targetX - velocityX) * 0.28;
            velocityZ += (targetZ - velocityZ) * 0.28;
            driftX += velocityX;
            driftZ += velocityZ;
            double maximumDrift = Math.max(1.0, maxHorizontalReach * 0.48);
            double driftRadius = Math.sqrt(driftX * driftX + driftZ * driftZ);
            if (driftRadius > maximumDrift) {
                double scale = maximumDrift / driftRadius;
                driftX *= scale;
                driftZ *= scale;
                velocityX *= 0.45;
                velocityZ *= 0.45;
                targetX *= -0.25;
                targetZ *= -0.25;
            }
            class_2338 center = origin.method_10069((int)Math.round(driftX), y, (int)Math.round(driftZ));

            int width = taperedWidth(baseWidth, y, height);
            if (y > 0 && (center.method_10263() != previousCenter.method_10263() || center.method_10260() != previousCenter.method_10260())) {
                addConnectedLine(trunkState, previousCenter.method_10084(), center, logs);
            }
            fillTrunkFootprint(trunkState, center, width, y, logs, y == 0 ? requiredGround : null);
            centers.add(center);
            previousCenter = center;
        }
    }

    private static void fillTrunkFootprint(class_2680 trunkState, class_2338 center, int width, int level,
                                           Map<class_2338, class_2680> logs, Set<class_2338> ground) {
        int minimum = width == 2 ? 0 : -(width / 2);
        int maximum = width == 2 ? 1 : width / 2;
        for (int dx = minimum; dx <= maximum; dx++) {
            for (int dz = minimum; dz <= maximum; dz++) {
                if (width == 3 && Math.abs(dx) == 1 && Math.abs(dz) == 1
                    && (stableHash(center.method_10263() + dx, level, center.method_10260() + dz) & 3L) == 0L) {
                    continue;
                }
                class_2338 position = center.method_10069(dx, 0, dz);
                logs.putIfAbsent(position, withAxis(trunkState, class_2350.class_2351.field_11052));
                if (ground != null) ground.add(position.method_10074());
            }
        }
    }

    private static int taperedWidth(int baseWidth, int y, int height) {
        double progress = y / (double)Math.max(1, height - 1);
        if (baseWidth == 3) {
            if (progress < 0.52) return 3;
            if (progress < 0.80) return 2;
            return 1;
        }
        if (baseWidth == 2) return progress < 0.67 ? 2 : 1;
        return 1;
    }

    private static void growBranches(class_2680 trunkState, TreeProfile profile, class_2338 origin,
                                     List<class_2338> trunkCenters, int maxReach,
                                     class_5819 random, Map<class_2338, class_2680> logs,
                                     List<class_2338> branchTips) {
        ShapeSettings shape = profile.shape();
        int branchCount = between(random, shape.minBranches(), shape.maxBranches());
        if (branchCount == 0) return;
        int firstLevel = Math.min(trunkCenters.size() - 2,
            Math.max(1, (int)Math.floor(trunkCenters.size() * shape.branchStartFraction())));
        double phase = random.method_43058() * Math.PI * 2.0;

        for (int index = 0; index < branchCount; index++) {
            int available = Math.max(1, trunkCenters.size() - 1 - firstLevel);
            int level = firstLevel + Math.floorMod(
                (index * available / Math.max(1, branchCount)) + random.method_43048(3) - 1, available);
            class_2338 anchor = trunkCenters.get(Math.min(level, trunkCenters.size() - 2));
            double angle = phase + (Math.PI * 2.0 * index / branchCount) + (random.method_43058() - 0.5) * 0.72;
            int length = between(random, shape.minBranchLength(), shape.maxBranchLength());
            length = Math.min(length, Math.max(2, maxReach - 2));
            double rise = -0.12 + random.method_43058() * 0.47;
            class_2338 endpoint = branchEndpoint(anchor, origin, angle, length, rise, maxReach - 2);
            addConnectedLine(trunkState, anchor, endpoint, logs);

            if (shape.maxBranchWidth() > 1 && length >= 5 && random.method_43057() < 0.48F) {
                class_2350 offsetDirection = perpendicularDirection(angle);
                class_2338 thickEnd = interpolate(anchor, endpoint, 0.52).method_10093(offsetDirection);
                addConnectedLine(trunkState, anchor.method_10093(offsetDirection), thickEnd, logs);
            }
            branchTips.add(endpoint);

            if (length >= 4 && random.method_43057() < shape.secondaryBranchChance()) {
                class_2338 secondaryStart = interpolate(anchor, endpoint, 0.55 + random.method_43058() * 0.18);
                double splitAngle = angle + (random.method_43056() ? 1.0 : -1.0) * (0.58 + random.method_43058() * 0.62);
                int secondaryLength = Math.max(2, (int)Math.round(length * (0.42 + random.method_43058() * 0.23)));
                class_2338 secondaryEnd = branchEndpoint(secondaryStart, origin, splitAngle,
                    secondaryLength, 0.08 + random.method_43058() * 0.33, maxReach - 2);
                addConnectedLine(trunkState, secondaryStart, secondaryEnd, logs);
                branchTips.add(secondaryEnd);
            }
        }
    }

    private static class_2338 branchEndpoint(class_2338 start, class_2338 origin, double angle, int length,
                                           double rise, int maximumRadius) {
        int endX = start.method_10263() + (int)Math.round(Math.cos(angle) * length);
        int endZ = start.method_10260() + (int)Math.round(Math.sin(angle) * length);
        int endY = start.method_10264() + (int)Math.round(rise * length);
        int dx = endX - origin.method_10263();
        int dz = endZ - origin.method_10260();
        double radius = Math.sqrt(dx * (double)dx + dz * (double)dz);
        if (radius > maximumRadius) {
            double scale = maximumRadius / radius;
            endX = origin.method_10263() + (int)Math.round(dx * scale);
            endZ = origin.method_10260() + (int)Math.round(dz * scale);
        }
        return new class_2338(endX, Math.max(origin.method_10264() + 2, endY), endZ);
    }

    private static void addConnectedLine(class_2680 trunkState, class_2338 start, class_2338 end,
                                         Map<class_2338, class_2680> logs) {
        int steps = Math.max(Math.abs(end.method_10263() - start.method_10263()),
            Math.max(Math.abs(end.method_10264() - start.method_10264()), Math.abs(end.method_10260() - start.method_10260())));
        class_2338 cursor = start;
        logs.putIfAbsent(cursor, withAxis(trunkState, class_2350.class_2351.field_11052));
        for (int step = 1; step <= Math.max(1, steps); step++) {
            double progress = step / (double)Math.max(1, steps);
            class_2338 target = new class_2338(
                (int)Math.round(start.method_10263() + (end.method_10263() - start.method_10263()) * progress),
                (int)Math.round(start.method_10264() + (end.method_10264() - start.method_10264()) * progress),
                (int)Math.round(start.method_10260() + (end.method_10260() - start.method_10260()) * progress));
            cursor = walkAxis(trunkState, cursor, target.method_10263(), class_2350.class_2351.field_11048, logs);
            cursor = walkAxis(trunkState, cursor, target.method_10260(), class_2350.class_2351.field_11051, logs);
            cursor = walkAxis(trunkState, cursor, target.method_10264(), class_2350.class_2351.field_11052, logs);
        }
    }

    private static class_2338 walkAxis(class_2680 state, class_2338 cursor, int target,
                                     class_2350.class_2351 axis, Map<class_2338, class_2680> logs) {
        int current = axis.method_10173(cursor.method_10263(), cursor.method_10264(), cursor.method_10260());
        while (current != target) {
            int delta = Integer.compare(target, current);
            cursor = switch (axis) {
                case field_11048 -> cursor.method_10069(delta, 0, 0);
                case field_11052 -> cursor.method_10069(0, delta, 0);
                case field_11051 -> cursor.method_10069(0, 0, delta);
            };
            logs.putIfAbsent(cursor, withAxis(state, axis));
            current += delta;
        }
        return cursor;
    }

    private static void growRoots(class_2680 trunkState, TreeProfile profile, class_2338 origin,
                                  int baseWidth, int maxReach, class_5819 random,
                                  Map<class_2338, class_2680> logs, Set<class_2338> ground) {
        ShapeSettings shape = profile.shape();
        if (shape.maxRootLength() == 0 || random.method_43057() >= shape.rootChance()) return;
        int roots = Math.min(7, 2 + baseWidth + random.method_43048(3));
        double phase = random.method_43058() * Math.PI * 2.0;
        for (int root = 0; root < roots; root++) {
            double angle = phase + Math.PI * 2.0 * root / roots + (random.method_43058() - 0.5) * 0.5;
            int length = Math.min(maxReach - 1, between(random, 1, shape.maxRootLength()));
            class_2338 end = origin.method_10069((int)Math.round(Math.cos(angle) * length), 0,
                (int)Math.round(Math.sin(angle) * length));
            HashSet<class_2338> before = new HashSet<>(logs.keySet());
            addConnectedLine(trunkState, origin, end, logs);
            for (class_2338 position : logs.keySet()) {
                if (!before.contains(position) && position.method_10264() == origin.method_10264()) ground.add(position.method_10074());
            }
        }
    }

    private static void createCanopy(CanopySettings canopy, class_2338 crown, class_2338 origin,
                                     int maxReach, class_5819 random, Set<class_2338> leaves) {
        int radius = between(random, canopy.minRadius(), canopy.maxRadius());
        int blobs = between(random, canopy.minBlobs(), canopy.maxBlobs());
        addLeafBlob(crown, origin, radius, Math.max(2, Math.round(radius * canopy.verticalScale())),
            canopy.density(), maxReach, random, leaves);

        for (int blob = 1; blob < blobs; blob++) {
            double angle = random.method_43058() * Math.PI * 2.0;
            double radial = radius * (0.15 + random.method_43058() * 0.56);
            int offsetY = (int)Math.round((random.method_43058() - 0.52) * radius * canopy.verticalScale());
            class_2338 center = crown.method_10069((int)Math.round(Math.cos(angle) * radial), offsetY,
                (int)Math.round(Math.sin(angle) * radial));
            int blobRadius = Math.max(1, (int)Math.round(radius * (0.34 + random.method_43058() * 0.34)));
            addLeafBlob(center, origin, blobRadius,
                Math.max(1, Math.round(blobRadius * canopy.verticalScale())),
                canopy.density() * (0.88F + random.method_43057() * 0.15F), maxReach, random, leaves);
        }
    }

    private static void createBranchFoliage(CanopySettings canopy, List<class_2338> branchTips,
                                            class_2338 origin, int maxReach, class_5819 random,
                                            Set<class_2338> leaves) {
        for (class_2338 tip : branchTips) {
            int radius = between(random, canopy.minTipRadius(), canopy.maxTipRadius());
            addLeafBlob(tip, origin, radius, Math.max(1, Math.round(radius * canopy.verticalScale())),
                Math.min(0.92F, canopy.density() + 0.08F), maxReach, random, leaves);
        }
    }

    private static boolean isFullyEnclosedByLogs(class_2338 position, Set<class_2338> logs) {
        for (class_2350 direction : NEIGHBORS) {
            if (!logs.contains(position.method_10093(direction))) return false;
        }
        return true;
    }

    private static void addLeafBlob(class_2338 center, class_2338 origin, int radius, int verticalRadius,
                                    float density, int maxReach, class_5819 random, Set<class_2338> leaves) {
        for (int dy = -verticalRadius; dy <= verticalRadius; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2338 position = center.method_10069(dx, dy, dz);
                    if (position.method_10264() <= origin.method_10264()) continue;
                    int originX = position.method_10263() - origin.method_10263();
                    int originZ = position.method_10260() - origin.method_10260();
                    if (originX * originX + originZ * originZ > maxReach * maxReach) continue;
                    double normalized = dx * (double)dx / (radius * radius)
                        + dz * (double)dz / (radius * radius)
                        + dy * (double)dy / (verticalRadius * verticalRadius);
                    double raggedBoundary = 0.78 + random.method_43058() * 0.42;
                    if (normalized > raggedBoundary) continue;
                    float localDensity = normalized < 0.28 ? Math.min(0.96F, density + 0.20F) : density;
                    if (random.method_43057() <= localDensity) leaves.add(position);
                }
            }
        }
        if (center.method_10264() > origin.method_10264()) {
            int centerDx = center.method_10263() - origin.method_10263();
            int centerDz = center.method_10260() - origin.method_10260();
            if (centerDx * centerDx + centerDz * centerDz <= maxReach * maxReach) leaves.add(center);
            for (class_2350 direction : NEIGHBORS) {
                class_2338 neighbor = center.method_10093(direction);
                int dx = neighbor.method_10263() - origin.method_10263();
                int dz = neighbor.method_10260() - origin.method_10260();
                if (neighbor.method_10264() > origin.method_10264() && dx * dx + dz * dz <= maxReach * maxReach) {
                    leaves.add(neighbor);
                }
            }
        }
    }

    private static LinkedHashMap<class_2338, class_2680> connectLeavesToLogs(class_2680 foliage,
                                                                            Set<class_2338> logs,
                                                                            Set<class_2338> candidates) {
        Map<class_2338, Integer> distance = new HashMap<>();
        Queue<class_2338> queue = new ArrayDeque<>();
        for (class_2338 log : logs) {
            distance.put(log, 0);
            queue.add(log);
        }
        while (!queue.isEmpty()) {
            class_2338 current = queue.remove();
            int nextDistance = distance.get(current) + 1;
            if (nextDistance > class_2397.field_31111 - 1) continue;
            for (class_2350 direction : NEIGHBORS) {
                class_2338 neighbor = current.method_10093(direction);
                if (!candidates.contains(neighbor) || distance.containsKey(neighbor)) continue;
                distance.put(neighbor, nextDistance);
                queue.add(neighbor);
            }
        }

        LinkedHashMap<class_2338, class_2680> result = new LinkedHashMap<>();
        candidates.stream()
            .filter(distance::containsKey)
            .sorted(Comparator.<class_2338>comparingInt(class_2338::method_10264)
                .thenComparingInt(class_2338::method_10263).thenComparingInt(class_2338::method_10260))
            .forEach(position -> {
                class_2680 state = foliage;
                if (state.method_28498(class_2397.field_11199)) {
                    state = state.method_11657(class_2397.field_11199, distance.get(position));
                }
                if (state.method_28498(class_2397.field_11200)) state = state.method_11657(class_2397.field_11200, false);
                if (state.method_28498(class_2397.field_38227)) state = state.method_11657(class_2397.field_38227, false);
                result.put(position, state);
            });
        return result;
    }

    private static class_2680 withAxis(class_2680 state, class_2350.class_2351 axis) {
        return state.method_28498(class_2465.field_11459) ? state.method_11657(class_2465.field_11459, axis) : state;
    }

    private static class_2350 perpendicularDirection(double angle) {
        double x = -Math.sin(angle);
        double z = Math.cos(angle);
        if (Math.abs(x) > Math.abs(z)) return x >= 0 ? class_2350.field_11034 : class_2350.field_11039;
        return z >= 0 ? class_2350.field_11035 : class_2350.field_11043;
    }

    private static class_2338 interpolate(class_2338 start, class_2338 end, double progress) {
        return new class_2338(
            (int)Math.round(start.method_10263() + (end.method_10263() - start.method_10263()) * progress),
            (int)Math.round(start.method_10264() + (end.method_10264() - start.method_10264()) * progress),
            (int)Math.round(start.method_10260() + (end.method_10260() - start.method_10260()) * progress));
    }

    private static int between(class_5819 random, int minimum, int maximum) {
        return minimum == maximum ? minimum : minimum + random.method_43048(maximum - minimum + 1);
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static long stableHash(int x, int y, int z) {
        return mix64(x * 0x9E3779B97F4A7C15L ^ y * 0xC2B2AE3D27D4EB4FL ^ z * 0x165667B19E3779F9L);
    }

    private static long mix64(long value) {
        value = (value ^ (value >>> 30)) * 0xBF58476D1CE4E5B9L;
        value = (value ^ (value >>> 27)) * 0x94D049BB133111EBL;
        return value ^ (value >>> 31);
    }

    private static <T> T chooseWeighted(List<T> entries, java.util.function.ToIntFunction<T> weight,
                                        class_5819 random) {
        int total = entries.stream().mapToInt(weight).sum();
        int choice = random.method_43048(total);
        for (T entry : entries) {
            choice -= weight.applyAsInt(entry);
            if (choice < 0) return entry;
        }
        return entries.get(entries.size() - 1);
    }

    private static <K, V> Map<K, V> immutableOrderedMap(Map<K, V> source) {
        return Collections.unmodifiableMap(new LinkedHashMap<>(source));
    }

    public record TreePlan(
        String profileName,
        int height,
        int baseWidth,
        int segments,
        Map<class_2338, class_2680> logs,
        Map<class_2338, class_2680> leaves,
        Set<class_2338> requiredGround,
        List<class_2338> trunkCenters,
        List<class_2338> branchTips
    ) {
        public Set<class_2338> allBlocks() {
            HashSet<class_2338> result = new HashSet<>(logs.keySet());
            result.addAll(leaves.keySet());
            return Collections.unmodifiableSet(result);
        }
    }
}
