package net.blue.chaoticd.worldgen.tree;

import com.mojang.serialization.Codec;
import java.util.Comparator;
import java.util.Map;
import net.blue.chaoticd.worldgen.tree.AuroraTreePlanner.TreePlan;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3031;
import net.minecraft.class_3481;
import net.minecraft.class_5281;
import net.minecraft.class_5821;

/** Places an Aurora tree only after validating its complete deterministic geometry. */
public final class AuroraTreeFeature extends class_3031<AuroraTreeConfiguration> {
    private static final int WORLDGEN_FLAGS = 19;

    public AuroraTreeFeature(Codec<AuroraTreeConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<AuroraTreeConfiguration> context) {
        class_5281 level = context.method_33652();
        AuroraTreeConfiguration configuration = context.method_33656();
        TreePlan plan = AuroraTreePlanner.plan(configuration, level.method_8412(), context.method_33655());
        if (!hasValidBounds(level, plan) || !hasValidGround(level, configuration, plan)
            || !hasClearSpace(level, plan)) {
            return false;
        }

        plan.logs().entrySet().stream()
            .sorted(Comparator.comparingInt(entry -> entry.getKey().method_10264()))
            .forEach(entry -> level.method_8652(entry.getKey(), entry.getValue(), WORLDGEN_FLAGS));
        plan.leaves().entrySet().stream()
            .sorted(Comparator.comparingInt(entry -> entry.getKey().method_10264()))
            .forEach(entry -> level.method_8652(entry.getKey(), entry.getValue(), WORLDGEN_FLAGS));
        return true;
    }

    private static boolean hasValidBounds(class_5281 level, TreePlan plan) {
        for (class_2338 position : plan.allBlocks()) {
            if (position.method_10264() <= level.method_31607() || position.method_10264() >= level.method_31600() - 1
                || !level.method_37368(position)) {
                return false;
            }
        }
        return true;
    }

    private static boolean hasValidGround(class_5281 level, AuroraTreeConfiguration configuration,
                                          TreePlan plan) {
        for (class_2338 position : plan.requiredGround()) {
            class_2680 ground = level.method_8320(position);
            boolean valid = configuration.groundStates().stream()
                .anyMatch(configured -> ground.method_27852(configured.method_26204()));
            if (!valid) return false;
        }
        return true;
    }

    private static boolean hasClearSpace(class_5281 level, TreePlan plan) {
        for (Map.Entry<class_2338, class_2680> entry : plan.logs().entrySet()) {
            if (!canReplace(level.method_8320(entry.getKey()))) return false;
        }
        for (Map.Entry<class_2338, class_2680> entry : plan.leaves().entrySet()) {
            if (!canReplace(level.method_8320(entry.getKey()))) return false;
        }
        return true;
    }

    private static boolean canReplace(class_2680 state) {
        if (!state.method_26227().method_15769() || state.method_26164(class_3481.field_33757)
            || state.method_26164(class_3481.field_15475) || state.method_26164(class_3481.field_15503)) {
            return false;
        }
        return state.method_26215() || state.method_26164(class_3481.field_44470);
    }
}
