package net.blue.chaoticd.worldgen;

import net.blue.chaoticd.ChaoticDimensions;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1474;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3486;
import net.minecraft.class_3730;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_7924;

/**
 * Mantém uma pequena população de peixes tropicais vanilla
 * nos lagos calmos da dimensão Aurora.
 *
 * <p>O sistema procura apenas água-fonte com profundidade suficiente,
 * evitando que peixes apareçam em cachoeiras ou pequenos fluxos.</p>
 */
public final class AuroraAquaticLife {
    private static final class_5321<class_1937> AURORA_DIMENSION =
        class_5321.method_29179(
            class_7924.field_41223,
            new class_2960(
                ChaoticDimensions.MOD_ID,
                "aurora_dimension"
            )
        );

    /**
     * Intervalo entre verificações.
     *
     * <p>100 ticks equivalem aproximadamente a 5 segundos.</p>
     */
    private static final int CHECK_INTERVAL_TICKS = 100;

    /**
     * Distância horizontal em que o sistema procura lagos
     * ao redor de cada jogador.
     */
    private static final int SEARCH_RADIUS = 28;

    /**
     * Quantidade máxima de peixes tropicais perto de um jogador.
     */
    private static final int MAX_FISH_NEAR_PLAYER = 10;

    /**
     * Número de posições aleatórias testadas em cada verificação.
     */
    private static final int WATER_SEARCH_ATTEMPTS = 18;

    /**
     * Quantos blocos abaixo do topo da coluna podem ser examinados
     * para encontrar a superfície de um lago.
     */
    private static final int WATER_SURFACE_SCAN_DEPTH = 7;

    private AuroraAquaticLife() {
    }

    /**
     * Registra a verificação no final de cada tick dos mundos do servidor.
     */
    public static void initialize() {
        ServerTickEvents.END_WORLD_TICK.register(
            AuroraAquaticLife::tickWorld
        );
    }

    /**
     * Executa o controle populacional apenas na dimensão Aurora.
     */
    private static void tickWorld(class_3218 level) {
        if (!level.method_27983().equals(AURORA_DIMENSION)
            || level.method_8510() % CHECK_INTERVAL_TICKS != 0L
            || level.method_18456().isEmpty()) {
            return;
        }

        class_5819 random = level.method_8409();

        for (class_3222 player : level.method_18456()) {
            if (player.method_7325()) {
                continue;
            }

            class_238 populationArea =
                player.method_5829().method_1009(
                    SEARCH_RADIUS,
                    18.0D,
                    SEARCH_RADIUS
                );

            int nearbyFish =
                level.method_8390(
                    class_1474.class,
                    populationArea,
                    class_1474::method_5805
                ).size();

            if (nearbyFish >= MAX_FISH_NEAR_PLAYER) {
                continue;
            }

            for (
                int attempt = 0;
                attempt < WATER_SEARCH_ATTEMPTS;
                attempt++
            ) {
                int x =
                    player.method_31477()
                        + random.method_43048(
                            SEARCH_RADIUS * 2 + 1
                        )
                        - SEARCH_RADIUS;

                int z =
                    player.method_31479()
                        + random.method_43048(
                            SEARCH_RADIUS * 2 + 1
                        )
                        - SEARCH_RADIUS;

                class_2338 spawnPos = findCalmWater(
                    level,
                    random,
                    x,
                    z,
                    player.method_31478()
                );

                if (spawnPos != null) {
                    spawnFish(
                        level,
                        random,
                        spawnPos
                    );

                    break;
                }
            }
        }
    }

    /**
     * Procura uma posição submersa dentro de um lago estável.
     *
     * @return posição válida dentro da água ou {@code null}
     */
    private static class_2338 findCalmWater(
        class_3218 level,
        class_5819 random,
        int x,
        int z,
        int playerY
    ) {
        int topY = level.method_8624(
            class_2902.class_2903.field_13202,
            x,
            z
        );

        if (topY <= level.method_31607() + 1) {
            return null;
        }

        class_2338 surface = null;

        int minimumScanY = Math.max(
            level.method_31607(),
            topY - WATER_SURFACE_SCAN_DEPTH
        );

        for (int y = topY; y >= minimumScanY; y--) {
            class_2338 candidate =
                new class_2338(x, y, z);

            if (isSourceWater(level, candidate)) {
                surface = candidate;
                break;
            }
        }

        if (surface == null
            || Math.abs(surface.method_10264() - playerY) > 28) {
            return null;
        }

        /*
         * Exige várias fontes de água vizinhas.
         * Uma cachoeira ou corrente estreita normalmente não passa
         * nesta verificação.
         */
        int calmNeighbours = 0;

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (isSourceWater(
                    level,
                    surface.method_10069(dx, 0, dz)
                )) {
                    calmNeighbours++;
                }
            }
        }

        if (calmNeighbours < 6) {
            return null;
        }

        /*
         * Mede quantos blocos de água existem abaixo da superfície.
         */
        int waterDepth = 0;

        while (
            waterDepth < 5
                && level.method_8316(
                    surface.method_10087(waterDepth)
                ).method_15767(class_3486.field_15517)
        ) {
            waterDepth++;
        }

        if (waterDepth < 2) {
            return null;
        }

        /*
         * Escolhe aleatoriamente uma altura dentro da coluna de água.
         */
        return surface.method_10087(
            random.method_43048(waterDepth)
        );
    }

    /**
     * Verifica se o bloco contém uma fonte de água completa.
     */
    private static boolean isSourceWater(
        class_3218 level,
        class_2338 pos
    ) {
        return level.method_8316(pos).method_15767(class_3486.field_15517)
            && level.method_8316(pos).method_15771();
    }

    /**
     * Cria um peixe tropical vanilla com variante aleatória.
     */
    private static void spawnFish(
        class_3218 level,
        class_5819 random,
        class_2338 pos
    ) {
        class_1474 fish =
            class_1299.field_6111.method_5883(level);

        if (fish == null) {
            return;
        }

        fish.method_5808(
            pos.method_10263() + 0.5D,
            pos.method_10264() + 0.35D,
            pos.method_10260() + 0.5D,
            random.method_43057() * 360.0F,
            0.0F
        );

        /*
         * No Minecraft 1.20.1 com mappings oficiais da Mojang,
         * finalizeSpawn exige cinco argumentos.
         *
         * O quarto argumento é SpawnGroupData.
         * O quinto argumento é CompoundTag.
         *
         * Ambos podem ser null para um spawn natural comum.
         */
        fish.method_5943(
            level,
            level.method_8404(pos),
            class_3730.field_16459,
            null,
            null
        );

        level.method_8649(fish);
    }
}