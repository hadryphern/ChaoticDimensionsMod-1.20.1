package net.blue.chaoticd.worldgen;

import net.blue.chaoticd.ChaoticDimensions;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7924;

/** Adds only the requested extremely rare Ruby ore to Overworld terrain. */
public final class LegacyWorldgen {
    private static final class_5321<class_6796> RUBY_ORE = class_5321.method_29179(
        class_7924.field_41245,
        new class_2960(ChaoticDimensions.MOD_ID, "ruby_ore")
    );

    private LegacyWorldgen() {
    }

    public static void initialize() {
        BiomeModifications.addFeature(
            BiomeSelectors.foundInOverworld(),
            class_2893.class_2895.field_13176,
            RUBY_ORE
        );
    }
}
