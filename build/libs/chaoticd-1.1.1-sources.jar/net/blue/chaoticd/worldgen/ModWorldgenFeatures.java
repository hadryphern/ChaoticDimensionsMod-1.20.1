package net.blue.chaoticd.worldgen;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.worldgen.tree.AuroraTreeConfiguration;
import net.blue.chaoticd.worldgen.tree.AuroraTreeFeature;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_7923;

/** Registers code-backed world-generation features used by the Aurora datapack. */
public final class ModWorldgenFeatures {
    public static final class_3031<AuroraTreeConfiguration> AURORA_TREE = class_2378.method_10230(
        class_7923.field_41144,
        new class_2960(ChaoticDimensions.MOD_ID, "aurora_tree"),
        new AuroraTreeFeature(AuroraTreeConfiguration.CODEC)
    );

    private ModWorldgenFeatures() {
    }

    public static void initialize() {
        // Class loading performs the registry insertion before datapacks are decoded.
    }
}
