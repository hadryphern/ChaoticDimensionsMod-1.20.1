package net.blue.chaoticd.worldgen;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.ModItems;
import net.blue.chaoticd.content.worldgen.AuroraSafeArrival;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1542;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * Server-authoritative transitions, curse behavior and Death Totem rules.
 *
 * <p>Falling below Aurora enters Shadow. Dropping a Death Totem in Shadow
 * returns the player to Aurora while returning the item to the inventory.</p>
 */
public final class ShadowDimensionSystems {
    public static final class_5321<class_1937> AURORA_DIMENSION = class_5321.method_29179(
        class_7924.field_41223,
        id("aurora_dimension")
    );

    public static final class_5321<class_1937> SHADOW_DIMENSION = class_5321.method_29179(
        class_7924.field_41223,
        id("shadow_dimension")
    );

    private static final int AURORA_VOID_MARGIN = 8;
    private static final int CURSE_REFRESH_TICKS = 20;
    private static final int CURSE_DURATION_TICKS = 60;
    private static final int DAMAGE_INTERVAL_TICKS = 60;
    private static final float SHADOW_DAMAGE = 2.0F;
    private static final double DROPPED_TOTEM_SEARCH_RADIUS = 6.0D;

    private static final Set<UUID> CURSED_PLAYERS = new HashSet<>();

    private ShadowDimensionSystems() {
    }

    public static void initialize() {
        ServerTickEvents.END_WORLD_TICK.register(
            ShadowDimensionSystems::tickWorld
        );

        ServerPlayerEvents.COPY_FROM.register(
            ShadowDimensionSystems::copyDeathTotemsAfterRespawn
        );
    }

    private static void tickWorld(class_3218 level) {
        if (level.method_27983().equals(AURORA_DIMENSION)) {
            for (class_3222 player : List.copyOf(level.method_18456())) {
                clearShadowCurse(player);
                handleAuroraVoidFall(level, player);
            }

            return;
        }

        if (level.method_27983().equals(SHADOW_DIMENSION)) {
            for (class_3222 player : List.copyOf(level.method_18456())) {
                if (handleDroppedDeathTotem(level, player)) {
                    continue;
                }

                if (isProtected(player)) {
                    clearShadowCurse(player);
                } else {
                    applyShadowCurse(level, player);
                }
            }

            return;
        }

        for (class_3222 player : level.method_18456()) {
            clearShadowCurse(player);
        }
    }

    private static void handleAuroraVoidFall(class_3218 aurora, class_3222 player) {
        if (player.method_23318() >= aurora.method_31607() - AURORA_VOID_MARGIN) {
            return;
        }

        class_3218 shadow = player.field_13995.method_3847(SHADOW_DIMENSION);

        if (shadow == null) {
            player.method_7353(
                class_2561.method_43471("message.chaoticd.shadow_unavailable"),
                false
            );
            return;
        }

        ShadowSafeArrival.find(shadow).ifPresentOrElse(
            arrival -> teleport(player, shadow, arrival),
            () -> player.method_7353(
                class_2561.method_43471("message.chaoticd.shadow_no_safe_arrival"),
                false
            )
        );
    }

    private static boolean handleDroppedDeathTotem(
        class_3218 shadow,
        class_3222 player
    ) {
        List<class_1542> drops = shadow.method_8390(
            class_1542.class,
            player.method_5829().method_1014(DROPPED_TOTEM_SEARCH_RADIUS),
            item -> item.method_5805() && item.method_6983().method_31574(ModItems.DEATH_TOTEM)
        );

        if (drops.isEmpty()) {
            return false;
        }

        class_1542 dropped = drops.get(0);
        class_1799 returnedTotem = dropped.method_6983().method_7972();
        dropped.method_31472();

        if (!player.method_31548().method_7394(returnedTotem)) {
            player.method_31548().method_5447(
                player.method_31548().field_7545,
                returnedTotem
            );
        }

        player.field_7512.method_7623();

        class_3218 aurora = player.field_13995.method_3847(AURORA_DIMENSION);

        if (aurora == null) {
            player.method_7353(
                class_2561.method_43471("message.chaoticd.aurora_unavailable"),
                false
            );
            return true;
        }

        clearShadowCurse(player);

        AuroraSafeArrival.find(aurora).ifPresentOrElse(
            arrival -> teleport(player, aurora, arrival),
            () -> player.method_7353(
                class_2561.method_43471("message.chaoticd.aurora_no_safe_arrival"),
                false
            )
        );

        return true;
    }

    private static boolean isProtected(class_3222 player) {
        return player.method_6079().method_31574(ModItems.DEATH_TOTEM);
    }

    private static void applyShadowCurse(class_3218 level, class_3222 player) {
        boolean newlyCursed = CURSED_PLAYERS.add(player.method_5667());

        if (newlyCursed || player.field_6012 % CURSE_REFRESH_TICKS == 0) {
            applyEffect(player, class_1294.field_5919, 0);
            applyEffect(player, class_1294.field_5909, 1);
            applyEffect(player, class_1294.field_38092, 0);
            applyEffect(player, class_1294.field_5901, 2);
        }

        if (!player.method_7337()
            && !player.method_7325()
            && player.field_6012 % DAMAGE_INTERVAL_TICKS == 0) {
            player.method_5643(level.method_48963().method_48831(), SHADOW_DAMAGE);
        }
    }

    private static void applyEffect(
        class_3222 player,
        class_1291 effect,
        int amplifier
    ) {
        player.method_6092(
            new class_1293(
                effect,
                CURSE_DURATION_TICKS,
                amplifier,
                true,
                false,
                true
            )
        );
    }

    private static void clearShadowCurse(class_3222 player) {
        if (!CURSED_PLAYERS.remove(player.method_5667())) {
            return;
        }

        player.method_6016(class_1294.field_5919);
        player.method_6016(class_1294.field_5909);
        player.method_6016(class_1294.field_38092);
        player.method_6016(class_1294.field_5901);
    }

    private static void teleport(
        class_3222 player,
        class_3218 destination,
        class_2338 arrival
    ) {
        player.method_18799(class_243.field_1353);
        player.field_6017 = 0.0F;

        player.method_14251(
            destination,
            arrival.method_10263() + 0.5D,
            arrival.method_10264() + 0.1D,
            arrival.method_10260() + 0.5D,
            player.method_36454(),
            player.method_36455()
        );
    }

    /**
     * Inventory.dropAll is mixed so Death Totems remain on the old player.
     * This callback copies any missing Totem stacks to the respawned player.
     */
    private static void copyDeathTotemsAfterRespawn(
        class_3222 oldPlayer,
        class_3222 newPlayer,
        boolean alive
    ) {
        if (alive) {
            return;
        }

        class_1661 oldInventory = oldPlayer.method_31548();
        class_1661 newInventory = newPlayer.method_31548();

        int oldCount = countDeathTotems(oldInventory);
        int newCount = countDeathTotems(newInventory);
        int missing = oldCount - newCount;

        if (missing <= 0) {
            return;
        }

        for (
            int slot = 0;
            slot < oldInventory.method_5439() && missing > 0;
            slot++
        ) {
            class_1799 stack = oldInventory.method_5438(slot);

            if (!stack.method_31574(ModItems.DEATH_TOTEM)) {
                continue;
            }

            class_1799 copy = stack.method_7972();

            if (newInventory.method_5438(slot).method_7960()) {
                newInventory.method_5447(slot, copy);
            } else {
                newInventory.method_7394(copy);
            }

            missing -= copy.method_7947();
        }
    }

    private static int countDeathTotems(class_1661 inventory) {
        int count = 0;

        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            class_1799 stack = inventory.method_5438(slot);

            if (stack.method_31574(ModItems.DEATH_TOTEM)) {
                count += stack.method_7947();
            }
        }

        return count;
    }

    private static class_2960 id(String path) {
        return new class_2960(ChaoticDimensions.MOD_ID, path);
    }
}
