package net.blue.chaoticd.rarity;

import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_1887;

/** Runtime inputs available to item and enchantment rarity providers. */
public record RarityContext(class_1799 stack, class_1887 enchantment, int enchantmentLevel) {
    public RarityContext {
        Objects.requireNonNull(stack, "stack");
        if (enchantment == null && enchantmentLevel != 0) {
            throw new IllegalArgumentException("An item-only context cannot have an enchantment level");
        }
        if (enchantmentLevel < 0) {
            throw new IllegalArgumentException("Enchantment level cannot be negative");
        }
    }

    public static RarityContext forItem(class_1799 stack) {
        return new RarityContext(stack, null, 0);
    }

    public static RarityContext forEnchantment(class_1799 stack, class_1887 enchantment, int level) {
        return new RarityContext(stack, Objects.requireNonNull(enchantment, "enchantment"), level);
    }

    public boolean hasEnchantment() {
        return enchantment != null;
    }
}
