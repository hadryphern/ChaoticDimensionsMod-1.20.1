package net.blue.chaoticd.rarity;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2960;

/** Automatic item/enchantment rarity resolution with one documented priority pipeline. */
public final class RarityResolver {
    public static final String NBT_ROOT = "ChaoticDimensions";
    public static final String NBT_RARITY = "Rarity";

    private static final RarityResolver GLOBAL = new RarityResolver(RarityRegistry.global(), true);

    private final RarityRegistry registry;
    private final boolean bootstrapDefaults;

    /** Creates a resolver for a custom registry. The global resolver contains the mod defaults. */
    public RarityResolver(RarityRegistry registry) {
        this(registry, false);
    }

    private RarityResolver(RarityRegistry registry, boolean bootstrapDefaults) {
        this.registry = Objects.requireNonNull(registry, "registry");
        this.bootstrapDefaults = bootstrapDefaults;
    }

    public static RarityResolver global() {
        return GLOBAL;
    }

    /**
     * Resolves the final stack rarity. Existing enchantment-score thresholds are deliberately kept.
     * Individual enchantment lines must call {@link #resolveEnchantment(class_1799, class_1887, int)}.
     */
    public RarityDefinition resolveItem(class_1799 stack) {
        ensureDefaults();
        // An explicit 1.20.1 NBT override is authoritative; enchantment aggregation applies otherwise.
        Optional<RarityDefinition> explicit = explicitRarity(stack);
        if (explicit.isPresent()) return explicit.get();
        int totalScore = resolveBaseItem(stack).progressionThreshold();
        for (Map.Entry<class_1887, Integer> entry : class_1890.method_8222(stack).entrySet()) {
            if (!ModRarities.isSapphireLegendaryLevel(stack, entry.getValue())) {
                totalScore += resolveEnchantment(stack, entry.getKey(), entry.getValue()).enchantmentScore();
            }
        }
        return definitionForScore(totalScore);
    }

    /**
     * Base priority: NBT override, exact item, specialized provider, tag, category provider,
     * vanilla rarity, global fallback.
     */
    public RarityDefinition resolveBaseItem(class_1799 stack) {
        Objects.requireNonNull(stack, "stack");
        ensureDefaults();
        RarityContext context = RarityContext.forItem(stack);
        Optional<RarityDefinition> result = explicitRarity(stack)
            .or(() -> registry.registeredItem(stack.method_7909()))
            .or(() -> resolveItemProviders(registry.itemProviders(), context))
            .or(() -> registry.taggedItem(stack))
            .or(() -> resolveItemProviders(registry.categoryProviders(), context));
        return result.orElseGet(() -> switch (stack.method_7932()) {
            case field_8907 -> known(ModRarities.UNCOMMON);
            case field_8903 -> known(ModRarities.RARE);
            case field_8904 -> known(ModRarities.VERY_RARE);
            default -> registry.fallback();
        });
    }

    /**
     * Enchantment priority: contextual provider (Sapphire L), exact enchantment registration,
     * vanilla Enchantment.Rarity, fallback. Providers are evaluated by explicit numeric priority.
     */
    public RarityDefinition resolveEnchantment(class_1799 stack, class_1887 enchantment, int level) {
        ensureDefaults();
        RarityContext context = RarityContext.forEnchantment(stack, enchantment, level);
        for (RarityRegistry.ProviderEntry<EnchantmentRarityProvider> entry : registry.enchantmentProviders()) {
            Optional<RarityDefinition> result = entry.provider().resolve(context, registry);
            if (result.isPresent()) return result.get();
        }
        Optional<RarityDefinition> registered = registry.registeredEnchantment(enchantment);
        if (registered.isPresent()) return registered.get();
        return switch (enchantment.method_8186()) {
            case field_9087 -> known(ModRarities.COMMON);
            case field_9090 -> known(ModRarities.UNCOMMON);
            case field_9088 -> known(ModRarities.RARE);
            case field_9091 -> known(ModRarities.VERY_RARE);
        };
    }

    public Optional<RarityDefinition> explicitRarity(class_1799 stack) {
        ensureDefaults();
        class_2487 root = stack.method_7941(NBT_ROOT);
        if (root == null || !root.method_10573(NBT_RARITY, class_2520.field_33258)) return Optional.empty();
        class_2960 id = class_2960.method_12829(root.method_10558(NBT_RARITY));
        return id == null ? Optional.empty() : registry.definition(id);
    }

    /** 1.20.1-compatible explicit override: {ChaoticDimensions:{Rarity:"namespace:id"}}. */
    public void setExplicitRarity(class_1799 stack, RarityDefinition definition) {
        ensureDefaults();
        registry.require(definition.id());
        stack.method_7911(NBT_ROOT).method_10582(NBT_RARITY, definition.id().toString());
    }

    public void clearExplicitRarity(class_1799 stack) {
        class_2487 root = stack.method_7941(NBT_ROOT);
        if (root == null) return;
        root.method_10551(NBT_RARITY);
        if (root.method_33133()) stack.method_7983(NBT_ROOT);
    }

    public RarityDefinition definitionForScore(int score) {
        ensureDefaults();
        RarityDefinition result = registry.fallback();
        for (RarityDefinition candidate : registry.definitionsByProgression()) {
            if (score >= candidate.progressionThreshold()) result = candidate;
        }
        return result;
    }

    private Optional<RarityDefinition> resolveItemProviders(
        Iterable<RarityRegistry.ProviderEntry<ItemRarityProvider>> providers, RarityContext context
    ) {
        for (RarityRegistry.ProviderEntry<ItemRarityProvider> entry : providers) {
            Optional<RarityDefinition> result = entry.provider().resolve(context, registry);
            if (result.isPresent()) return result;
        }
        return Optional.empty();
    }

    private RarityDefinition known(RarityDefinition definition) {
        return registry.definition(definition.id()).orElseGet(registry::fallback);
    }

    private void ensureDefaults() {
        if (bootstrapDefaults) ModRarities.bootstrap();
    }
}
