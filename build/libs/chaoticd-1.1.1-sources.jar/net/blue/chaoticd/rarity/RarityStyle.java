package net.blue.chaoticd.rarity;

import net.minecraft.class_2583;
import net.minecraft.class_2960;

/**
 * Optional typography overrides owned by a rarity definition.
 *
 * <p>A {@code null} flag means "preserve the component's existing value". This is important for
 * custom names, curses, hover events and text supplied by other mods: rarity styling changes only
 * the properties it explicitly owns.</p>
 */
public record RarityStyle(
    Boolean bold,
    Boolean italic,
    Boolean underlined,
    Boolean strikethrough,
    class_2960 font,
    boolean gradientByCodePoint
) {
    public static final RarityStyle PRESERVE = new RarityStyle(null, null, null, null, null, false);
    public static final RarityStyle PRESERVE_WITH_GRADIENT =
        new RarityStyle(null, null, null, null, null, true);

    /** Applies the rarity-owned fields while retaining every unrelated part of the original style. */
    public class_2583 apply(class_2583 original, int color) {
        class_2583 result = original.method_36139(color);
        if (bold != null) result = result.method_10982(bold);
        if (italic != null) result = result.method_10978(italic);
        if (underlined != null) result = result.method_30938(underlined);
        if (strikethrough != null) result = result.method_36140(strikethrough);
        if (font != null) result = result.method_27704(font);
        return result;
    }
}
