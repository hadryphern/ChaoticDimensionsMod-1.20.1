package net.blue.chaoticd.gameplay;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.blue.chaoticd.content.ModEnchantments;
import net.blue.chaoticd.content.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5819;

/**
 * Initializes special gear only after it actually enters a player inventory.
 *
 * <p>This keeps Creative Mode search results clean while preserving the
 * intended Sapphire kit and the controlled Emerald enchantment rolls.</p>
 */
public final class ChaoticGearInitialization {
    private static final String INITIALIZED_TAG =
        "chaoticdGearInitialized";

    private static final String EMERALD_VERSION_TAG =
        "chaoticdEmeraldGearVersion";

    /*
     * Version 2 removes the old level X/XV enchantment lottery and replaces it
     * with at most two ordinary vanilla-level enchantments.
     */
    private static final int CURRENT_EMERALD_VERSION = 2;

    private static final int CHECK_INTERVAL_TICKS = 5;
    private static final int MAX_SELECTION_ATTEMPTS = 32;

    private ChaoticGearInitialization() {
    }

    public static void initialize() {
        ServerTickEvents.END_WORLD_TICK.register(
            ChaoticGearInitialization::tickWorld
        );
    }

    private static void tickWorld(
        class_3218 level
    ) {
        if (
            level.method_8510()
                % CHECK_INTERVAL_TICKS
                != 0L
        ) {
            return;
        }

        for (
            class_3222 player :
                level.method_18456()
        ) {
            boolean changed = false;

            for (
                int slot = 0;
                slot
                    < player.method_31548()
                        .method_5439();
                slot++
            ) {
                class_1799 stack =
                    player.method_31548()
                        .method_5438(slot);

                changed |=
                    initializeStack(
                        stack,
                        level.method_8409()
                    );
            }

            class_1799 carried =
                player.field_7512
                    .method_34255();

            changed |=
                initializeStack(
                    carried,
                    level.method_8409()
                );

            if (changed) {
                player.method_31548()
                    .method_5431();

                player.field_7512
                    .method_7623();
            }
        }
    }

    private static boolean initializeStack(
        class_1799 stack,
        class_5819 random
    ) {
        if (stack.method_7960()) {
            return false;
        }

        /*
         * Emerald gear uses a version tag so equipment created before this
         * rebalance is automatically cleaned and rolled again exactly once.
         */
        if (ModItems.isEmeraldGear(stack)) {
            class_2487 tag =
                stack.method_7948();

            if (
                tag.method_10550(
                    EMERALD_VERSION_TAG
                )
                    >= CURRENT_EMERALD_VERSION
            ) {
                return false;
            }

            initializeEmerald(
                stack,
                random
            );

            tag =
                stack.method_7948();

            tag.method_10569(
                EMERALD_VERSION_TAG,
                CURRENT_EMERALD_VERSION
            );

            tag.method_10556(
                INITIALIZED_TAG,
                true
            );

            return true;
        }

        if (!ModItems.isSapphireGear(stack)) {
            return false;
        }

        class_2487 tag =
            stack.method_7948();

        if (
            tag.method_10577(
                INITIALIZED_TAG
            )
        ) {
            return false;
        }

        initializeSapphire(stack);

        stack.method_7948()
            .method_10556(
                INITIALIZED_TAG,
                true
            );

        return true;
    }

    private static void initializeSapphire(
        class_1799 stack
    ) {
        if (
            stack.method_31574(
                ModItems.SAPPHIRE_SWORD
            )
        ) {
            stack.method_7978(
                ModEnchantments.SAPPHIRIC,
                1
            );

            stack.method_7978(
                ModEnchantments.DHEATHIC,
                1
            );

            return;
        }

        stack.method_7978(
            class_1893.field_9131,
            50
        );

        stack.method_7978(
            class_1893.field_9119,
            50
        );

        if (
            stack.method_31574(
                ModItems.SAPPHIRE_PICKAXE
            )
                || stack.method_31574(
                    ModItems.SAPPHIRE_AXE
                )
        ) {
            stack.method_7978(
                class_1893.field_9130,
                50
            );
        }

        if (
            stack.method_31574(
                ModItems.SAPPHIRE_AXE
            )
        ) {
            stack.method_7978(
                class_1893.field_9118,
                50
            );
        }
    }

    private static void initializeEmerald(
        class_1799 stack,
        class_5819 random
    ) {
        /*
         * Remove the old lottery enchantments from equipment generated by the
         * previous system. RepairCost is removed as well so the cleaned item
         * does not retain an unfair anvil penalty.
         */
        class_2487 tag =
            stack.method_7948();

        tag.method_10551("Enchantments");
        tag.method_10551("RepairCost");

        /*
         * Luck V remains the defining guaranteed enchantment of all Emerald
         * tools and armor pieces.
         */
        stack.method_7978(
            ModEnchantments.LUCK,
            5
        );

        int additionalEnchantments =
            rollAdditionalEnchantmentCount(
                random
            );

        if (additionalEnchantments == 0) {
            return;
        }

        List<class_1887> pool =
            emeraldEnchantmentPool(stack);

        if (pool.isEmpty()) {
            return;
        }

        Set<class_1887> selected =
            new LinkedHashSet<>();

        int attempts = 0;

        while (
            selected.size()
                < additionalEnchantments
                && attempts
                < MAX_SELECTION_ATTEMPTS
        ) {
            attempts++;

            class_1887 candidate =
                pool.get(
                    random.method_43048(
                        pool.size()
                    )
                );

            if (
                !isCompatibleSelection(
                    candidate,
                    selected
                )
            ) {
                continue;
            }

            selected.add(candidate);
        }

        for (
            class_1887 enchantment :
                selected
        ) {
            int maximumLevel =
                Math.max(
                    1,
                    enchantment.method_8183()
                );

            int level =
                1
                    + random.method_43048(
                        maximumLevel
                    );

            stack.method_7978(
                enchantment,
                level
            );
        }
    }

    /**
     * Emerald equipment can receive:
     *
     * <ul>
     *     <li>50% chance of no additional enchantment.</li>
     *     <li>40% chance of one ordinary enchantment.</li>
     *     <li>10% chance of two ordinary enchantments.</li>
     * </ul>
     */
    private static int rollAdditionalEnchantmentCount(
        class_5819 random
    ) {
        int roll =
            random.method_43048(100);

        if (roll < 50) {
            return 0;
        }

        if (roll < 90) {
            return 1;
        }

        return 2;
    }

    /**
     * Returns a small item-specific pool containing only ordinary enchantments.
     *
     * <p>There are no level X/XV rolls, curses, Mending, specialized damage
     * enchantments or combinations with five random effects.</p>
     */
    private static List<class_1887> emeraldEnchantmentPool(
        class_1799 stack
    ) {
        List<class_1887> pool =
            new ArrayList<>();

        if (
            stack.method_31574(
                ModItems.EMERALD_SWORD
            )
        ) {
            pool.add(
                class_1893.field_9118
            );

            pool.add(
                class_1893.field_9119
            );

            pool.add(
                class_1893.field_9110
            );

            pool.add(
                class_1893.field_9121
            );

            pool.add(
                class_1893.field_9124
            );

            return pool;
        }

        if (
            stack.method_31574(
                ModItems.EMERALD_PICKAXE
            )
                || stack.method_31574(
                    ModItems.EMERALD_SHOVEL
                )
                || stack.method_31574(
                    ModItems.EMERALD_HOE
                )
        ) {
            pool.add(
                class_1893.field_9131
            );

            pool.add(
                class_1893.field_9119
            );

            pool.add(
                class_1893.field_9130
            );

            pool.add(
                class_1893.field_9099
            );

            return pool;
        }

        if (
            stack.method_31574(
                ModItems.EMERALD_AXE
            )
        ) {
            pool.add(
                class_1893.field_9131
            );

            pool.add(
                class_1893.field_9119
            );

            pool.add(
                class_1893.field_9130
            );

            pool.add(
                class_1893.field_9099
            );

            pool.add(
                class_1893.field_9118
            );

            return pool;
        }

        if (
            stack.method_31574(
                ModItems.EMERALD_HELMET
            )
        ) {
            pool.add(
                class_1893.field_9111
            );

            pool.add(
                class_1893.field_9119
            );

            pool.add(
                class_1893.field_9127
            );

            pool.add(
                class_1893.field_9105
            );

            return pool;
        }

        if (
            stack.method_31574(
                ModItems.EMERALD_CHESTPLATE
            )
        ) {
            pool.add(
                class_1893.field_9111
            );

            pool.add(
                class_1893.field_9119
            );

            pool.add(
                class_1893.field_9097
            );

            return pool;
        }

        if (
            stack.method_31574(
                ModItems.EMERALD_LEGGINGS
            )
        ) {
            pool.add(
                class_1893.field_9111
            );

            pool.add(
                class_1893.field_9119
            );

            return pool;
        }

        if (
            stack.method_31574(
                ModItems.EMERALD_BOOTS
            )
        ) {
            pool.add(
                class_1893.field_9111
            );

            pool.add(
                class_1893.field_9119
            );

            pool.add(
                class_1893.field_9129
            );

            pool.add(
                class_1893.field_9128
            );

            return pool;
        }

        return pool;
    }

    private static boolean isCompatibleSelection(
        class_1887 candidate,
        Set<class_1887> selected
    ) {
        if (
            candidate
                == class_1893.field_9130
                && selected.contains(
                    class_1893.field_9099
                )
        ) {
            return false;
        }

        if (
            candidate
                == class_1893.field_9099
                && selected.contains(
                    class_1893.field_9130
                )
        ) {
            return false;
        }

        return true;
    }
}
