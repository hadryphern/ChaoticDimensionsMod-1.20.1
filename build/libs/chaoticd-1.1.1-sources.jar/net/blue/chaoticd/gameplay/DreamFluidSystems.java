package net.blue.chaoticd.gameplay;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.blue.chaoticd.content.ModItems;
import net.blue.chaoticd.content.ModTags;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;

/** Server-side Dream Fluid hazard and Shimmer-style item transformation. */
public final class DreamFluidSystems {
    private static final String START_TIME_TAG = "chaoticdDreamFluidStart";
    private static final String OWNER_TAG = "chaoticdDreamFluidOwner";
    private static final int TRANSFORMATION_TICKS = 100;
    private static final double ITEM_SEARCH_RADIUS = 96.0D;
    private static final double ITEM_HORIZONTAL_DRAG = 0.55D;
    private static final double MAXIMUM_ITEM_SINK_SPEED = -0.010D;

    private DreamFluidSystems() {
    }

    public static void initialize() {
        ServerTickEvents.END_WORLD_TICK.register(DreamFluidSystems::tickWorld);
    }

    private static void tickWorld(class_3218 level) {
        if (level.method_18456().isEmpty()) {
            return;
        }
        killPlayersInsideDreamFluid(level);
        transformItemsInsideDreamFluid(level);
    }

    private static void killPlayersInsideDreamFluid(class_3218 level) {
        for (class_3222 player : level.method_18456()) {
            if (player.method_7325()) {
                continue;
            }

            class_3610 feetFluid = level.method_8316(player.method_24515());
            class_3610 bodyFluid = level.method_8316(player.method_24515().method_10084());

            if (feetFluid.method_15767(ModTags.DREAM_FLUID) || bodyFluid.method_15767(ModTags.DREAM_FLUID)) {
                player.method_5768();
            }
        }
    }

    private static void transformItemsInsideDreamFluid(class_3218 level) {
        Set<UUID> processed = new HashSet<>();

        for (class_3222 observer : level.method_18456()) {
            List<class_1542> items = level.method_8390(
                class_1542.class,
                observer.method_5829().method_1014(ITEM_SEARCH_RADIUS),
                item -> item.method_5805() && isInsideDreamFluid(level, item)
            );

            for (class_1542 item : items) {
                if (!processed.add(item.method_5667())) {
                    continue;
                }
                keepItemSuspended(item);
                processItem(level, item);
            }
        }
    }

    private static boolean isInsideDreamFluid(class_3218 level, class_1542 item) {
        class_2338 position = item.method_24515();
        return level.method_8316(position).method_15767(ModTags.DREAM_FLUID)
            || level.method_8316(position.method_10074()).method_15767(ModTags.DREAM_FLUID);
    }

    private static void keepItemSuspended(class_1542 item) {
        class_243 movement = item.method_18798();
        item.method_18800(
            movement.field_1352 * ITEM_HORIZONTAL_DRAG,
            Math.max(movement.field_1351 * 0.10D, MAXIMUM_ITEM_SINK_SPEED),
            movement.field_1350 * ITEM_HORIZONTAL_DRAG
        );
        item.field_6017 = 0.0F;
    }

    private static void processItem(class_3218 level, class_1542 item) {
        class_1799 input = item.method_6983();
        Transformation preview = transform(input);

        if (preview == null) {
            clearProgress(input);
            return;
        }

        long now = level.method_8510();

        if (!input.method_7948().method_10545(START_TIME_TAG)) {
            input.method_7948().method_10544(START_TIME_TAG, now);
            class_3222 owner = nearestPlayer(level, item);
            if (owner != null) {
                input.method_7948().method_25927(OWNER_TAG, owner.method_5667());
            }
            item.method_6979(input);
            level.method_8396(
                null,
                item.method_24515(),
                class_3417.field_26980,
                class_3419.field_15245,
                0.65F,
                1.45F
            );
            return;
        }

        long start = input.method_7948().method_10537(START_TIME_TAG);

        if ((now - start) % 10L == 0L) {
            level.method_14199(
                class_2398.field_11207,
                item.method_23317(),
                item.method_23318() + 0.25D,
                item.method_23321(),
                3,
                0.15D,
                0.10D,
                0.15D,
                0.01D
            );
            level.method_14199(
                class_2398.field_11249,
                item.method_23317(),
                item.method_23318() + 0.20D,
                item.method_23321(),
                2,
                0.18D,
                0.08D,
                0.18D,
                0.0D
            );
        }

        if (now - start < TRANSFORMATION_TICKS) {
            return;
        }

        Transformation transformation = transform(input);
        if (transformation == null) {
            clearProgress(input);
            item.method_6979(input);
            return;
        }

        class_3222 owner = resolveOwner(level, input);
        if (owner == null) {
            owner = nearestPlayer(level, item);
        }

        double itemX = item.method_23317();
        double itemY = item.method_23318();
        double itemZ = item.method_23321();
        item.method_31472();

        clearProgress(transformation.result());
        clearProgress(transformation.remainder());

        if (owner != null) {
            giveOrDrop(owner, transformation.result());
            giveOrDrop(owner, transformation.remainder());
            owner.field_7512.method_7623();
            level.method_14199(
                class_2398.field_11248,
                owner.method_23317(),
                owner.method_23318() + 1.0D,
                owner.method_23321(),
                12,
                0.35D,
                0.55D,
                0.35D,
                0.04D
            );
            level.method_8396(
                null,
                owner.method_24515(),
                class_3417.field_14709,
                class_3419.field_15248,
                0.55F,
                1.75F
            );
            return;
        }

        spawnResult(level, itemX, itemY, itemZ, transformation.result());
        spawnResult(level, itemX, itemY, itemZ, transformation.remainder());
    }

    /**
     * Complete Dream Fluid transformation table.
     *
     * <ul>
     *     <li>Emerald becomes Emerald Ingot.</li>
     *     <li>Ender Pearl and Eye of Ender become Crystaline See.</li>
     *     <li>Five Diamond Blocks become two Ruby Nuggets.</li>
     * </ul>
     */
    private static Transformation transform(class_1799 input) {
        if (input.method_31574(class_1802.field_8687)) {
            return new Transformation(
                new class_1799(ModItems.EMERALD_INGOT, input.method_7947()),
                class_1799.field_8037
            );
        }

        if (input.method_31574(class_1802.field_8634) || input.method_31574(class_1802.field_8449)) {
            return new Transformation(
                new class_1799(ModItems.CRYSTALINE_SEE, input.method_7947()),
                class_1799.field_8037
            );
        }

        if (input.method_31574(class_1802.field_8603) && input.method_7947() >= 5) {
            class_1799 remainder = input.method_7972();
            remainder.method_7939(input.method_7947() - 5);
            if (remainder.method_7960()) {
                remainder = class_1799.field_8037;
            }
            return new Transformation(
                new class_1799(ModItems.RUBY_NUGGET, 2),
                remainder
            );
        }

        return null;
    }

    private static void giveOrDrop(class_3222 player, class_1799 stack) {
        if (stack.method_7960()) {
            return;
        }
        if (!player.method_31548().method_7394(stack)) {
            player.method_7328(stack, false);
        }
    }

    private static void spawnResult(
        class_3218 level,
        double x,
        double y,
        double z,
        class_1799 stack
    ) {
        if (!stack.method_7960()) {
            level.method_8649(new class_1542(level, x, y, z, stack));
        }
    }

    private static void clearProgress(class_1799 stack) {
        if (stack.method_7960() || !stack.method_7985()) {
            return;
        }
        stack.method_7948().method_10551(START_TIME_TAG);
        stack.method_7948().method_10551(OWNER_TAG);
    }

    private static class_3222 resolveOwner(class_3218 level, class_1799 stack) {
        if (!stack.method_7985() || !stack.method_7948().method_25928(OWNER_TAG)) {
            return null;
        }
        return level.method_8503().method_3760().method_14602(
            stack.method_7948().method_25926(OWNER_TAG)
        );
    }

    private static class_3222 nearestPlayer(class_3218 level, class_1542 item) {
        class_3222 nearest = null;
        double bestDistance = Double.MAX_VALUE;

        for (class_3222 player : level.method_18456()) {
            double distance = player.method_5858(item);
            if (distance < bestDistance) {
                nearest = player;
                bestDistance = distance;
            }
        }
        return nearest;
    }

    private record Transformation(class_1799 result, class_1799 remainder) {
    }
}
