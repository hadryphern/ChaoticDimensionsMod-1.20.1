package net.blue.chaoticd.gameplay;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import net.blue.chaoticd.content.ModEnchantments;
import net.blue.chaoticd.content.ModItems;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1439;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1914;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3489;
import net.minecraft.class_5819;
import net.minecraft.class_7923;

/**
 * Implements the world interactions granted by the hidden Luck enchantment.
 */
public final class EmeraldLuckSystems {
    private static final String OWNER_PREFIX =
        "chaoticd_emerald_owner_";

    private static final int EFFECT_REFRESH_TICKS = 20;
    private static final int VILLAGER_GIFT_INTERVAL_TICKS = 600;
    private static final double VILLAGER_GIFT_RADIUS = 18.0D;
    private static final double GOLEM_COMMAND_RADIUS = 28.0D;
    private static final double GOLEM_FOLLOW_RADIUS = 16.0D;
    private static final double GOLEM_STOP_FOLLOW_RADIUS = 20.0D;

    private static final Map<class_1914, Integer>
        ORIGINAL_SPECIAL_PRICES = new WeakHashMap<>();

    private static final List<class_1792> VILLAGER_GIFTS = List.of(
        class_1802.field_8229,
        class_1802.field_8423,
        class_1802.field_8741,
        class_1802.field_8176,
        class_1802.field_8071,
        class_1802.field_8287,
        class_1802.field_8620,
        class_1802.field_8695,
        class_1802.field_8687,
        class_1802.field_8477
    );

    private EmeraldLuckSystems() {
    }

    public static void initialize() {
        PlayerBlockBreakEvents.AFTER.register(
            EmeraldLuckSystems::afterBlockBreak
        );

        UseEntityCallback.EVENT.register(
            EmeraldLuckSystems::useEntity
        );

        AttackEntityCallback.EVENT.register(
            EmeraldLuckSystems::attackEntity
        );

        ServerLivingEntityEvents.ALLOW_DAMAGE.register(
            EmeraldLuckSystems::allowDamage
        );

        ServerTickEvents.END_WORLD_TICK.register(
            EmeraldLuckSystems::tickWorld
        );
    }

    private static void afterBlockBreak(
        class_1937 level,
        net.minecraft.class_1657 player,
        class_2338 pos,
        class_2680 state,
        net.minecraft.class_2586 blockEntity
    ) {
        if (level.field_9236
            || !(player instanceof class_3222 serverPlayer)
            || !hasLuck(serverPlayer)
            || !isOre(state)) {
            return;
        }

        class_5819 random =
            serverPlayer.method_6051();

        class_2248.method_9577(
            level,
            pos,
            new class_1799(
                class_1802.field_8687,
                1 + random.method_43048(5)
            )
        );

        class_2248.method_9577(
            level,
            pos,
            new class_1799(
                class_1802.field_8477,
                1 + random.method_43048(5)
            )
        );
    }

    private static class_1269 useEntity(
        net.minecraft.class_1657 player,
        class_1937 level,
        net.minecraft.class_1268 hand,
        class_1297 entity,
        net.minecraft.class_3966 hitResult
    ) {
        if (entity instanceof class_1646 villager) {
            if (!level.field_9236
                && player instanceof class_3222 serverPlayer) {
                updateVillagerPrices(
                    villager,
                    hasLuck(serverPlayer)
                );
            }

            return class_1269.field_5811;
        }

        if (!(entity instanceof class_1439 golem)) {
            return class_1269.field_5811;
        }

        class_1799 held =
            player.method_5998(hand);

        boolean canBind =
            hasFullEmeraldArmor(player)
                && held.method_31573(class_3489.field_20344);

        boolean canRide =
            held.method_7960()
                && hasLuck(player);

        if (!canBind && !canRide) {
            return class_1269.field_5811;
        }

        if (level.field_9236) {
            return class_1269.field_5812;
        }

        if (canBind) {
            setOwner(golem, player.method_5667());

            if (!player.method_31549().field_7477) {
                held.method_7934(1);
            }

            if (level instanceof class_3218 serverLevel) {
                serverLevel.method_14199(
                    class_2398.field_11201,
                    golem.method_23317(),
                    golem.method_23318() + 1.8D,
                    golem.method_23321(),
                    12,
                    0.45D,
                    0.55D,
                    0.45D,
                    0.03D
                );
            }

            return class_1269.field_21466;
        }

        player.method_5873(golem, true);
        return class_1269.field_5812;
    }

    private static class_1269 attackEntity(
        net.minecraft.class_1657 player,
        class_1937 level,
        net.minecraft.class_1268 hand,
        class_1297 entity,
        net.minecraft.class_3966 hitResult
    ) {
        if (level.field_9236
            || !(player instanceof class_3222 serverPlayer)
            || !(entity instanceof class_1309 target)
            || !hasLuck(serverPlayer)) {
            return class_1269.field_5811;
        }

        class_238 search =
            serverPlayer.method_5829().method_1014(
                GOLEM_COMMAND_RADIUS
            );

        for (
            class_1439 golem :
                level.method_8390(
                    class_1439.class,
                    search,
                    candidate ->
                        isOwner(
                            candidate,
                            serverPlayer.method_5667()
                        )
                )
        ) {
            golem.method_5980(target);
        }

        return class_1269.field_5811;
    }

    private static boolean allowDamage(
        class_1309 entity,
        net.minecraft.class_1282 source,
        float amount
    ) {
        if (!(entity instanceof class_3222 player)
            || !hasLuck(player)) {
            return true;
        }

        class_1297 attacker = source.method_5529();
        class_1297 direct = source.method_5526();

        return !(attacker instanceof class_1439)
            && !(direct instanceof class_1439);
    }

    private static void tickWorld(class_3218 level) {
        if (level.method_8510() % EFFECT_REFRESH_TICKS == 0L) {
            for (class_3222 player : level.method_18456()) {
                refreshEmeraldBootEffects(player);
            }

            tickOwnedGolems(level);
        }

        if (
            level.method_8510()
                % VILLAGER_GIFT_INTERVAL_TICKS
                == 0L
        ) {
            giveVillagerGifts(level);
        }
    }

    private static void refreshEmeraldBootEffects(
        class_3222 player
    ) {
        class_1799 boots =
            player.method_6118(class_1304.field_6166);

        if (!boots.method_31574(ModItems.EMERALD_BOOTS)
            || class_1890.method_8225(
                ModEnchantments.LUCK,
                boots
            ) <= 0) {
            return;
        }

        player.method_6092(
            new net.minecraft.class_1293(
                net.minecraft.class_1294.field_5904,
                40,
                0,
                true,
                false,
                true
            )
        );

        player.method_6092(
            new net.minecraft.class_1293(
                net.minecraft.class_1294.field_5913,
                40,
                0,
                true,
                false,
                true
            )
        );
    }

    private static void giveVillagerGifts(
        class_3218 level
    ) {
        class_5819 random = level.method_8409();

        for (class_3222 player : level.method_18456()) {
            if (!hasLuck(player)) {
                continue;
            }

            class_238 area =
                player.method_5829().method_1014(
                    VILLAGER_GIFT_RADIUS
                );

            List<class_1646> villagers =
                level.method_8390(
                    class_1646.class,
                    area,
                    class_1646::method_5805
                );

            for (class_1646 villager : villagers) {
                class_1792 gift =
                    VILLAGER_GIFTS.get(
                        random.method_43048(
                            VILLAGER_GIFTS.size()
                        )
                    );

                int count =
                    gift == class_1802.field_8477
                        ? 1
                        : 1 + random.method_43048(3);

                villager.method_5775(
                    new class_1799(gift, count)
                );

                level.method_14199(
                    class_2398.field_11211,
                    villager.method_23317(),
                    villager.method_23318() + 1.4D,
                    villager.method_23321(),
                    5,
                    0.25D,
                    0.35D,
                    0.25D,
                    0.0D
                );
            }
        }
    }

    private static void updateVillagerPrices(
        class_1646 villager,
        boolean lucky
    ) {
        for (class_1914 offer : villager.method_8264()) {
            if (!offer.method_8246().method_31574(class_1802.field_8687)) {
                continue;
            }

            if (lucky) {
                ORIGINAL_SPECIAL_PRICES.putIfAbsent(
                    offer,
                    offer.method_19277()
                );

                int currentCount =
                    offer.method_19272().method_7947();

                offer.method_19273(
                    offer.method_19277()
                        + 1
                        - currentCount
                );
            } else {
                Integer original =
                    ORIGINAL_SPECIAL_PRICES.remove(offer);

                if (original != null) {
                    offer.method_19273(original);
                }
            }
        }
    }

    private static void tickOwnedGolems(
        class_3218 level
    ) {
        Set<UUID> processed = new java.util.HashSet<>();

        for (class_3222 observer : level.method_18456()) {
            class_238 area =
                observer.method_5829().method_1014(
                    GOLEM_STOP_FOLLOW_RADIUS + 12.0D
                );

            for (
                class_1439 golem :
                    level.method_8390(
                        class_1439.class,
                        area,
                        candidate ->
                            ownerUuid(candidate) != null
                    )
            ) {
                if (!processed.add(golem.method_5667())) {
                    continue;
                }

                UUID ownerUuid =
                    ownerUuid(golem);

                if (ownerUuid == null) {
                    continue;
                }

                class_3222 owner =
                    level.method_8503()
                        .method_3760()
                        .method_14602(ownerUuid);

                if (owner == null
                    || owner.method_37908() != level) {
                    golem.method_5942().method_6340();
                    continue;
                }

                if (
                    golem.method_5968()
                        instanceof class_3222 target
                        && hasLuck(target)
                ) {
                    golem.method_5980(null);
                }

                double distance =
                    golem.method_5739(owner);

                if (distance <= 3.0D) {
                    golem.method_5942().method_6340();
                } else if (
                    distance <= GOLEM_FOLLOW_RADIUS
                ) {
                    golem.method_5942().method_6335(
                        owner,
                        1.10D
                    );
                } else if (
                    distance > GOLEM_STOP_FOLLOW_RADIUS
                ) {
                    golem.method_5942().method_6340();
                }
            }
        }
    }

    public static boolean hasLuck(
        net.minecraft.class_1657 player
    ) {
        for (class_1799 stack : player.method_5743()) {
            if (
                class_1890.method_8225(
                    ModEnchantments.LUCK,
                    stack
                ) > 0
            ) {
                return true;
            }
        }

        return false;
    }

    private static boolean hasFullEmeraldArmor(
        net.minecraft.class_1657 player
    ) {
        return player.method_6118(class_1304.field_6169)
                .method_31574(ModItems.EMERALD_HELMET)
            && player.method_6118(class_1304.field_6174)
                .method_31574(ModItems.EMERALD_CHESTPLATE)
            && player.method_6118(class_1304.field_6172)
                .method_31574(ModItems.EMERALD_LEGGINGS)
            && player.method_6118(class_1304.field_6166)
                .method_31574(ModItems.EMERALD_BOOTS);
    }

    private static boolean isOre(
        class_2680 state
    ) {
        String path =
            class_7923.field_41175.method_10221(
                state.method_26204()
            ).method_12832();

        return path.endsWith("_ore")
            || path.contains("_ore_");
    }

    private static void setOwner(
        class_1439 golem,
        UUID owner
    ) {
        List<String> oldOwnerTags =
            new ArrayList<>();

        for (String tag : golem.method_5752()) {
            if (tag.startsWith(OWNER_PREFIX)) {
                oldOwnerTags.add(tag);
            }
        }

        for (String tag : oldOwnerTags) {
            golem.method_5738(tag);
        }

        golem.method_5780(
            OWNER_PREFIX + owner
        );
    }

    private static boolean isOwner(
        class_1439 golem,
        UUID player
    ) {
        UUID owner =
            ownerUuid(golem);

        return owner != null
            && owner.equals(player);
    }

    private static UUID ownerUuid(
        class_1439 golem
    ) {
        for (String tag : golem.method_5752()) {
            if (!tag.startsWith(OWNER_PREFIX)) {
                continue;
            }

            try {
                return UUID.fromString(
                    tag.substring(
                        OWNER_PREFIX.length()
                    )
                );
            } catch (IllegalArgumentException ignored) {
                return null;
            }
        }

        return null;
    }
}
