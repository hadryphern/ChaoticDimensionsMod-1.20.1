package net.blue.chaoticd.client.visual;

import net.minecraft.class_243;
import net.minecraft.class_5294;

/** Aurora-specific fog response while retaining Minecraft's stable normal-sky renderer. */
public final class AuroraDimensionEffects extends class_5294 {
    public AuroraDimensionEffects(float cloudHeight) {
        super(cloudHeight, true, class_5401.field_25640, false, false);
    }

    @Override
    public class_243 method_28112(class_243 fogColor, float brightness) {
        double red = brightness * 0.92F + 0.08F;
        double green = brightness * 0.88F + 0.12F;
        double blue = brightness * 0.94F + 0.06F;
        return fogColor.method_18805(red, green, blue);
    }

    @Override
    public boolean method_28110(int x, int z) {
        return false;
    }
}
