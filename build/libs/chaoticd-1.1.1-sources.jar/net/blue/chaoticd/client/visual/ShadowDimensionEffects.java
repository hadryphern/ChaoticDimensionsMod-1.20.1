package net.blue.chaoticd.client.visual;

import net.minecraft.class_243;
import net.minecraft.class_5294;

/**
 * Shadow-specific visual response.
 *
 * <p>The dimension has no normal sky or clouds and is always treated as foggy,
 * creating the short, oppressive view distance requested for the biome.</p>
 */
public final class ShadowDimensionEffects extends class_5294 {
    public ShadowDimensionEffects() {
        super(Float.NaN, true, class_5401.field_25639, false, false);
    }

    @Override
    public class_243 method_28112(class_243 fogColor, float brightness) {
        double factor = 0.10D + brightness * 0.16D;
        return fogColor.method_18805(factor, factor * 0.78D, factor * 1.08D);
    }

    @Override
    public boolean method_28110(int x, int z) {
        return true;
    }
}
