package net.blue.chaoticd.client.visual;

import net.blue.chaoticd.ChaoticDimensions;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/** Client-only identifiers and atmospheric tuning for the Shadow Dimension. */
public final class ShadowVisualConfig {
    public static final class_5321<class_1937> SHADOW_DIMENSION = class_5321.method_29179(
        class_7924.field_41223,
        id("shadow_dimension")
    );

    public static final class_2960 DIMENSION_EFFECTS = id("shadow");

    private ShadowVisualConfig() {
    }

    private static class_2960 id(String path) {
        return new class_2960(ChaoticDimensions.MOD_ID, path);
    }
}
