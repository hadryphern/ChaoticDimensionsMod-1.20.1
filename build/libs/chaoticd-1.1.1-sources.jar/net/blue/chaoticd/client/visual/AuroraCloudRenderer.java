package net.blue.chaoticd.client.visual;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_291;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4063;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.class_758;
import java.util.Objects;

/**
 * Lightweight, Aurora-only cloud renderer intended for registration through
 * {@link DimensionRenderingRegistry#registerCloudRenderer}.
 *
 * <p>The renderer reuses Minecraft's tileable cloud mask, but draws two independently tinted,
 * scaled and moving layers. Geometry is uploaded once and then shifted relative to the camera;
 * no vertex data or temporary collections are rebuilt every frame.</p>
 */
public final class AuroraCloudRenderer implements DimensionRenderingRegistry.CloudRenderer, AutoCloseable {
    private static final class_2960 VANILLA_CLOUD_TEXTURE =
        new class_2960("minecraft", "textures/environment/clouds.png");
    /** Small enough that at least one row remains inside the two-chunk minimum far plane. */
    public static final float GRID_CELL_SIZE = 128.0F;

    private final Settings settings;
    private class_291 primaryBuffer;
    private class_291 secondaryBuffer;
    private boolean closed;

    public AuroraCloudRenderer(Settings settings) {
        this.settings = Objects.requireNonNull(settings, "settings");
    }

    public AuroraCloudRenderer() {
        this(Settings.defaults());
    }

    public Settings settings() {
        return settings;
    }

    @Override
    public void render(WorldRenderContext context) {
        Objects.requireNonNull(context, "context");
        if (closed || class_310.method_1551().field_1690.method_1632() == class_4063.field_18162) {
            return;
        }

        ensureBuffers();
        if (primaryBuffer == null || secondaryBuffer == null) {
            return;
        }

        context.profiler().method_15396("chaoticd_aurora_clouds");
        try {
            prepareRenderState();

            class_243 cameraPosition = context.camera().method_19326();
            double cameraX = cameraPosition.field_1352;
            double cameraY = cameraPosition.field_1351;
            double cameraZ = cameraPosition.field_1350;
            double timeSeconds = (context.world().method_8510() + context.tickDelta()) / 20.0D;
            CloudLayer primary = settings.primary();
            CloudLayer secondary = settings.secondary();

            // Translucent layers are rendered back-to-front from any camera altitude.
            if (Math.abs(primary.height() - cameraY) >= Math.abs(secondary.height() - cameraY)) {
                renderLayer(context, primary, primaryBuffer, timeSeconds, cameraX, cameraY, cameraZ);
                renderLayer(context, secondary, secondaryBuffer, timeSeconds, cameraX, cameraY, cameraZ);
            } else {
                renderLayer(context, secondary, secondaryBuffer, timeSeconds, cameraX, cameraY, cameraZ);
                renderLayer(context, primary, primaryBuffer, timeSeconds, cameraX, cameraY, cameraZ);
            }
        } finally {
            restoreRenderState();
            context.profiler().method_15407();
        }
    }

    private void ensureBuffers() {
        if (primaryBuffer == null) {
            primaryBuffer = createLayerBuffer(settings.primary());
        }
        if (secondaryBuffer == null) {
            secondaryBuffer = createLayerBuffer(settings.secondary());
        }
    }

    private static class_291 createLayerBuffer(CloudLayer layer) {
        class_287 builder = class_289.method_1348().method_1349();
        builder.method_1328(class_293.class_5596.field_27382, class_290.field_1577);

        float extent = layer.halfExtent();
        int cellsPerSide = cellsPerSide(layer);
        float cellSize = extent * 2.0F / cellsPerSide;
        for (int zCell = 0; zCell < cellsPerSide; zCell++) {
            float z0 = -extent + zCell * cellSize;
            float z1 = z0 + cellSize;
            for (int xCell = 0; xCell < cellsPerSide; xCell++) {
                float x0 = -extent + xCell * cellSize;
                float x1 = x0 + cellSize;
                addVertex(builder, x0, z0, x0 / layer.texturePeriod(), z0 / layer.texturePeriod());
                addVertex(builder, x0, z1, x0 / layer.texturePeriod(), z1 / layer.texturePeriod());
                addVertex(builder, x1, z1, x1 / layer.texturePeriod(), z1 / layer.texturePeriod());
                addVertex(builder, x1, z0, x1 / layer.texturePeriod(), z0 / layer.texturePeriod());
            }
        }

        class_291 buffer = new class_291(class_291.class_8555.field_44793);
        buffer.method_1353();
        buffer.method_1352(builder.method_1326());
        class_291.method_1354();
        return buffer;
    }

    public static int cellsPerSide(CloudLayer layer) {
        return (int)Math.ceil(layer.halfExtent() * 2.0F / GRID_CELL_SIZE);
    }

    public static int vertexCount(CloudLayer layer) {
        int cells = cellsPerSide(layer);
        return cells * cells * 4;
    }

    private static void addVertex(class_287 builder, float x, float z, float u, float v) {
        builder.method_22912(x, 0.0F, z)
            .method_22913(u, v)
            .method_22915(1.0F, 1.0F, 1.0F, 1.0F)
            .method_22914(0.0F, 1.0F, 0.0F)
            .method_1344();
    }

    private static void prepareRenderState() {
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.blendFuncSeparate(
            GlStateManager.class_4535.SRC_ALPHA,
            GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA,
            GlStateManager.class_4535.ONE,
            GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA
        );
        RenderSystem.setShader(class_757::method_34549);
        RenderSystem.setShaderTexture(0, VANILLA_CLOUD_TEXTURE);
        class_758.method_3212();
    }

    private static void renderLayer(
        WorldRenderContext context,
        CloudLayer layer,
        class_291 buffer,
        double timeSeconds,
        double cameraX,
        double cameraY,
        double cameraZ
    ) {
        class_5944 shader = RenderSystem.getShader();
        if (shader == null) {
            return;
        }

        // Anchors the repeating texture in world space while applying a subtle continuous drift.
        double phaseX = centeredModulo(cameraX - timeSeconds * layer.speedX(), layer.texturePeriod());
        double phaseZ = centeredModulo(cameraZ - timeSeconds * layer.speedZ(), layer.texturePeriod());

        class_4587 matrices = context.matrixStack();
        matrices.method_22903();
        try {
            matrices.method_22904(-phaseX, layer.height() - cameraY, -phaseZ);
            RenderSystem.setShaderColor(layer.red(), layer.green(), layer.blue(), layer.opacity());
            buffer.method_1353();
            buffer.method_34427(matrices.method_23760().method_23761(), context.projectionMatrix(), shader);
            class_291.method_1354();
        } finally {
            matrices.method_22909();
        }
    }

    static double positiveModulo(double value, double modulus) {
        double result = value % modulus;
        return result < 0.0D ? result + modulus : result;
    }

    static double centeredModulo(double value, double modulus) {
        return positiveModulo(value + modulus * 0.5D, modulus) - modulus * 0.5D;
    }

    private static void restoreRenderState() {
        class_291.method_1354();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    /** Releases the two GPU buffers. Call from the render thread or during client shutdown. */
    @Override
    public void close() {
        if (closed) {
            return;
        }
        closed = true;

        if (!RenderSystem.isOnRenderThread()) {
            RenderSystem.recordRenderCall(this::closeBuffers);
        } else {
            closeBuffers();
        }
    }

    private void closeBuffers() {
        if (primaryBuffer != null) {
            primaryBuffer.close();
            primaryBuffer = null;
        }
        if (secondaryBuffer != null) {
            secondaryBuffer.close();
            secondaryBuffer = null;
        }
    }

    /** Drops GPU state after a renderer reload and recreates it lazily on the next frame. */
    public void invalidate() {
        if (closed) return;
        if (!RenderSystem.isOnRenderThread()) {
            RenderSystem.recordRenderCall(this::closeBuffers);
        } else {
            closeBuffers();
        }
    }

    /** Two-layer cloud settings kept immutable so they are safe to share from a visual config. */
    public record Settings(CloudLayer primary, CloudLayer secondary) {
        public Settings {
            Objects.requireNonNull(primary, "primary");
            Objects.requireNonNull(secondary, "secondary");
        }

        public static Settings defaults() {
            return new Settings(
                new CloudLayer(326.0F, 1_440.0F, 4_096.0F,
                    1.00F, 0.90F, 0.96F, 0.62F, 0.28F, 0.05F),
                new CloudLayer(364.0F, 1_040.0F, 4_096.0F,
                    0.94F, 0.84F, 1.00F, 0.28F, -0.12F, 0.20F)
            );
        }
    }

    /**
     * @param height absolute world height of this layer
     * @param texturePeriod world-space blocks occupied by one repeat of the cloud mask
     * @param halfExtent half-width of the rendered plane; keep comfortably beyond view distance
     * @param red red tint multiplier from 0 to 1
     * @param green green tint multiplier from 0 to 1
     * @param blue blue tint multiplier from 0 to 1
     * @param opacity layer opacity from 0 to 1
     * @param speedX horizontal drift in blocks per second
     * @param speedZ horizontal drift in blocks per second
     */
    public record CloudLayer(
        float height,
        float texturePeriod,
        float halfExtent,
        float red,
        float green,
        float blue,
        float opacity,
        float speedX,
        float speedZ
    ) {
        public CloudLayer {
            requireFinite(height, "height");
            requireFinite(speedX, "speedX");
            requireFinite(speedZ, "speedZ");
            if (!Float.isFinite(texturePeriod) || texturePeriod < 128.0F) {
                throw new IllegalArgumentException("texturePeriod must be finite and at least 128 blocks");
            }
            if (!Float.isFinite(halfExtent) || halfExtent < texturePeriod * 1.5F) {
                throw new IllegalArgumentException("halfExtent must cover at least 1.5 texture periods");
            }
            requireUnit(red, "red");
            requireUnit(green, "green");
            requireUnit(blue, "blue");
            requireUnit(opacity, "opacity");
        }

        private static void requireFinite(float value, String name) {
            if (!Float.isFinite(value)) {
                throw new IllegalArgumentException(name + " must be finite");
            }
        }

        private static void requireUnit(float value, String name) {
            if (!Float.isFinite(value) || value < 0.0F || value > 1.0F) {
                throw new IllegalArgumentException(name + " must be between 0 and 1");
            }
        }
    }
}
