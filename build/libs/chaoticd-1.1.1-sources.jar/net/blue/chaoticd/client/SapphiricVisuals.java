package net.blue.chaoticd.client;

import net.blue.chaoticd.content.ModEffects;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;

/** Purple screen veil for the local player while the Sapphiric effect is active. */
public final class SapphiricVisuals {
    private SapphiricVisuals() {
    }

    public static void initialize() {
        HudRenderCallback.EVENT.register((graphics, tickDelta) -> {
            var player = class_310.method_1551().field_1724;
            if (player == null || !player.method_6059(ModEffects.SAPPHIRIC)) {
                return;
            }
            int alpha = 68 + (player.field_6012 / 5 % 2) * 16;
            graphics.method_25294(0, 0, graphics.method_51421(), graphics.method_51443(), (alpha << 24) | 0x61169E);
        });
    }
}
