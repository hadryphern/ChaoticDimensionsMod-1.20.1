package net.blue.chaoticd.client.rarity;

import java.util.Objects;
import java.util.Optional;
import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.rarity.RarityDefinition;
import net.blue.chaoticd.rarity.RarityStyle;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_5348;

/** Component-safe rarity styling used only from client mixins and client compatibility facades. */
public final class TooltipRarityRenderer {
    private static final TooltipRarityRenderer GLOBAL =
        new TooltipRarityRenderer(AnimatedColorProvider.global());

    private final AnimatedColorProvider colors;

    public TooltipRarityRenderer(AnimatedColorProvider colors) {
        this.colors = Objects.requireNonNull(colors, "colors");
    }

    public static TooltipRarityRenderer global() {
        return GLOBAL;
    }

    public class_2561 style(class_2561 source, RarityDefinition definition) {
        return styleAt(source, definition, colors.nowNanos());
    }

    public class_2561 styleAt(class_2561 source, RarityDefinition definition, long nowNanos) {
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(definition, "definition");
        if (!definition.style().gradientByCodePoint()) {
            int color = colors.colorAt(definition, nowNanos, 0, 1);
            return copyUniform(source, definition, color);
        }
        return copyGradient(source, definition, nowNanos);
    }

    /** Compatibility path for the old public RarityText.gradient API. */
    public class_2561 customGradient(class_2561 source, int... palette) {
        if (palette == null || palette.length == 0) return source.method_27661();
        if (palette.length == 1) return copyWithColor(source, palette[0]);
        RarityDefinition temporary = RarityDefinition.builder(
                new class_2960(ChaoticDimensions.MOD_ID, "compatibility_gradient"),
                "rarity.chaoticd.common", palette[0])
            .paletteAnimation(3_600L, RarityDefinition.Easing.SMOOTHSTEP, palette)
            .style(RarityStyle.PRESERVE_WITH_GRADIENT)
            .build();
        return style(source, temporary);
    }

    public static class_2561 copyWithColor(class_2561 source, int color) {
        class_5250 result = source.method_27662().method_10862(source.method_10866().method_36139(color));
        for (class_2561 sibling : source.method_10855()) result.method_10852(copyWithColor(sibling, color));
        return result;
    }

    private class_2561 copyUniform(class_2561 source, RarityDefinition definition, int color) {
        class_5250 result = source.method_27662()
            .method_10862(definition.style().apply(source.method_10866(), color));
        for (class_2561 sibling : source.method_10855()) {
            result.method_10852(copyUniform(sibling, definition, color));
        }
        return result;
    }

    private class_2561 copyGradient(class_2561 source, RarityDefinition definition, long nowNanos) {
        class_5250 result = class_2561.method_43473();
        String renderedText = source.getString();
        int totalCodePoints = Math.max(1, renderedText.codePointCount(0, renderedText.length()));
        int[] codePointIndex = {0};
        class_5348.class_5246<Void> visitor = (originalStyle, text) -> {
            text.codePoints().forEachOrdered(codePoint -> {
                int color = colors.colorAt(definition, nowNanos, codePointIndex[0]++, totalCodePoints);
                class_2583 styled = definition.style().apply(originalStyle, color);
                result.method_10852(class_2561.method_43470(new String(Character.toChars(codePoint))).method_10862(styled));
            });
            return Optional.empty();
        };
        source.method_27658(visitor, class_2583.field_24360);
        return result;
    }
}
