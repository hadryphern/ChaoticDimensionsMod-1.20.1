package net.blue.chaoticd.client.rarity;

import java.util.List;
import net.blue.chaoticd.rarity.RarityDefinition;
import net.blue.chaoticd.rarity.RarityResolver;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Shared exact NBT-to-tooltip-line mapping for normal items and enchanted books. */
public final class TooltipEnchantmentStyler {
    private TooltipEnchantmentStyler() {
    }

    public static void appendAndStyle(class_1799 stack, List<class_2561> lines, class_2499 enchantmentTags) {
        int firstAddedLine = lines.size();
        class_1799.method_17870(lines, enchantmentTags);
        styleExisting(stack, lines, enchantmentTags, firstAddedLine,
            AnimatedColorProvider.global().nowNanos());
    }

    public static void styleExisting(class_1799 stack, List<class_2561> lines, class_2499 enchantmentTags,
                                     int firstLine, long nowNanos) {
        if (firstLine >= lines.size()) return;
        RarityResolver resolver = RarityResolver.global();
        TooltipRarityRenderer renderer = TooltipRarityRenderer.global();
        int lineIndex = firstLine;

        for (int tagIndex = 0; tagIndex < enchantmentTags.size() && lineIndex < lines.size(); tagIndex++) {
            class_2487 tag = enchantmentTags.method_10602(tagIndex);
            class_2960 enchantmentId = class_1890.method_37427(tag);
            if (enchantmentId == null) continue;
            class_1887 enchantment = class_7923.field_41176.method_17966(enchantmentId).orElse(null);
            if (enchantment == null) continue;

            int level = class_1890.method_37424(tag);
            RarityDefinition rarity = resolver.resolveEnchantment(stack, enchantment, level);
            lines.set(lineIndex, renderer.styleAt(lines.get(lineIndex), rarity, nowNanos));
            lineIndex++;
        }
    }
}
