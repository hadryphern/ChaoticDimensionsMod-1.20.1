package net.blue.chaoticd.client.entity;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.entity.LegacyAnimatedMob;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

/** Reads the original GeckoLib geometry, texture and animation resources. */
public final class LegacyMobModel<T extends class_1297 & LegacyAnimatedMob> extends GeoModel<T> {
    @Override
    public class_2960 getModelResource(T animatable) {
        return new class_2960(ChaoticDimensions.MOD_ID, animatable.variant().model());
    }

    @Override
    public class_2960 getTextureResource(T animatable) {
        return new class_2960(ChaoticDimensions.MOD_ID, animatable.variant().texture());
    }

    @Override
    public class_2960 getAnimationResource(T animatable) {
        return new class_2960(ChaoticDimensions.MOD_ID, animatable.variant().animation());
    }
}
