package net.blue.chaoticd.client.entity;

import net.blue.chaoticd.content.entity.LegacyAnimatedMob;
import net.minecraft.class_1297;
import net.minecraft.class_5617;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Shared renderer for every restored GeckoLib legacy creature. */
public final class LegacyMobRenderer<T extends class_1297 & LegacyAnimatedMob> extends GeoEntityRenderer<T> {
    public LegacyMobRenderer(class_5617.class_5618 context) {
        super(context, new LegacyMobModel<>());
        this.field_4673 = 0.5F;
    }
}
