package net.blue.chaoticd.mixin;

import net.blue.chaoticd.content.ModCombatEnchantments;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Keeps the server-side interaction validation in step with the custom sword reach. */
@Mixin(class_3244.class)
public abstract class ServerGamePacketListenerImplMixin {
    @Shadow public class_3222 player;

    @Redirect(method = "handleInteract", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/world/phys/AABB;distanceToSqr(Lnet/minecraft/world/phys/Vec3;)D"))
    private double chaoticd$scaleInteractionDistanceForSwordReach(class_238 targetBounds, class_243 eyePosition) {
        double actualSquaredDistance = targetBounds.method_49271(eyePosition);
        float reach = ModCombatEnchantments.attackReach(player.method_6047());
        // Vanilla compares this value to a fixed 36.0 (six blocks); normalize our custom reach to it.
        return reach > 0.0F ? actualSquaredDistance * 36.0D / (reach * reach) : actualSquaredDistance;
    }
}
