package net.blue.chaoticd.mixin;

import java.util.List;
import net.blue.chaoticd.client.rarity.AnimatedColorProvider;
import net.blue.chaoticd.client.rarity.TooltipEnchantmentStyler;
import net.minecraft.class_1772;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Styles StoredEnchantments at their creation site; normal item enchantments are handled separately. */
@Mixin(class_1772.class)
public abstract class EnchantedBookTooltipMixin {
    @Unique
    private int chaoticd$firstBookEnchantmentLine;

    @Inject(method = "appendHoverText", at = @At("HEAD"))
    private void chaoticd$captureFirstBookLine(class_1799 stack, class_1937 level, List<class_2561> lines,
                                                class_1836 flag, CallbackInfo callback) {
        chaoticd$firstBookEnchantmentLine = lines.size();
    }

    @Inject(method = "appendHoverText", at = @At("RETURN"))
    private void chaoticd$styleBookEnchantments(class_1799 stack, class_1937 level, List<class_2561> lines,
                                                 class_1836 flag, CallbackInfo callback) {
        TooltipEnchantmentStyler.styleExisting(stack, lines, class_1772.method_7806(stack),
            chaoticd$firstBookEnchantmentLine, AnimatedColorProvider.global().nowNanos());
    }
}
