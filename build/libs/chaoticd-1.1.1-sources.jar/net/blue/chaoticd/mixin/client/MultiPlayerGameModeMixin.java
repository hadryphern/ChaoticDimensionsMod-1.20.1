package net.blue.chaoticd.mixin.client;

import net.blue.chaoticd.content.ModCombatEnchantments;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets the local crosshair select entities at Big Bertha or Royal range. */
@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "getPickRange", at = @At("RETURN"), cancellable = true)
    private void chaoticd$extendSwordPickRange(CallbackInfoReturnable<Float> callback) {
        var player = class_310.method_1551().field_1724;
        if (player != null) {
            callback.setReturnValue(Math.max(callback.getReturnValue(),
                ModCombatEnchantments.attackReach(player.method_6047())));
        }
    }
}
