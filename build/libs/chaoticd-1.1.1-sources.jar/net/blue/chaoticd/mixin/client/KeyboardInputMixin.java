package net.blue.chaoticd.mixin.client;

import net.blue.chaoticd.content.ModEffects;
import net.minecraft.class_310;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Reorders local movement directions while Sapphiric is active. */
@Mixin(class_743.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void chaoticd$shuffleDirections(boolean slowDown, float slowdownFactor, CallbackInfo callback) {
        var player = class_310.method_1551().field_1724;
        if (player == null || !player.method_6059(ModEffects.SAPPHIRIC)) {
            return;
        }

        class_744 input = (class_744) (Object) this;
        boolean up = input.field_3910;
        boolean down = input.field_3909;
        boolean left = input.field_3908;
        boolean right = input.field_3906;

        switch ((player.field_6012 / 20) % 4) {
            case 0 -> {
                input.field_3910 = left;
                input.field_3906 = up;
                input.field_3909 = right;
                input.field_3908 = down;
            }
            case 1 -> {
                input.field_3910 = right;
                input.field_3906 = down;
                input.field_3909 = left;
                input.field_3908 = up;
            }
            case 2 -> {
                input.field_3910 = down;
                input.field_3906 = left;
                input.field_3909 = up;
                input.field_3908 = right;
            }
            default -> {
                input.field_3910 = left;
                input.field_3906 = down;
                input.field_3909 = right;
                input.field_3908 = up;
            }
        }
        input.field_3905 = (input.field_3910 ? 1.0F : 0.0F) - (input.field_3909 ? 1.0F : 0.0F);
        input.field_3907 = (input.field_3908 ? 1.0F : 0.0F) - (input.field_3906 ? 1.0F : 0.0F);
    }
}
