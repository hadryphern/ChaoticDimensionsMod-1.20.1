package net.blue.chaoticd.mixin.client;

import net.blue.chaoticd.content.ModCombatEnchantments;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Restores an entity target beyond vanilla's three-block anti-reach client clamp. */
@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Inject(method = "pick", at = @At("TAIL"))
    private void chaoticd$pickLongRangeSwordTarget(float partialTick, CallbackInfo callback) {
        class_310 minecraft = class_310.method_1551();
        class_1297 player = minecraft.method_1560();
        if (player == null || minecraft.field_1687 == null || minecraft.field_1724 == null) {
            return;
        }

        float reach = ModCombatEnchantments.attackReach(minecraft.field_1724.method_6047());
        if (reach <= 3.0F) {
            return;
        }

        class_243 eye = player.method_5836(partialTick);
        class_243 direction = player.method_5828(partialTick);
        double maximumReach = reach;
        if (minecraft.field_1765 != null && minecraft.field_1765.method_17783() == class_239.class_240.field_1332) {
            maximumReach = Math.min(maximumReach, eye.method_1022(minecraft.field_1765.method_17784()));
        }
        class_243 end = eye.method_1019(direction.method_1021(maximumReach));
        class_238 searchBox = player.method_5829().method_18804(direction.method_1021(maximumReach)).method_1014(1.0D);
        class_3966 target = class_1675.method_18075(player, eye, end, searchBox,
            candidate -> !candidate.method_7325() && candidate.method_5863(), maximumReach * maximumReach);
        if (target != null) {
            minecraft.field_1765 = target;
            minecraft.field_1692 = target.method_17782();
        }
    }
}
