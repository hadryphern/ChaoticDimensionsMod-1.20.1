package net.blue.chaoticd.mixin;

import net.blue.chaoticd.content.ModEnchantments;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Converts a short real draw into a much stronger draw when Disparada is on the bow. */
@Mixin(net.minecraft.class_1753.class)
public abstract class BowItemMixin {
    private static final ThreadLocal<class_1799> CHAOTICD_ACTIVE_BOW = new ThreadLocal<>();

    @Inject(method = "releaseUsing", at = @At("HEAD"))
    private void chaoticd$rememberBow(class_1799 bow, class_1937 level, class_1309 user, int timeLeft,
                                      CallbackInfo callback) {
        CHAOTICD_ACTIVE_BOW.set(bow);
    }

    @ModifyArg(method = "releaseUsing", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/world/item/BowItem;getPowerForTime(I)F"), index = 0)
    private int chaoticd$accelerateBowCharge(int drawTicks) {
        class_1799 bow = CHAOTICD_ACTIVE_BOW.get();
        if (bow == null) {
            return drawTicks;
        }
        int disparada = class_1890.method_8225(ModEnchantments.DISPARADA, bow);
        int multiplier = switch (disparada) {
            case 1 -> 2;
            case 2 -> 4;
            case 3 -> 6;
            case 4 -> 10;
            case 5 -> 20;
            default -> 1;
        };
        return drawTicks * multiplier;
    }

    @Inject(method = "releaseUsing", at = @At("RETURN"))
    private void chaoticd$forgetBow(class_1799 bow, class_1937 level, class_1309 user, int timeLeft,
                                    CallbackInfo callback) {
        CHAOTICD_ACTIVE_BOW.remove();
    }
}
