package net.blue.chaoticd.mixin;

import java.util.ArrayList;
import java.util.List;
import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Keeps Death Totems inside the old player inventory while every other item is
 * dropped normally. ShadowDimensionSystems copies the retained stack on respawn.
 */
@Mixin(class_1661.class)
public abstract class InventoryDropMixin {
    @Unique
    private List<SavedTotem> chaoticd$savedDeathTotems = List.of();

    @Inject(method = "dropAll", at = @At("HEAD"))
    private void chaoticd$hideDeathTotemsBeforeDrop(CallbackInfo callback) {
        class_1661 inventory = (class_1661)(Object)this;
        List<SavedTotem> saved = new ArrayList<>();

        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            class_1799 stack = inventory.method_5438(slot);

            if (stack.method_31574(ModItems.DEATH_TOTEM)) {
                saved.add(new SavedTotem(slot, stack.method_7972()));
                inventory.method_5447(slot, class_1799.field_8037);
            }
        }

        chaoticd$savedDeathTotems = saved;
    }

    @Inject(method = "dropAll", at = @At("TAIL"))
    private void chaoticd$restoreDeathTotemsAfterDrop(CallbackInfo callback) {
        class_1661 inventory = (class_1661)(Object)this;

        for (SavedTotem saved : chaoticd$savedDeathTotems) {
            inventory.method_5447(saved.slot(), saved.stack());
        }

        chaoticd$savedDeathTotems = List.of();
    }

    @Unique
    private record SavedTotem(int slot, class_1799 stack) {
    }
}
