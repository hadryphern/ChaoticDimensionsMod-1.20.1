package net.blue.chaoticd.mixin;

import net.blue.chaoticd.client.rarity.TooltipRarityRenderer;
import net.blue.chaoticd.rarity.RarityDefinition;
import net.blue.chaoticd.rarity.RarityResolver;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Client-only name styling; copies Components and retains custom-name typography/events. */
@Mixin(class_1799.class)
public abstract class ItemStackNameMixin {
    @Inject(method = "getHoverName", at = @At("RETURN"), cancellable = true)
    private void chaoticd$applyResolvedRarity(CallbackInfoReturnable<class_2561> callback) {
        class_1799 stack = (class_1799) (Object) this;
        RarityDefinition rarity = RarityResolver.global().resolveItem(stack);
        callback.setReturnValue(TooltipRarityRenderer.global().style(callback.getReturnValue(), rarity));
    }
}
