package net.blue.chaoticd.mixin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.blue.chaoticd.client.rarity.TooltipEnchantmentStyler;
import net.blue.chaoticd.client.rarity.TooltipRarityRenderer;
import net.blue.chaoticd.content.ModCombatEnchantments;
import net.blue.chaoticd.rarity.RarityDefinition;
import net.blue.chaoticd.rarity.RarityResolver;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_5134;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Surgical client tooltip integration: every enchantment is styled as its own line when appended. */
@Mixin(class_1799.class)
public abstract class ItemStackTooltipMixin {
    /**
     * Intercepts the vanilla append operation instead of searching localized strings afterwards.
     * Unknown command/NBT enchantments remain untouched and cannot shift subsequent known entries.
     */
    @Redirect(
        method = "getTooltipLines",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/item/ItemStack;appendEnchantmentNames(Ljava/util/List;Lnet/minecraft/nbt/ListTag;)V"
        )
    )
    private void chaoticd$appendIndividuallyStyledEnchantments(List<class_2561> lines, class_2499 enchantmentTags) {
        class_1799 stack = (class_1799) (Object) this;
        TooltipEnchantmentStyler.appendAndStyle(stack, lines, enchantmentTags);
    }

    @Inject(method = "getTooltipLines", at = @At("RETURN"), cancellable = true)
    private void chaoticd$appendIndependentCombatAndRarityLines(class_1657 player, class_1836 flag,
                                                                 CallbackInfoReturnable<List<class_2561>> callback) {
        class_1799 stack = (class_1799) (Object) this;
        float multiplier = ModCombatEnchantments.damageMultiplier(stack);
        float reach = ModCombatEnchantments.attackReach(stack);
        List<class_2561> lines = new ArrayList<>(callback.getReturnValue());

        if (multiplier > 1.0F) {
            String attackDamageName = class_2561.method_43471("attribute.name.generic.attack_damage").getString();
            for (int index = 0; index < lines.size(); index++) {
                if (!lines.get(index).getString().contains(attackDamageName)) continue;
                lines.set(index, class_2561.method_43469("attribute.modifier.plus.0",
                    format(finalAttackDamage(stack, player) * multiplier),
                    class_2561.method_43471("attribute.name.generic.attack_damage"))
                    .method_27692(class_124.field_1064));
                break;
            }
        }

        if (reach > 0.0F) {
            lines.add(class_2561.method_43469("attribute.modifier.plus.0", format(reach),
                class_2561.method_43471("tooltip.chaoticd.attack_reach"))
                .method_27692(class_124.field_1064));
        }

        // The name was styled by ItemStackNameMixin; lore and attributes retain their own styles.
        RarityDefinition stackRarity = RarityResolver.global().resolveItem(stack);
        class_2561 rankLabel = class_2561.method_43471(stackRarity.translationKey());
        lines.add(TooltipRarityRenderer.global().style(rankLabel, stackRarity));
        callback.setReturnValue(lines);
    }

    private static double finalAttackDamage(class_1799 stack, class_1657 player) {
        double value = player == null ? 1.0D : player.method_26826(class_5134.field_23721);
        for (class_1322 modifier : stack.method_7926(class_1304.field_6173)
            .get(class_5134.field_23721)) {
            switch (modifier.method_6182()) {
                case field_6328 -> value += modifier.method_6186();
                case field_6330 -> value += value * modifier.method_6186();
                case field_6331 -> value *= 1.0D + modifier.method_6186();
            }
        }
        return value;
    }

    private static String format(double value) {
        return value == Math.rint(value) ? Long.toString(Math.round(value))
            : String.format(Locale.ROOT, "%.2f", value);
    }
}
