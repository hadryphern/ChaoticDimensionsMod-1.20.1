package net.blue.chaoticd.mixin;

import net.minecraft.class_1882;
import net.minecraft.class_1884;
import net.minecraft.class_1885;
import net.minecraft.class_1892;
import net.minecraft.class_1893;
import net.minecraft.class_1896;
import net.minecraft.class_1897;
import net.minecraft.class_1900;
import net.minecraft.class_1903;
import net.minecraft.class_1906;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Raises the requested vanilla enchantment caps without changing unrelated enchantments. */
@Mixin({class_1882.class, class_1884.class, class_1885.class,
    class_1892.class, class_1897.class, class_1896.class,
    class_1900.class, class_1903.class, class_1906.class})
public abstract class VanillaEnchantmentLevelMixin {
    @Inject(method = "getMaxLevel", at = @At("HEAD"), cancellable = true)
    private void chaoticd$raiseVanillaCaps(CallbackInfoReturnable<Integer> callback) {
        Object self = this;
        if (self == class_1893.field_9118) callback.setReturnValue(15);
        else if (self == class_1893.field_9119) callback.setReturnValue(10);
        else if (self == class_1893.field_9111 || self == class_1893.field_9095
            || self == class_1893.field_9107 || self == class_1893.field_9096
            || self == class_1893.field_9129 || self == class_1893.field_9097) callback.setReturnValue(15);
        else if (self == class_1893.field_9131 || self == class_1893.field_9121) callback.setReturnValue(self == class_1893.field_9121 ? 20 : 10);
        else if (self == class_1893.field_9110 || self == class_1893.field_9130
            || self == class_1893.field_9123 || self == class_1893.field_9112
            || self == class_1893.field_9115 || self == class_1893.field_9124) callback.setReturnValue(10);
    }
}
