package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1772;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1889;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Single ordered creative tab for all currently registered mod content. */
public final class ModItemGroups {
    public static final class_1761 CHAOTIC_DIMENSIONS = class_2378.method_10230(
        class_7923.field_44687,
        new class_2960(ChaoticDimensions.MOD_ID, "chaotic_dimensions"),
        FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemGroup.chaoticd.chaotic_dimensions"))
            .method_47320(() -> new class_1799(ModItems.SAPPHIRE_SWORD))
            .method_47317((parameters, entries) -> {
                addBlocks(entries);
                addToolsAndWeapons(entries);
                addMaterialsAndOres(entries);
                addArmor(entries);
                addEnchantments(entries);
                addPotions(entries);
                addNature(entries);
                addFood(entries);
                addSpawnEggs(entries);
                addUsefulItems(entries);
            })
            .method_47324()
    );

    private ModItemGroups() {
    }

    private static void addBlocks(class_1761.class_7704 entries) {
        entries.method_45421(ModBlocks.PASTEL_AURORA_LOG);
        entries.method_45421(ModBlocks.PASTEL_AURORA_WOOD);
        entries.method_45421(ModBlocks.STRIPPED_PASTEL_AURORA_LOG);
        entries.method_45421(ModBlocks.STRIPPED_PASTEL_AURORA_WOOD);
        entries.method_45421(ModBlocks.PASTEL_AURORA_PLANKS);
        entries.method_45421(ModBlocks.PASTEL_PINK_LEAVES);
        entries.method_45421(ModBlocks.PASTEL_PURPLE_LEAVES);
        entries.method_45421(ModBlocks.PASTEL_BLUE_LEAVES);
        entries.method_45421(ModBlocks.PASTEL_GRASS);
        entries.method_45421(ModBlocks.PASTEL_SOIL);
        entries.method_45421(ModBlocks.PASTEL_AURORA_STONE);
        entries.method_45421(ModBlocks.SAPPHIRE_ORE);
        entries.method_45421(ModBlocks.ROSALITA_ORE);

        entries.method_45421(ModBlocks.SHADOW_LOG);
        entries.method_45421(ModBlocks.SHADOW_WOOD);
        entries.method_45421(ModBlocks.STRIPPED_SHADOW_LOG);
        entries.method_45421(ModBlocks.STRIPPED_SHADOW_WOOD);
        entries.method_45421(ModBlocks.SHADOW_PLANKS);
        entries.method_45421(ModBlocks.SHADOW_LEAVES);
        entries.method_45421(ModBlocks.SHADOW_GRASS);
        entries.method_45421(ModBlocks.SHADOW_SOIL);
        entries.method_45421(ModBlocks.SHADOW_STONE);

        entries.method_45421(ModBlocks.RUBY_ORE);
        entries.method_45421(ModBlocks.RUBY_BLOCK);
        entries.method_45421(ModBlocks.TITANIUM_ORE);
        entries.method_45421(ModBlocks.TITANIUM_BLOCK);

        entries.method_45421(ModBlocks.CRYSTAL_DIRT);
        entries.method_45421(ModBlocks.CRYSTAL_GRASS_BLOCK);
        entries.method_45421(ModBlocks.CRYSTAL_LOG);
        entries.method_45421(ModBlocks.CRYSTAL_PLANKS);
        entries.method_45421(ModBlocks.CRYSTAL_LEAVES_1);
        entries.method_45421(ModBlocks.CRYSTAL_LEAVES_2);
        entries.method_45421(ModBlocks.CRYSTAL_LEAVES_3);
        entries.method_45421(ModBlocks.CRYSTAL_RED_PLANT);
        entries.method_45421(ModBlocks.CRYSTAL_YELLOW_PLANT);
        entries.method_45421(ModBlocks.CRYSTAL_BLUE_PLANT);
        entries.method_45421(ModBlocks.CRYSTAL_GREEN_PLANT);
        entries.method_45421(ModBlocks.CRYSTAL_FURNACE);
        entries.method_45421(ModBlocks.CRYSTAL_CRAFTING_TABLE);
    }

    private static void addToolsAndWeapons(class_1761.class_7704 entries) {
        entries.method_45421(ModItems.SAPPHIRE_SWORD);
        entries.method_45421(ModItems.SAPPHIRE_AXE);
        entries.method_45421(ModItems.SAPPHIRE_PICKAXE);
        entries.method_45421(ModItems.SAPPHIRE_SHOVEL);
        entries.method_45421(ModItems.SAPPHIRE_HOE);

        entries.method_45421(ModItems.TITANIUM_SWORD);
        entries.method_45421(ModItems.TITANIUM_AXE);
        entries.method_45421(ModItems.TITANIUM_PICKAXE);
        entries.method_45421(ModItems.TITANIUM_SHOVEL);
        entries.method_45421(ModItems.TITANIUM_HOE);

        entries.method_45421(ModItems.EMERALD_SWORD);
        entries.method_45421(ModItems.EMERALD_AXE);
        entries.method_45421(ModItems.EMERALD_PICKAXE);
        entries.method_45421(ModItems.EMERALD_SHOVEL);
        entries.method_45421(ModItems.EMERALD_HOE);

        entries.method_45421(ModItems.RUBY_SWORD);
        entries.method_45421(ModItems.RUBY_AXE);
        entries.method_45421(ModItems.RUBY_PICKAXE);
        entries.method_45421(ModItems.RUBY_SHOVEL);
        entries.method_45421(ModItems.RUBY_HOE);
    }

    private static void addMaterialsAndOres(class_1761.class_7704 entries) {
        entries.method_45421(ModItems.SAPPHIRE_GEM);
        entries.method_45421(ModItems.ROSALITA_GEM);
        entries.method_45421(ModItems.TITANIUM_INGOT);
        entries.method_45421(ModItems.EMERALD_INGOT);
        entries.method_45421(ModItems.RUBY_NUGGET);
        entries.method_45421(ModItems.RUBY);
        entries.method_45421(ModItems.RUBY_PLATE);
        entries.method_45421(ModItems.WATER_INGOT);
        entries.method_45421(ModItems.LAVA_INGOT);
        entries.method_45421(ModItems.BEDROCK_STICK);
    }

    private static void addArmor(class_1761.class_7704 entries) {
        entries.method_45421(ModItems.EMERALD_HELMET);
        entries.method_45421(ModItems.EMERALD_CHESTPLATE);
        entries.method_45421(ModItems.EMERALD_LEGGINGS);
        entries.method_45421(ModItems.EMERALD_BOOTS);

        entries.method_45421(ModItems.RUBY_HELMET);
        entries.method_45421(ModItems.RUBY_CHESTPLATE);
        entries.method_45421(ModItems.RUBY_LEGGINGS);
        entries.method_45421(ModItems.RUBY_BOOTS);
    }

    private static void addEnchantments(class_1761.class_7704 entries) {
        addBooks(entries, ModEnchantments.SAPPHIRIC);
        addBooks(entries, ModEnchantments.BIG_BERTHA);
        addBooks(entries, ModEnchantments.ROYAL);
        addBooks(entries, ModEnchantments.DISPARADA);
        entries.method_45420(class_1772.method_7808(
            new class_1889(ModEnchantments.DHEATHIC, 1)
        ));
    }

    private static void addBooks(
        class_1761.class_7704 entries,
        net.minecraft.class_1887 enchantment
    ) {
        for (int level = 1; level <= enchantment.method_8183(); level++) {
            entries.method_45420(class_1772.method_7808(
                new class_1889(enchantment, level)
            ));
        }
    }

    private static void addPotions(class_1761.class_7704 entries) {
        entries.method_45420(ModPotions.potion(class_1802.field_8574));
        entries.method_45420(ModPotions.potion(class_1802.field_8436));
        entries.method_45420(ModPotions.potion(class_1802.field_8150));
        entries.method_45420(ModPotions.potion(class_1802.field_8087));
    }

    private static void addNature(class_1761.class_7704 entries) {
        // Nature blocks are already listed in the ordered block section.
    }

    private static void addFood(class_1761.class_7704 entries) {
        entries.method_45421(ModItems.CHAOTIC_APPLE);
        entries.method_45421(ModItems.GOLD_SPECIAL_APPLE);
        entries.method_45421(ModItems.DIMENSION_APPLE);
    }

    private static void addSpawnEggs(class_1761.class_7704 entries) {
        entries.method_45421(ModItems.DIMENSION_PIG_SPAWN_EGG);
        entries.method_45421(ModItems.GOLD_DIMENSION_PIG_SPAWN_EGG);
        entries.method_45421(ModItems.APPLE_COW_SPAWN_EGG);
        entries.method_45421(ModItems.GOLDEN_APPLE_COW_SPAWN_EGG);
        entries.method_45421(ModItems.CRYSTAL_APPLE_COW_SPAWN_EGG);
        entries.method_45421(ModItems.CRYSTAL_GOLDEN_APPLE_SPAWN_EGG);
        entries.method_45421(ModItems.CRYSTAL_CREEPER_SPAWN_EGG);
    }

    private static void addUsefulItems(class_1761.class_7704 entries) {
        entries.method_45421(ModItems.DEATH_TOTEM);
        entries.method_45421(ModItems.DREAM_FLUID_BUCKET);
        entries.method_45421(ModItems.CRYSTALINE_SEE);
        entries.method_45421(ModItems.CRYSTALINE_EYE);
        entries.method_45421(ModItems.LEATHER_BACKPACK);
    }

    public static void initialize() {
        // Static field performs registry insertion.
    }
}
