package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1772;
import net.minecraft.class_1802;
import net.minecraft.class_1889;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * The single, ordered creative tab for this mod.
 *
 * Keep the section methods and their call order intact. New content must be added only to its matching
 * section so the tab never becomes a random collection of items.
 */
public final class ModItemGroups {
    public static final class_1761 CHAOTIC_DIMENSIONS = class_2378.method_10230(
        class_7923.field_44687,
        new class_2960(ChaoticDimensions.MOD_ID, "chaotic_dimensions"),
        FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemGroup.chaoticd.chaotic_dimensions"))
            .method_47320(ModItems::createSapphireSword)
            .method_47317((parameters, entries) -> {
                addBlocks(entries);
                addToolsAndWeapons(entries);
                addMaterialsAndOres(entries);
                addArmor(entries);
                addEnchantments(entries);
                addPotions(entries);
                addNature(entries);
                addFood(entries);
                addSpawnEggs(entries);
                addUsefulItems(entries);
            })
            .method_47324());

    private ModItemGroups() {
    }

    /** First: all block items, ordered by their block family. */
    private static void addBlocks(class_1761.class_7704 entries) {
        entries.method_45421(ModBlocks.PASTEL_AURORA_LOG);
        entries.method_45421(ModBlocks.PASTEL_AURORA_WOOD);
        entries.method_45421(ModBlocks.STRIPPED_PASTEL_AURORA_LOG);
        entries.method_45421(ModBlocks.STRIPPED_PASTEL_AURORA_WOOD);
        entries.method_45421(ModBlocks.PASTEL_AURORA_PLANKS);
        entries.method_45421(ModBlocks.PASTEL_PINK_LEAVES);
        entries.method_45421(ModBlocks.PASTEL_PURPLE_LEAVES);
        entries.method_45421(ModBlocks.PASTEL_BLUE_LEAVES);
        entries.method_45421(ModBlocks.PASTEL_GRASS);
        entries.method_45421(ModBlocks.PASTEL_SOIL);
        entries.method_45421(ModBlocks.PASTEL_AURORA_STONE);
        entries.method_45421(ModBlocks.SAPPHIRE_ORE);
        entries.method_45421(ModBlocks.ROSALITA_ORE);
    }

    /** Second: sword, axe, pickaxe, shovel and hoe, matching the agreed visual order. */
    private static void addToolsAndWeapons(class_1761.class_7704 entries) {
        entries.method_45420(ModItems.createSapphireSword());
        entries.method_45420(ModItems.createSapphireTool(ModItems.SapphireToolType.AXE));
        entries.method_45420(ModItems.createSapphireTool(ModItems.SapphireToolType.PICKAXE));
        entries.method_45420(ModItems.createSapphireTool(ModItems.SapphireToolType.SHOVEL));
        entries.method_45420(ModItems.createSapphireTool(ModItems.SapphireToolType.HOE));
    }

    /** Third: gems, ingots, raw materials, then ore blocks. */
    private static void addMaterialsAndOres(class_1761.class_7704 entries) {
        entries.method_45421(ModItems.SAPPHIRE_GEM);
    }

    /** Fourth: all armor pieces, grouped by material. */
    private static void addArmor(class_1761.class_7704 entries) {
        // Future armor belongs here.
    }

    /** Fifth: enchanted books. Dheathic remains an Ender Dragon reward in survival. */
    private static void addEnchantments(class_1761.class_7704 entries) {
        for (int level = 1; level <= ModEnchantments.SAPPHIRIC.method_8183(); level++) {
            entries.method_45420(class_1772.method_7808(new class_1889(ModEnchantments.SAPPHIRIC, level)));
        }
        for (int level = 1; level <= ModEnchantments.BIG_BERTHA.method_8183(); level++) {
            entries.method_45420(class_1772.method_7808(new class_1889(ModEnchantments.BIG_BERTHA, level)));
        }
        for (int level = 1; level <= ModEnchantments.ROYAL.method_8183(); level++) {
            entries.method_45420(class_1772.method_7808(new class_1889(ModEnchantments.ROYAL, level)));
        }
        for (int level = 1; level <= ModEnchantments.DISPARADA.method_8183(); level++) {
            entries.method_45420(class_1772.method_7808(new class_1889(ModEnchantments.DISPARADA, level)));
        }
        entries.method_45420(class_1772.method_7808(new class_1889(ModEnchantments.DHEATHIC, 1)));
    }

    /** Sixth: drinkable potion, splash potion, lingering potion, then tipped arrow. */
    private static void addPotions(class_1761.class_7704 entries) {
        entries.method_45420(ModPotions.potion(class_1802.field_8574));
        entries.method_45420(ModPotions.potion(class_1802.field_8436));
        entries.method_45420(ModPotions.potion(class_1802.field_8150));
        entries.method_45420(ModPotions.potion(class_1802.field_8087));
    }

    private static void addNature(class_1761.class_7704 entries) {
        // Future natural content belongs here.
    }

    private static void addFood(class_1761.class_7704 entries) {
        entries.method_45420(ModItems.CHAOTIC_APPLE.method_7854());
    }

    private static void addSpawnEggs(class_1761.class_7704 entries) {
        // Future spawn eggs belong here.
    }

    private static void addUsefulItems(class_1761.class_7704 entries) {
        // Future utility items belong here.
    }

    public static void initialize() {
        // Loading this class performs the registry entry above.
    }
}
