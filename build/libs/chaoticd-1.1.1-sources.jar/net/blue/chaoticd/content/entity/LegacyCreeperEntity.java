package net.blue.chaoticd.content.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1548;
import net.minecraft.class_1937;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Fabric/GeckoLib restoration of the legacy Crystal Creeper. */
public final class LegacyCreeperEntity extends class_1548 implements LegacyAnimatedMob {
    private final LegacyMobVariant variant;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public LegacyCreeperEntity(
        class_1299<? extends class_1548> type,
        class_1937 level,
        LegacyMobVariant variant
    ) {
        super(type, level);
        this.variant = variant;
    }

    @Override
    public LegacyMobVariant variant() {
        return variant;
    }

    @Override
    public void registerControllers(ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(
            this,
            "movement",
            4,
            this::movementAnimation
        ));
    }

    private PlayState movementAnimation(AnimationState<LegacyCreeperEntity> state) {
        String animation = state.isMoving()
            ? variant.walkAnimation()
            : variant.idleAnimation();
        state.getController().setAnimation(RawAnimation.begin().thenLoop(animation));
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
