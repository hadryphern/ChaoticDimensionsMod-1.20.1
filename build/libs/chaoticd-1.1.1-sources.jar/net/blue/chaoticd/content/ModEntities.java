package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.entity.LegacyCowEntity;
import net.blue.chaoticd.content.entity.LegacyCreeperEntity;
import net.blue.chaoticd.content.entity.LegacyMobVariant;
import net.blue.chaoticd.content.entity.LegacyPigEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1430;
import net.minecraft.class_1452;
import net.minecraft.class_1548;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Legacy entities are registered for spawn eggs only; no biome spawn is added. */
public final class ModEntities {
    public static final class_1299<LegacyPigEntity> DIMENSION_PIG = register(
        "dimension_pig",
        class_1299.class_1300.<LegacyPigEntity>method_5903(
            (type, level) -> new LegacyPigEntity(type, level, LegacyMobVariant.DIMENSION_PIG),
            class_1311.field_6294
        ).method_17687(0.9F, 0.9F)
    );

    public static final class_1299<LegacyPigEntity> GOLD_DIMENSION_PIG = register(
        "gold_dimension_pig",
        class_1299.class_1300.<LegacyPigEntity>method_5903(
            (type, level) -> new LegacyPigEntity(type, level, LegacyMobVariant.GOLD_DIMENSION_PIG),
            class_1311.field_6294
        ).method_17687(0.9F, 0.9F)
    );

    public static final class_1299<LegacyCowEntity> APPLE_COW = register(
        "apple_cow",
        class_1299.class_1300.<LegacyCowEntity>method_5903(
            (type, level) -> new LegacyCowEntity(type, level, LegacyMobVariant.APPLE_COW),
            class_1311.field_6294
        ).method_17687(0.9F, 1.4F)
    );

    public static final class_1299<LegacyCowEntity> GOLDEN_APPLE_COW = register(
        "golden_apple_cow",
        class_1299.class_1300.<LegacyCowEntity>method_5903(
            (type, level) -> new LegacyCowEntity(type, level, LegacyMobVariant.GOLDEN_APPLE_COW),
            class_1311.field_6294
        ).method_17687(0.9F, 1.4F)
    );

    public static final class_1299<LegacyCowEntity> CRYSTAL_APPLE_COW = register(
        "crystal_apple_cow",
        class_1299.class_1300.<LegacyCowEntity>method_5903(
            (type, level) -> new LegacyCowEntity(type, level, LegacyMobVariant.CRYSTAL_APPLE_COW),
            class_1311.field_6294
        ).method_17687(0.9F, 1.4F)
    );

    public static final class_1299<LegacyCowEntity> CRYSTAL_GOLDEN_APPLE = register(
        "crystal_golden_apple",
        class_1299.class_1300.<LegacyCowEntity>method_5903(
            (type, level) -> new LegacyCowEntity(type, level, LegacyMobVariant.CRYSTAL_GOLDEN_APPLE),
            class_1311.field_6294
        ).method_17687(0.9F, 1.4F)
    );

    public static final class_1299<LegacyCreeperEntity> CRYSTAL_CREEPER = register(
        "crystal_creeper",
        class_1299.class_1300.<LegacyCreeperEntity>method_5903(
            (type, level) -> new LegacyCreeperEntity(type, level, LegacyMobVariant.CRYSTAL_CREEPER),
            class_1311.field_6302
        ).method_17687(0.6F, 1.7F)
    );

    private ModEntities() {
    }

    private static <T extends net.minecraft.class_1297> class_1299<T> register(
        String id,
        class_1299.class_1300<T> builder
    ) {
        return class_2378.method_10230(
            class_7923.field_41177,
            new class_2960(ChaoticDimensions.MOD_ID, id),
            builder.method_27299(8).method_5905(id)
        );
    }

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(DIMENSION_PIG, class_1452.method_26890());
        FabricDefaultAttributeRegistry.register(GOLD_DIMENSION_PIG, class_1452.method_26890());
        FabricDefaultAttributeRegistry.register(APPLE_COW, class_1430.method_26883());
        FabricDefaultAttributeRegistry.register(GOLDEN_APPLE_COW, class_1430.method_26883());
        FabricDefaultAttributeRegistry.register(CRYSTAL_APPLE_COW, class_1430.method_26883());
        FabricDefaultAttributeRegistry.register(CRYSTAL_GOLDEN_APPLE, class_1430.method_26883());
        FabricDefaultAttributeRegistry.register(CRYSTAL_CREEPER, class_1548.method_26908());
    }
}