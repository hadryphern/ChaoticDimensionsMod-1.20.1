package net.blue.chaoticd.content.fluid;

import java.util.Optional;
import net.blue.chaoticd.content.ModBlocks;
import net.blue.chaoticd.content.ModFluids;
import net.blue.chaoticd.content.ModItems;
import net.blue.chaoticd.content.ModTags;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2404;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import org.jetbrains.annotations.Nullable;

/**
 * Dense magical liquid used by Dream Fluid lakes.
 *
 * <p>Its flow behavior intentionally resembles lava rather than water:
 * it spreads slowly, loses more height per block and cannot create infinite
 * source blocks. The block class handles the heavy movement slowdown.</p>
 */
public abstract class DreamFluid extends class_3609 {
    @Override
    public class_3611 method_15750() {
        return ModFluids.FLOWING_DREAM_FLUID;
    }

    @Override
    public class_3611 method_15751() {
        return ModFluids.DREAM_FLUID;
    }

    @Override
    public class_1792 method_15774() {
        return ModItems.DREAM_FLUID_BUCKET;
    }

    @Override
    public boolean method_15780(class_3611 fluid) {
        return fluid == ModFluids.DREAM_FLUID
            || fluid == ModFluids.FLOWING_DREAM_FLUID;
    }

    @Nullable
    @Override
    public class_2394 method_15787() {
        return class_2398.field_11223;
    }

    /**
     * Dream Fluid is rare and must not become an infinite source like water.
     */
    @Override
    protected boolean method_15737(class_1937 level) {
        return false;
    }

    @Override
    protected void method_15730(
        class_1936 level,
        class_2338 pos,
        class_2680 state
    ) {
        class_2586 blockEntity =
            state.method_31709()
                ? level.method_8321(pos)
                : null;

        class_2248.method_9610(
            state,
            level,
            pos,
            blockEntity
        );
    }

    /**
     * Lava searches only a short distance for a downward path.
     */
    @Override
    protected int method_15733(
        class_4538 level
    ) {
        return 2;
    }

    /**
     * The fluid level falls quickly while spreading horizontally.
     */
    @Override
    public int method_15739(
        class_4538 level
    ) {
        return 2;
    }

    /**
     * Thirty ticks makes it visibly slow and heavy like Overworld lava.
     */
    @Override
    public int method_15789(
        class_4538 level
    ) {
        return 30;
    }

    @Override
    public boolean method_15777(
        class_3610 state,
        class_1922 level,
        class_2338 pos,
        class_3611 fluid,
        class_2350 direction
    ) {
        return direction == class_2350.field_11033
            && !fluid.method_15791(ModTags.DREAM_FLUID);
    }

    @Override
    protected float method_15784() {
        return 100.0F;
    }

    @Override
    public Optional<class_3414> method_32359() {
        return Optional.of(
            class_3417.field_15202
        );
    }

    @Override
    protected class_2680 method_15790(
        class_3610 state
    ) {
        return ModBlocks.DREAM_FLUID
            .method_9564()
            .method_11657(
                class_2404.field_11278,
                method_15741(state)
            );
    }

    public static final class Flowing
        extends DreamFluid {

        public Flowing() {
            method_15781(
                method_15783()
                    .method_11664()
                    .method_11657(field_15900, 7)
                    .method_11657(field_15902, false)
            );
        }

        @Override
        protected void method_15775(
            class_2689.class_2690<
                class_3611,
                class_3610
            > builder
        ) {
            super.method_15775(
                builder
            );

            builder.method_11667(field_15900);
        }

        @Override
        public int method_15779(
            class_3610 state
        ) {
            return state.method_11654(field_15900);
        }

        @Override
        public boolean method_15793(
            class_3610 state
        ) {
            return false;
        }
    }

    public static final class Source
        extends DreamFluid {

        public Source() {
            method_15781(
                method_15783()
                    .method_11664()
                    .method_11657(field_15902, false)
            );
        }

        @Override
        public int method_15779(
            class_3610 state
        ) {
            return 8;
        }

        @Override
        public boolean method_15793(
            class_3610 state
        ) {
            return true;
        }
    }
}
