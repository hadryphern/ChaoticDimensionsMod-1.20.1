package net.blue.chaoticd.content.block;

import net.blue.chaoticd.content.ModBlocks;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2372;
import net.minecraft.class_2488;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3486;
import net.minecraft.class_3558;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;

/** Grass that spreads only across Aurora soil and immediately becomes soil when covered. */
public final class AuroraGrassBlock extends class_2372 {
    public AuroraGrassBlock(class_4970.class_2251 properties) {
        super(properties);
    }

    private static boolean canRemainGrass(class_2680 state, class_4538 level, class_2338 pos) {
        class_2338 abovePos = pos.method_10084();
        class_2680 above = level.method_8320(abovePos);

        if (above.method_27852(class_2246.field_10477) && above.method_11654(class_2488.field_11518) == 1) {
            return true;
        }

        if (above.method_26227().method_15761() == 8) {
            return false;
        }

        int blockedLight = class_3558.method_20049(
            level,
            state,
            pos,
            above,
            abovePos,
            class_2350.field_11036,
            above.method_26193(level, abovePos)
        );

        return blockedLight < level.method_8315();
    }

    private static boolean canSpreadTo(class_2680 state, class_4538 level, class_2338 pos) {
        return canRemainGrass(state, level, pos)
            && !level.method_8316(pos.method_10084()).method_15767(class_3486.field_15517);
    }

    /**
     * Unlike randomTick, updateShape runs as soon as the block above changes.
     * This removes the long delay when a solid block is placed over Aurora grass.
     */
    @Override
    public class_2680 method_9559(
        class_2680 state,
        class_2350 direction,
        class_2680 neighbourState,
        class_1936 level,
        class_2338 pos,
        class_2338 neighbourPos
    ) {
        if (direction == class_2350.field_11036 && !canRemainGrass(state, level, pos)) {
            return ModBlocks.PASTEL_SOIL.method_9564();
        }

        return super.method_9559(state, direction, neighbourState, level, pos, neighbourPos);
    }

    @Override
    public void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (!canRemainGrass(state, level, pos)) {
            level.method_8501(pos, ModBlocks.PASTEL_SOIL.method_9564());
            return;
        }

        if (level.method_22339(pos.method_10084()) < 9) {
            return;
        }

        class_2680 spreadingState = method_9564();

        for (int attempt = 0; attempt < 4; attempt++) {
            class_2338 targetPos = pos.method_10069(
                random.method_43048(3) - 1,
                random.method_43048(5) - 3,
                random.method_43048(3) - 1
            );

            if (level.method_8320(targetPos).method_27852(ModBlocks.PASTEL_SOIL)
                && canSpreadTo(spreadingState, level, targetPos)) {
                boolean snowy = level.method_8320(targetPos.method_10084()).method_27852(class_2246.field_10477);
                level.method_8501(targetPos, spreadingState.method_11657(field_11522, snowy));
            }
        }
    }
}
