package net.blue.chaoticd.content.block;

import net.blue.chaoticd.content.ModBlockEntities;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_3858;
import net.minecraft.class_3956;

/** Block entity that runs the vanilla smelting recipe type and Furnace menu. */
public final class CrystalFurnaceBlockEntity extends class_2609 {
    public CrystalFurnaceBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CRYSTAL_FURNACE, pos, state, class_3956.field_17546);
    }

    @Override
    protected class_2561 method_17823() {
        return class_2561.method_43471("container.chaoticd.crystal_furnace");
    }

    @Override
    protected class_1703 method_5465(int id, class_1661 inventory) {
        return new class_3858(id, inventory, this, this.field_17374);
    }
}
