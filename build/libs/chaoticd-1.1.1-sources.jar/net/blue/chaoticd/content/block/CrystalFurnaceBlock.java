package net.blue.chaoticd.content.block;

import org.jetbrains.annotations.Nullable;

import net.blue.chaoticd.content.ModBlockEntities;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2363;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3468;
import net.minecraft.class_3908;
import net.minecraft.class_5558;

public final class CrystalFurnaceBlock extends class_2363 {

    public CrystalFurnaceBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CrystalFurnaceBlockEntity(pos, state);
    }

    @Override
    protected void method_17025(class_1937 level, class_2338 pos, class_1657 player) {

        class_2586 blockEntity = level.method_8321(pos);

        if (blockEntity instanceof class_3908 provider) {

            player.method_17355(provider);

            player.method_7281(class_3468.field_15379);

        }
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(
            class_1937 level,
            class_2680 state,
            class_2591<T> type
    ) {

        return method_31617(
                level,
                type,
                ModBlockEntities.CRYSTAL_FURNACE
        );

    }

}