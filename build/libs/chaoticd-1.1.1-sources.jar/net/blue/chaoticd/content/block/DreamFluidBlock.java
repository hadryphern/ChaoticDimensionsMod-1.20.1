package net.blue.chaoticd.content.block;

import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_4970;

/**
 * Dream Fluid block with heavy, lava-like movement.
 *
 * <p>Players are killed by DreamFluidSystems. This class is responsible only
 * for making entities and dropped items move through the liquid very slowly.</p>
 */
public final class DreamFluidBlock extends class_2404 {
    private static final double HORIZONTAL_DRAG = 0.22D;
    private static final double ENTITY_VERTICAL_DRAG = 0.12D;
    private static final double ITEM_VERTICAL_DRAG = 0.08D;
    private static final double MAXIMUM_ITEM_SINK_SPEED = -0.012D;

    public DreamFluidBlock(
        class_3609 fluid,
        class_4970.class_2251 properties
    ) {
        super(fluid, properties);
    }

    @Override
    public void method_9548(
        class_2680 state,
        class_1937 level,
        class_2338 pos,
        class_1297 entity
    ) {
        class_243 movement =
            entity.method_18798();

        double verticalMovement;

        if (entity instanceof class_1542) {
            verticalMovement =
                Math.max(
                    movement.field_1351
                        * ITEM_VERTICAL_DRAG,
                    MAXIMUM_ITEM_SINK_SPEED
                );
        } else {
            verticalMovement =
                movement.field_1351
                    * ENTITY_VERTICAL_DRAG;
        }

        entity.method_18800(
            movement.field_1352 * HORIZONTAL_DRAG,
            verticalMovement,
            movement.field_1350 * HORIZONTAL_DRAG
        );

        entity.field_6017 = 0.0F;
    }
}
