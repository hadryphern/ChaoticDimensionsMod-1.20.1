package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.enchantment.DheathicEnchantment;
import net.blue.chaoticd.content.enchantment.DisparadaEnchantment;
import net.blue.chaoticd.content.enchantment.BigBerthaEnchantment;
import net.blue.chaoticd.content.enchantment.RoyalEnchantment;
import net.blue.chaoticd.content.enchantment.SapphiricEnchantment;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1772;
import net.minecraft.class_1887;
import net.minecraft.class_1889;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

/** Registers the two Sapphire-era enchantments and the obtainable Sapphiric book. */
public final class ModEnchantments {
    public static final class_1887 SAPPHIRIC = register("sapphiric", new SapphiricEnchantment());
    public static final class_1887 DHEATHIC = register("dheathic", new DheathicEnchantment());
    public static final class_1887 BIG_BERTHA = register("big_bertha", new BigBerthaEnchantment());
    public static final class_1887 ROYAL = register("royal", new RoyalEnchantment());
    public static final class_1887 DISPARADA = register("disparada", new DisparadaEnchantment());

    private ModEnchantments() {
    }

    private static class_1887 register(String id, class_1887 enchantment) {
        return class_2378.method_10230(class_7923.field_41176,
            new class_2960(ChaoticDimensions.MOD_ID, id), enchantment);
    }

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            addBooks(entries, class_1893.field_9118, 15);
            addBooks(entries, class_1893.field_9119, 10);
            addBooks(entries, class_1893.field_9111, 15);
            addBooks(entries, class_1893.field_9095, 15);
            addBooks(entries, class_1893.field_9107, 15);
            addBooks(entries, class_1893.field_9096, 15);
            addBooks(entries, class_1893.field_9129, 15);
            addBooks(entries, class_1893.field_9097, 15);
            addBooks(entries, class_1893.field_9131, 10);
            addBooks(entries, class_1893.field_9121, 20);
            addBooks(entries, class_1893.field_9123, 10);
            addBooks(entries, class_1893.field_9112, 10);
            addBooks(entries, class_1893.field_9115, 10);
            addBooks(entries, class_1893.field_9124, 10);
            addBooks(entries, class_1893.field_9110, 10);
            addBooks(entries, class_1893.field_9130, 10);
            addBooks(entries, DISPARADA, 5);
        });
    }

    private static void addBooks(FabricItemGroupEntries entries, class_1887 enchantment, int maxLevel) {
        for (int level = 1; level <= maxLevel; level++) {
            entries.method_45420(class_1772.method_7808(new class_1889(enchantment, level)));
        }
    }
}
