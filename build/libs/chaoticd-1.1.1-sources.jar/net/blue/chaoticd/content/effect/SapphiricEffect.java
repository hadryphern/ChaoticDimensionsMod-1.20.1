package net.blue.chaoticd.content.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_4081;

/** Makes AI mobs continually abandon their course for a random nearby destination. */
public final class SapphiricEffect extends class_1291 {
    private static final double WANDER_DISTANCE = 18.0D;

    public SapphiricEffect() {
        super(class_4081.field_18272, 0x7B2CBF);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return duration % 10 == 0;
    }

    @Override
    public void method_5572(class_1309 entity, int amplifier) {
        if (entity.method_37908().field_9236 || !(entity instanceof class_1308 mob)) {
            return;
        }

        double targetX = mob.method_23317() + (mob.method_6051().method_43058() - 0.5D) * WANDER_DISTANCE * 2.0D;
        double targetZ = mob.method_23321() + (mob.method_6051().method_43058() - 0.5D) * WANDER_DISTANCE * 2.0D;
        mob.method_5942().method_6337(targetX, mob.method_23318(), targetZ, 1.25D + amplifier * 0.15D);
    }
}
