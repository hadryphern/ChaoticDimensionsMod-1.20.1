package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1845;
import net.minecraft.class_1847;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Vanilla potion containers carrying the Sapphiric effect for 45 seconds. */
public final class ModPotions {
    public static final class_1842 SAPPHIRIC = class_2378.method_10230(class_7923.field_41179,
        new class_2960(ChaoticDimensions.MOD_ID, "sapphiric"),
        new class_1842("sapphiric", new class_1293(ModEffects.SAPPHIRIC, 20 * 45)));

    private ModPotions() {
    }

    public static void initialize() {
        class_1845.method_8074(class_1847.field_8999, ModItems.SAPPHIRE_GEM, SAPPHIRIC);
        // Containers are shown in the dedicated Chaotic Dimensions Potions category.
    }

    public static class_1799 potion(net.minecraft.class_1792 container) {
        return class_1844.method_8061(new class_1799(container), SAPPHIRIC);
    }
}
