package net.blue.chaoticd.content;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1772;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1889;
import net.minecraft.class_1890;
import net.minecraft.class_2371;
import net.minecraft.class_8111;

/** Server-authoritative behavior for the two custom enchantments. */
public final class ModGameplayEvents {
    private static final Set<UUID> SURVIVED_DAMAGE_THIS_LIFE = new HashSet<>();
    private static final ThreadLocal<Boolean> APPLYING_BONUS_SWORD_DAMAGE = ThreadLocal.withInitial(() -> false);

    private ModGameplayEvents() {
    }

    public static void initialize() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(ModGameplayEvents::onDamage);
        ServerLivingEntityEvents.AFTER_DEATH.register(ModGameplayEvents::onDeath);
    }

    private static boolean onDamage(class_1309 victim, class_1282 source, float amount) {
        applySwordEnchantments(victim, source, amount);

        if (victim instanceof class_1657 player && amount < player.method_6032()) {
            SURVIVED_DAMAGE_THIS_LIFE.add(player.method_5667());
            repairDheathicTools(player, amount);
        }
        return true;
    }

    private static void applySwordEnchantments(class_1309 victim, class_1282 source, float amount) {
        if (!(source.method_5529() instanceof class_1309 attacker)
            || source.method_5526() != attacker) {
            return;
        }

        class_1799 sword = attacker.method_6047();
        int sapphiric = class_1890.method_8225(ModEnchantments.SAPPHIRIC, sword);
        if (sapphiric > 0) {
            applySapphiricArea(victim, attacker, sapphiric);
        }

        float multiplier = ModCombatEnchantments.damageMultiplier(sword);
        if (multiplier > 1.0F && !APPLYING_BONUS_SWORD_DAMAGE.get()) {
            APPLYING_BONUS_SWORD_DAMAGE.set(true);
            try {
                victim.method_5643(source, amount * (multiplier - 1.0F));
            } finally {
                APPLYING_BONUS_SWORD_DAMAGE.set(false);
            }
        }
    }

    private static void applySapphiricArea(class_1309 victim, class_1309 attacker, int level) {
        victim.method_37222(new class_1293(ModEffects.SAPPHIRIC, 20 * 45), attacker);
        double radius = ModCombatEnchantments.sapphiricEffectRadius(level);
        if (radius <= 0.0D) {
            return;
        }
        for (class_1309 nearby : attacker.method_37908().method_8390(class_1309.class,
            victim.method_5829().method_1014(radius), candidate -> candidate != attacker && candidate.method_5805())) {
            nearby.method_37222(new class_1293(ModEffects.SAPPHIRIC, 20 * 45), attacker);
        }
    }

    private static void repairDheathicTools(class_1657 player, float damageTaken) {
        repairDheathicStacks(player.method_31548().field_7547, damageTaken);
        repairDheathicStacks(player.method_31548().field_7548, damageTaken);
        repairDheathicStacks(player.method_31548().field_7544, damageTaken);
    }

    private static void repairDheathicStacks(class_2371<class_1799> stacks, float damageTaken) {
        for (class_1799 stack : stacks) {
            if (!(stack.method_7909() instanceof class_1831) || stack.method_7919() <= 0
                || class_1890.method_8225(ModEnchantments.DHEATHIC, stack) <= 0) {
                continue;
            }
            int repair = Math.max(1, (int) Math.ceil(stack.method_7919() * 0.30D)
                + (int) Math.ceil(damageTaken * 8.0D));
            stack.method_7974(Math.max(0, stack.method_7919() - repair));
        }
    }

    private static void onDeath(class_1309 entity, class_1282 source) {
        if (entity.method_5864() == class_1299.field_6116) {
            entity.method_5775(class_1772.method_7808(
                new class_1889(ModEnchantments.DHEATHIC, 1)));
        }

        if (!(entity instanceof class_1657 player)) {
            return;
        }
        boolean instantProjectileOrFall = source.method_5526() instanceof class_1676 || source.method_49708(class_8111.field_42345);
        if (instantProjectileOrFall && !SURVIVED_DAMAGE_THIS_LIFE.contains(player.method_5667())) {
            removeDheathicTools(player.method_31548().field_7547);
            removeDheathicTools(player.method_31548().field_7548);
            removeDheathicTools(player.method_31548().field_7544);
        }
        SURVIVED_DAMAGE_THIS_LIFE.remove(player.method_5667());
    }

    private static void removeDheathicTools(class_2371<class_1799> stacks) {
        for (int index = 0; index < stacks.size(); index++) {
            class_1799 stack = stacks.get(index);
            if (stack.method_7909() instanceof class_1831
                && class_1890.method_8225(ModEnchantments.DHEATHIC, stack) > 0) {
                stacks.set(index, class_1799.field_8037);
            }
        }
    }
}
