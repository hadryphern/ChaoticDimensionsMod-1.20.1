package net.blue.chaoticd.content.enchantment;

import net.minecraft.class_1304;
import net.minecraft.class_1886;
import net.minecraft.class_1887;

/** Portuguese-named bow enchantment that greatly reduces draw time. */
public final class DisparadaEnchantment extends class_1887 {
    public DisparadaEnchantment() {
        super(class_1888.field_9088, class_1886.field_9070, new class_1304[] {class_1304.field_6173});
    }

    @Override
    public int method_8183() {
        return 5;
    }
}
