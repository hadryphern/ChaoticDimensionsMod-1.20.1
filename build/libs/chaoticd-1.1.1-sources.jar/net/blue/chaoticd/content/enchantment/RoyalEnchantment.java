package net.blue.chaoticd.content.enchantment;

import net.blue.chaoticd.content.ModEnchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1886;
import net.minecraft.class_1887;

/** A stronger Big Bertha variant: more reach and ten times sword damage. */
public final class RoyalEnchantment extends class_1887 {
    public RoyalEnchantment() {
        super(class_1888.field_9091, class_1886.field_9074, new class_1304[] {class_1304.field_6173});
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return stack.method_7909() instanceof class_1829;
    }

    @Override
    public int method_8183() {
        return 4;
    }

    @Override
    public boolean method_8180(class_1887 other) {
        return other != ModEnchantments.BIG_BERTHA && super.method_8180(other);
    }
}
