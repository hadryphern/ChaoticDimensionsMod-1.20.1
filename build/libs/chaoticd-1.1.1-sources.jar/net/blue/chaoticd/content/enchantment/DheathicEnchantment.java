package net.blue.chaoticd.content.enchantment;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.minecraft.class_1893;

/** A treasure-only repair enchantment for tiered tools and weapons. */
public final class DheathicEnchantment extends class_1887 {
    public DheathicEnchantment() {
        super(class_1888.field_9091, class_1886.field_9082, new class_1304[] {class_1304.field_6173});
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return stack.method_7909() instanceof class_1831;
    }

    @Override
    public int method_8183() {
        return 1;
    }

    @Override
    public boolean method_8193() {
        return true;
    }

    @Override
    public boolean method_25949() {
        return false;
    }

    @Override
    public boolean method_25950() {
        return false;
    }

    @Override
    public boolean method_8180(class_1887 other) {
        return other != class_1893.field_9101 && other != class_1893.field_9099 && super.method_8180(other);
    }
}
