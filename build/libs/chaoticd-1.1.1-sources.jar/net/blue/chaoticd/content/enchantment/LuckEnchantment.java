package net.blue.chaoticd.content.enchantment;

import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;

/**
 * Encantamento oculto exclusivo dos equipamentos de Esmeralda.
 *
 * <p>O encantamento Sorte não aparece na mesa de encantamentos,
 * não é vendido por villagers e não pode surgir aleatoriamente
 * em loot ou livros encantados.</p>
 *
 * <p>Ele é aplicado automaticamente pelo sistema de inicialização
 * dos equipamentos de Esmeralda.</p>
 */
public final class LuckEnchantment extends class_1887 {
    public LuckEnchantment() {
        super(
            class_1888.field_9091,
            class_1886.field_9082,
            class_1304.values()
        );
    }

    /**
     * Define o custo mínimo interno do encantamento.
     *
     * <p>Este valor praticamente não será utilizado porque Sorte
     * não pode aparecer naturalmente na mesa de encantamentos.</p>
     */
    @Override
    public int method_8182(int level) {
        return 1;
    }

    /**
     * Define o custo máximo interno do encantamento.
     */
    @Override
    public int method_20742(int level) {
        return 100;
    }

    /**
     * Sorte possui cinco níveis.
     */
    @Override
    public int method_8183() {
        return 5;
    }

    /**
     * Permite que Sorte exista apenas nos equipamentos
     * de Esmeralda registrados pelo mod.
     */
    @Override
    public boolean method_8192(class_1799 stack) {
        return ModItems.isEmeraldGear(stack);
    }

    /**
     * Marca Sorte como um encantamento especial.
     */
    @Override
    public boolean method_8193() {
        return true;
    }

    /**
     * Impede villagers bibliotecários de venderem Sorte.
     */
    @Override
    public boolean method_25949() {
        return false;
    }

    /**
     * Impede Sorte de aparecer na mesa de encantamentos,
     * em loot aleatório e em outras seleções vanilla.
     */
    @Override
    public boolean method_25950() {
        return false;
    }
}