package net.blue.chaoticd.content.enchantment;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1886;
import net.minecraft.class_1887;

/** Applies the disorienting Sapphiric effect to direct sword melee hits. */
public final class SapphiricEnchantment extends class_1887 {
    public SapphiricEnchantment() {
        super(class_1888.field_9088, class_1886.field_9074, new class_1304[] {class_1304.field_6173});
    }

    @Override
    public int method_8183() {
        return 5;
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return stack.method_7909() instanceof class_1829;
    }

    @Override
    public int method_8182(int level) {
        return 12 + level * 10;
    }

    @Override
    public int method_20742(int level) {
        return method_8182(level) + 18;
    }
}
