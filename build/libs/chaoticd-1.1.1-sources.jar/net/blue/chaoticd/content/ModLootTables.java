package net.blue.chaoticd.content;

import java.util.Set;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

/** Very rare Ruby Nugget injection into requested vanilla dungeon chests. */
public final class ModLootTables {
    private static final float RUBY_NUGGET_CHANCE = 0.02F;

    private static final Set<class_2960> RUBY_NUGGET_CHESTS = Set.of(
        vanilla("chests/simple_dungeon"),
        vanilla("chests/abandoned_mineshaft"),
        vanilla("chests/nether_bridge"),
        vanilla("chests/bastion_bridge"),
        vanilla("chests/bastion_hoglin_stable"),
        vanilla("chests/bastion_other"),
        vanilla("chests/bastion_treasure"),
        vanilla("chests/end_city_treasure"),
        vanilla("chests/stronghold_corridor"),
        vanilla("chests/stronghold_crossing"),
        vanilla("chests/stronghold_library"),
        vanilla("chests/ancient_city"),
        vanilla("chests/woodland_mansion"),
        vanilla("chests/desert_pyramid"),
        vanilla("chests/jungle_temple"),
        vanilla("chests/ruined_portal"),
        vanilla("chests/shipwreck_treasure")
    );

    private ModLootTables() {
    }

    public static void initialize() {
        LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
            if (!source.isBuiltin() || !RUBY_NUGGET_CHESTS.contains(id)) {
                return;
            }

            class_55.class_56 pool = class_55.method_347()
                .method_352(class_44.method_32448(1.0F))
                .method_356(class_219.method_932(RUBY_NUGGET_CHANCE))
                .method_351(
                    class_77.method_411(ModItems.RUBY_NUGGET)
                        .method_438(
                            class_141.method_621(
                                class_5662.method_32462(1.0F, 2.0F)
                            )
                        )
                );

            tableBuilder.pool(pool.method_355());
            
        });
    }

    private static class_2960 vanilla(String path) {
        return new class_2960("minecraft", path);
    }
}
