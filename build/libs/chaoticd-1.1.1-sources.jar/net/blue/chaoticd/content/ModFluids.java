package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.fluid.DreamFluid;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_7923;

/** Registers both source and flowing states of Dream Fluid. */
public final class ModFluids {
    public static final class_3609 FLOWING_DREAM_FLUID = register(
        "flowing_dream_fluid",
        new DreamFluid.Flowing()
    );

    public static final class_3609 DREAM_FLUID = register(
        "dream_fluid",
        new DreamFluid.Source()
    );

    private ModFluids() {
    }

    private static class_3609 register(String id, class_3609 fluid) {
        return class_2378.method_10230(
            class_7923.field_41173,
            new class_2960(ChaoticDimensions.MOD_ID, id),
            fluid
        );
    }

    public static void initialize() {
        // Static fields perform registry insertion.
    }
}
