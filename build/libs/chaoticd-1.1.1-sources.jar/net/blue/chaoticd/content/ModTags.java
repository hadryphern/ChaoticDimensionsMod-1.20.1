package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

/** Central tag keys used by code-backed Chaotic Dimensions systems. */
public final class ModTags {
    public static final class_6862<class_3611> DREAM_FLUID =
        class_6862.method_40092(
            class_7924.field_41270,
            id("dream_fluid")
        );

    /**
     * Dream Fluid structures that can be located while inside Aurora.
     */
    public static final class_6862<class_3195>
        DREAM_FLUID_AURORA_STRUCTURES =
        class_6862.method_40092(
            class_7924.field_41246,
            id("dream_fluid_aurora")
        );

    /**
     * Underground and sky Dream Fluid structures in the Overworld.
     */
    public static final class_6862<class_3195>
        DREAM_FLUID_OVERWORLD_STRUCTURES =
        class_6862.method_40092(
            class_7924.field_41246,
            id("dream_fluid_overworld")
        );

    private ModTags() {
    }

    private static class_2960 id(
        String path
    ) {
        return new class_2960(
            ChaoticDimensions.MOD_ID,
            path
        );
    }
}
