package net.blue.chaoticd.content.worldgen;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_7138;

/** Finds a safe landing area on ordinary Aurora terrain without creating or changing blocks. */
public final class AuroraSafeArrival {
    private static final int SEARCH_STEP = 24;
    private static final int MAX_SEARCH_RADIUS = 2048;
    private static final int SAFE_FOOTPRINT_RADIUS = 7;
    private static final int MAX_SURFACE_VARIATION = 5;
    private static final int MIN_ARRIVAL_Y = 80;

    private AuroraSafeArrival() {
    }

    public static Optional<class_2338> find(class_3218 level) {
        class_2794 generator = level.method_14178().method_12129();
        class_7138 randomState = level.method_14178().method_41248();
        Map<Long, Integer> heightCache = new HashMap<>();

        Optional<class_2338> origin = inspect(level, generator, randomState, heightCache, 0, 0);
        if (origin.isPresent()) {
            return origin;
        }

        for (int radius = SEARCH_STEP; radius <= MAX_SEARCH_RADIUS; radius += SEARCH_STEP) {
            for (int offset = -radius; offset <= radius; offset += SEARCH_STEP) {
                Optional<class_2338> candidate = inspect(level, generator, randomState, heightCache, -radius, offset);
                if (candidate.isPresent()) return candidate;

                candidate = inspect(level, generator, randomState, heightCache, radius, offset);
                if (candidate.isPresent()) return candidate;
            }
            for (int offset = -radius + SEARCH_STEP; offset < radius; offset += SEARCH_STEP) {
                Optional<class_2338> candidate = inspect(level, generator, randomState, heightCache, offset, -radius);
                if (candidate.isPresent()) return candidate;

                candidate = inspect(level, generator, randomState, heightCache, offset, radius);
                if (candidate.isPresent()) return candidate;
            }
        }

        return Optional.empty();
    }

    private static Optional<class_2338> inspect(class_3218 level, class_2794 generator, class_7138 randomState,
                                               Map<Long, Integer> heightCache, int x, int z) {
        int centerHeight = height(generator, level, randomState, heightCache, x, z);
        if (!isUsableHeight(level, centerHeight)) {
            return Optional.empty();
        }

        int minimum = centerHeight;
        int maximum = centerHeight;
        int radius = SAFE_FOOTPRINT_RADIUS;
        int[][] samples = {
            {radius, 0}, {-radius, 0}, {0, radius}, {0, -radius},
            {radius, radius}, {radius, -radius}, {-radius, radius}, {-radius, -radius}
        };
        for (int[] sample : samples) {
            int sampledHeight = height(generator, level, randomState, heightCache, x + sample[0], z + sample[1]);
            if (!isUsableHeight(level, sampledHeight)) {
                return Optional.empty();
            }
            minimum = Math.min(minimum, sampledHeight);
            maximum = Math.max(maximum, sampledHeight);
        }
        if (maximum - minimum > MAX_SURFACE_VARIATION) {
            return Optional.empty();
        }

        level.method_8497(x >> 4, z >> 4);
        int feetY = level.method_8624(class_2902.class_2903.field_13203, x, z);
        class_2338 feet = new class_2338(x, feetY, z);
        if (feetY < MIN_ARRIVAL_Y
            || feetY >= level.method_31600() - 2
            || level.method_8320(feet.method_10074()).method_26215()
            || !level.method_8320(feet).method_26215()
            || !level.method_8320(feet.method_10084()).method_26215()) {
            return Optional.empty();
        }
        return Optional.of(feet);
    }

    private static int height(class_2794 generator, class_3218 level, class_7138 randomState,
                              Map<Long, Integer> cache, int x, int z) {
        long key = class_2338.method_10064(x, 0, z);
        return cache.computeIfAbsent(key, ignored -> generator.method_16397(
            x, z, class_2902.class_2903.field_13194, level, randomState));
    }

    private static boolean isUsableHeight(class_3218 level, int height) {
        return height >= MIN_ARRIVAL_Y && height < level.method_31600() - 2;
    }
}
