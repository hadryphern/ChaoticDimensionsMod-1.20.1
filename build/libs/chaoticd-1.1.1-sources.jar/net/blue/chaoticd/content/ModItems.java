package net.blue.chaoticd.content;

import java.util.Map;
import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.item.ChaoticAppleItem;
import net.blue.chaoticd.content.item.CrystalineSeeItem;
import net.blue.chaoticd.content.item.DeathTotemItem;
import net.blue.chaoticd.content.item.EmeraldArmorMaterial;
import net.blue.chaoticd.content.item.EmeraldTier;
import net.blue.chaoticd.content.item.LeatherBackpackItem;
import net.blue.chaoticd.content.item.RubyArmorMaterial;
import net.blue.chaoticd.content.item.RubyTier;
import net.blue.chaoticd.content.item.TitaniumTier;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1814;
import net.minecraft.class_1821;
import net.minecraft.class_1826;
import net.minecraft.class_1829;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7923;
import net.blue.chaoticd.content.item.SapphireSwordItem;
import net.blue.chaoticd.content.item.SapphireTier;

/** Items belonging to Chaotic Dimensions progression. */
public final class ModItems {
    public static final class_1792 SAPPHIRE_GEM = register(
        "sapphire_gem",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 SAPPHIRE_SWORD = register(
        "sapphire_sword",
        new SapphireSwordItem(new class_1792.class_1793())
    );

    public static final class_1792 SAPPHIRE_PICKAXE = register(
        "sapphire_pickaxe",
        new class_1810(
            SapphireTier.INSTANCE,
            1,
            -2.8F,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 SAPPHIRE_AXE = register(
        "sapphire_axe",
        new class_1743(
            SapphireTier.INSTANCE,
            7.0F,
            -3.0F,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 SAPPHIRE_SHOVEL = register(
        "sapphire_shovel",
        new class_1821(
            SapphireTier.INSTANCE,
            1.5F,
            -3.0F,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 SAPPHIRE_HOE = register(
        "sapphire_hoe",
        new class_1794(
            SapphireTier.INSTANCE,
            -2,
            -1.0F,
            new class_1792.class_1793()
        )
    );

    public static final class_1792 CHAOTIC_APPLE = register(
        "chaotic_apple",
        new ChaoticAppleItem(
            new class_1792.class_1793().method_19265(
                new class_4174.class_4175()
                    .method_19238(8)
                    .method_19237(1.2F)
                    .method_19240()
                    .method_19242()
            )
        )
    );

    public static final class_1792 DEATH_TOTEM = register(
        "death_totem",
        new DeathTotemItem(
            new class_1792.class_1793()
                .method_7889(1)
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_INGOT = register(
        "emerald_ingot",
        new class_1792(
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 DREAM_FLUID_BUCKET = register(
        "dream_fluid_bucket",
        new class_1755(
            ModFluids.DREAM_FLUID,
            new class_1792.class_1793()
                .method_7896(class_1802.field_8550)
                .method_7889(1)
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 CRYSTALINE_SEE = register(
        "crystaline_see",
        new CrystalineSeeItem(
            new class_1792.class_1793()
                .method_7889(16)
                .method_7894(class_1814.field_8904)
        )
    );



    public static final class_1792 CRYSTALINE_EYE = register(
        "crystaline_eye",
        new class_1792(new class_1792.class_1793().method_7889(16).method_7894(class_1814.field_8903))
    );

    public static final class_1792 GOLD_SPECIAL_APPLE = register(
        "gold_special_apple",
        new class_1792(new class_1792.class_1793().method_19265(
            new class_4174.class_4175()
                .method_19238(8)
                .method_19237(1.2F)
                .method_19240()
                .method_19242()
        ))
    );

    public static final class_1792 DIMENSION_APPLE = register(
        "dimension_apple",
        new class_1792(new class_1792.class_1793().method_19265(
            new class_4174.class_4175()
                .method_19238(6)
                .method_19237(0.8F)
                .method_19240()
                .method_19242()
        ))
    );

    public static final class_1792 LEATHER_BACKPACK = register(
        "leather_backpack",
        new LeatherBackpackItem(new class_1792.class_1793().method_7889(1))
    );

    public static final class_1792 BEDROCK_STICK = register(
        "bedrock_stick",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 ROSALITA_GEM = register(
        "rosalita_gem",
        new class_1792(new class_1792.class_1793().method_7894(class_1814.field_8903))
    );

    public static final class_1792 WATER_INGOT = register(
        "water_ingot",
        new class_1792(new class_1792.class_1793().method_7894(class_1814.field_8903))
    );

    public static final class_1792 LAVA_INGOT = register(
        "lava_ingot",
        new class_1792(new class_1792.class_1793().method_24359().method_7894(class_1814.field_8903))
    );

    public static final class_1792 TITANIUM_INGOT = register(
        "titanium_ingot",
        new class_1792(new class_1792.class_1793())
    );

    public static final class_1792 TITANIUM_SWORD = register(
        "titanium_sword",
        new class_1829(TitaniumTier.INSTANCE, 3, -2.4F, new class_1792.class_1793())
    );

    public static final class_1792 TITANIUM_PICKAXE = register(
        "titanium_pickaxe",
        new class_1810(TitaniumTier.INSTANCE, 1, -2.8F, new class_1792.class_1793())
    );

    public static final class_1792 TITANIUM_AXE = register(
        "titanium_axe",
        new class_1743(TitaniumTier.INSTANCE, 6.0F, -3.0F, new class_1792.class_1793())
    );

    public static final class_1792 TITANIUM_SHOVEL = register(
        "titanium_shovel",
        new class_1821(TitaniumTier.INSTANCE, 1.5F, -3.0F, new class_1792.class_1793())
    );

    public static final class_1792 TITANIUM_HOE = register(
        "titanium_hoe",
        new class_1794(TitaniumTier.INSTANCE, -3, 0.0F, new class_1792.class_1793())
    );

    public static final class_1792 RUBY_NUGGET = register(
        "ruby_nugget",
        new class_1792(new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904))
    );

    public static final class_1792 RUBY = register(
        "ruby",
        new class_1792(new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904))
    );

    public static final class_1792 RUBY_PLATE = register(
        "ruby_plate",
        new class_1792(new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904))
    );

    public static final class_1792 RUBY_SWORD = register(
        "ruby_sword",
        new class_1829(
            RubyTier.INSTANCE,
            14,
            -2.0F,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 RUBY_PICKAXE = register(
        "ruby_pickaxe",
        new class_1810(
            RubyTier.INSTANCE,
            6,
            -2.4F,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 RUBY_AXE = register(
        "ruby_axe",
        new class_1743(
            RubyTier.INSTANCE,
            22.0F,
            -2.6F,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 RUBY_SHOVEL = register(
        "ruby_shovel",
        new class_1821(
            RubyTier.INSTANCE,
            8.0F,
            -2.4F,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 RUBY_HOE = register(
        "ruby_hoe",
        new class_1794(
            RubyTier.INSTANCE,
            -8,
            0.0F,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 RUBY_HELMET = register(
        "ruby_helmet",
        new class_1738(
            RubyArmorMaterial.INSTANCE,
            class_1738.class_8051.field_41934,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 RUBY_CHESTPLATE = register(
        "ruby_chestplate",
        new class_1738(
            RubyArmorMaterial.INSTANCE,
            class_1738.class_8051.field_41935,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 RUBY_LEGGINGS = register(
        "ruby_leggings",
        new class_1738(
            RubyArmorMaterial.INSTANCE,
            class_1738.class_8051.field_41936,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 RUBY_BOOTS = register(
        "ruby_boots",
        new class_1738(
            RubyArmorMaterial.INSTANCE,
            class_1738.class_8051.field_41937,
            new class_1792.class_1793().method_24359().method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 DIMENSION_PIG_SPAWN_EGG = register(
        "dimension_pig_spawn_egg",
        new class_1826(ModEntities.DIMENSION_PIG, 0x8A4B79, 0xE5A6D7, new class_1792.class_1793())
    );

    public static final class_1792 GOLD_DIMENSION_PIG_SPAWN_EGG = register(
        "gold_dimension_pig_spawn_egg",
        new class_1826(ModEntities.GOLD_DIMENSION_PIG, 0xD5A82A, 0xFFF08A, new class_1792.class_1793())
    );

    public static final class_1792 APPLE_COW_SPAWN_EGG = register(
        "apple_cow_spawn_egg",
        new class_1826(ModEntities.APPLE_COW, 0x6C2E1A, 0xD92B2B, new class_1792.class_1793())
    );

    public static final class_1792 GOLDEN_APPLE_COW_SPAWN_EGG = register(
        "golden_apple_cow_spawn_egg",
        new class_1826(ModEntities.GOLDEN_APPLE_COW, 0xC69A23, 0xFFF1A0, new class_1792.class_1793())
    );

    public static final class_1792 CRYSTAL_APPLE_COW_SPAWN_EGG = register(
        "crystal_apple_cow_spawn_egg",
        new class_1826(ModEntities.CRYSTAL_APPLE_COW, 0x8D6FD1, 0x65E6F4, new class_1792.class_1793())
    );

    public static final class_1792 CRYSTAL_GOLDEN_APPLE_SPAWN_EGG = register(
        "crystal_golden_apple_spawn_egg",
        new class_1826(ModEntities.CRYSTAL_GOLDEN_APPLE, 0xA96ED4, 0xFFD75A, new class_1792.class_1793())
    );

    public static final class_1792 CRYSTAL_CREEPER_SPAWN_EGG = register(
        "crystal_creeper_spawn_egg",
        new class_1826(ModEntities.CRYSTAL_CREEPER, 0x7869C6, 0xD6F5FF, new class_1792.class_1793())
    );

    /*
     * The Emerald tools are built around a tier with twice Netherite's
     * durability, mining speed and attack bonus.
     *
     * Their constructor damage values were also adjusted so the final attacks
     * remain a clear direct upgrade instead of merely reusing Netherite values.
     */
    public static final class_1792 EMERALD_SWORD = register(
        "emerald_sword",
        new class_1829(
            EmeraldTier.INSTANCE,
            7,
            -2.4F,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_PICKAXE = register(
        "emerald_pickaxe",
        new class_1810(
            EmeraldTier.INSTANCE,
            3,
            -2.8F,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_AXE = register(
        "emerald_axe",
        new class_1743(
            EmeraldTier.INSTANCE,
            11.0F,
            -3.0F,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_SHOVEL = register(
        "emerald_shovel",
        new class_1821(
            EmeraldTier.INSTANCE,
            4.0F,
            -3.0F,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_HOE = register(
        "emerald_hoe",
        new class_1794(
            EmeraldTier.INSTANCE,
            -4,
            0.0F,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_HELMET = register(
        "emerald_helmet",
        new class_1738(
            EmeraldArmorMaterial.INSTANCE,
            class_1738.class_8051.field_41934,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_CHESTPLATE = register(
        "emerald_chestplate",
        new class_1738(
            EmeraldArmorMaterial.INSTANCE,
            class_1738.class_8051.field_41935,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_LEGGINGS = register(
        "emerald_leggings",
        new class_1738(
            EmeraldArmorMaterial.INSTANCE,
            class_1738.class_8051.field_41936,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    public static final class_1792 EMERALD_BOOTS = register(
        "emerald_boots",
        new class_1738(
            EmeraldArmorMaterial.INSTANCE,
            class_1738.class_8051.field_41937,
            new class_1792.class_1793()
                .method_24359()
                .method_7894(class_1814.field_8904)
        )
    );

    private ModItems() {
    }

    private static class_1792 register(String id, class_1792 item) {
        return class_2378.method_10230(
            class_7923.field_41178,
            new class_2960(
                ChaoticDimensions.MOD_ID,
                id
            ),
            item
        );
    }

    /**
     * Canonical Sapphire Sword stack used after it actually enters a player's
     * inventory. Creative tabs intentionally use the raw item instead.
     */
    public static class_1799 createSapphireSword() {
        class_1799 result =
            new class_1799(SAPPHIRE_SWORD);

        class_1890.method_8214(
            Map.of(
                ModEnchantments.SAPPHIRIC,
                1,
                ModEnchantments.DHEATHIC,
                1
            ),
            result
        );

        return result;
    }

    public static class_1799 createSapphireTool(
        SapphireToolType type
    ) {
        class_1799 result =
            new class_1799(type.item());

        Map<
            net.minecraft.class_1887,
            Integer
        > enchantments =
            switch (type) {
                case PICKAXE -> Map.of(
                    class_1893.field_9130,
                    50,
                    class_1893.field_9131,
                    50,
                    class_1893.field_9119,
                    50
                );
                case AXE -> Map.of(
                    class_1893.field_9130,
                    50,
                    class_1893.field_9131,
                    50,
                    class_1893.field_9119,
                    50,
                    class_1893.field_9118,
                    50
                );
                case SHOVEL, HOE -> Map.of(
                    class_1893.field_9131,
                    50,
                    class_1893.field_9119,
                    50
                );
            };

        class_1890.method_8214(
            enchantments,
            result
        );

        return result;
    }

    public static boolean isSapphireGear(
        class_1799 stack
    ) {
        return stack.method_31574(SAPPHIRE_SWORD)
            || stack.method_31574(SAPPHIRE_PICKAXE)
            || stack.method_31574(SAPPHIRE_AXE)
            || stack.method_31574(SAPPHIRE_SHOVEL)
            || stack.method_31574(SAPPHIRE_HOE);
    }

    public static boolean isEmeraldGear(
        class_1799 stack
    ) {
        return stack.method_31574(EMERALD_SWORD)
            || stack.method_31574(EMERALD_PICKAXE)
            || stack.method_31574(EMERALD_AXE)
            || stack.method_31574(EMERALD_SHOVEL)
            || stack.method_31574(EMERALD_HOE)
            || stack.method_31574(EMERALD_HELMET)
            || stack.method_31574(EMERALD_CHESTPLATE)
            || stack.method_31574(EMERALD_LEGGINGS)
            || stack.method_31574(EMERALD_BOOTS);
    }

    public static boolean isEmeraldArmor(
        class_1799 stack
    ) {
        return stack.method_31574(EMERALD_HELMET)
            || stack.method_31574(EMERALD_CHESTPLATE)
            || stack.method_31574(EMERALD_LEGGINGS)
            || stack.method_31574(EMERALD_BOOTS);
    }

    public enum SapphireToolType {
        PICKAXE(SAPPHIRE_PICKAXE),
        AXE(SAPPHIRE_AXE),
        SHOVEL(SAPPHIRE_SHOVEL),
        HOE(SAPPHIRE_HOE);

        private final class_1792 item;

        SapphireToolType(class_1792 item) {
            this.item = item;
        }

        public class_1792 item() {
            return item;
        }
    }

    public static void initialize() {
        // Static fields perform registry insertion.
    }
}
