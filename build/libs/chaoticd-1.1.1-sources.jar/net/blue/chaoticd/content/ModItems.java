package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.item.SapphireSwordItem;
import net.blue.chaoticd.content.item.SapphireTier;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7923;
import net.blue.chaoticd.content.item.ChaoticAppleItem;
import java.util.Map;

/** The first clean-slate items: the manual Sapphire assets and their sword. */
public final class ModItems {
    public static final class_1792 SAPPHIRE_GEM = register("sapphire_gem", new class_1792(new class_1792.class_1793()));
    public static final class_1792 SAPPHIRE_SWORD = register("sapphire_sword", new SapphireSwordItem(new class_1792.class_1793()));
    public static final class_1792 SAPPHIRE_PICKAXE = register("sapphire_pickaxe", new class_1810(SapphireTier.INSTANCE, 1, -2.8F, new class_1792.class_1793()));
    public static final class_1792 SAPPHIRE_AXE = register("sapphire_axe", new class_1743(SapphireTier.INSTANCE, 7.0F, -3.0F, new class_1792.class_1793()));
    public static final class_1792 SAPPHIRE_SHOVEL = register("sapphire_shovel", new class_1821(SapphireTier.INSTANCE, 1.5F, -3.0F, new class_1792.class_1793()));
    public static final class_1792 SAPPHIRE_HOE = register("sapphire_hoe", new class_1794(SapphireTier.INSTANCE, -2, -1.0F, new class_1792.class_1793()));
    public static final class_1792 CHAOTIC_APPLE = register("chaotic_apple", new ChaoticAppleItem(new class_1792.class_1793()
        .method_19265(new class_4174.class_4175().method_19238(8).method_19237(1.2F).method_19240().method_19242())));

    private ModItems() {
    }

    private static class_1792 register(String id, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(ChaoticDimensions.MOD_ID, id), item);
    }

    /** The canonical crafted form of the sword, including both of its defining enchantments. */
    public static class_1799 createSapphireSword() {
        class_1799 result = new class_1799(SAPPHIRE_SWORD);
        class_1890.method_8214(Map.of(
            ModEnchantments.SAPPHIRIC, 1,
            ModEnchantments.DHEATHIC, 1), result);
        return result;
    }

    public static class_1799 createSapphireTool(SapphireToolType type) {
        class_1799 result = new class_1799(type.item());
        Map<net.minecraft.class_1887, Integer> enchantments = switch (type) {
            case PICKAXE -> Map.of(class_1893.field_9130, 50, class_1893.field_9131, 50, class_1893.field_9119, 50);
            case AXE -> Map.of(class_1893.field_9130, 50, class_1893.field_9131, 50,
                class_1893.field_9119, 50, class_1893.field_9118, 50);
            case SHOVEL, HOE -> Map.of(class_1893.field_9131, 50, class_1893.field_9119, 50);
        };
        class_1890.method_8214(enchantments, result);
        return result;
    }

    public enum SapphireToolType {
        PICKAXE(SAPPHIRE_PICKAXE), AXE(SAPPHIRE_AXE), SHOVEL(SAPPHIRE_SHOVEL), HOE(SAPPHIRE_HOE);

        private final class_1792 item;

        SapphireToolType(class_1792 item) {
            this.item = item;
        }

        public class_1792 item() {
            return item;
        }
    }

    public static void initialize() {
        // Entries belong only to the Chaotic Dimensions category family.
    }
}
