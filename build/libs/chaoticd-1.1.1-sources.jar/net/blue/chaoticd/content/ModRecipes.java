package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.recipe.SapphireSwordRecipe;
import net.blue.chaoticd.content.recipe.SapphireToolRecipe;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Serializers for recipes which need to set data on their result. */
public final class ModRecipes {
    public static final class_1865<SapphireSwordRecipe> SAPPHIRE_SWORD = class_2378.method_10230(
        class_7923.field_41189,
        new class_2960(ChaoticDimensions.MOD_ID, "sapphire_sword"),
        new class_1866<>(SapphireSwordRecipe::new));
    public static final class_1865<SapphireToolRecipe> SAPPHIRE_TOOL = class_2378.method_10230(
        class_7923.field_41189,
        new class_2960(ChaoticDimensions.MOD_ID, "sapphire_tool"),
        new class_1866<>(SapphireToolRecipe::new));

    private ModRecipes() {
    }

    public static void initialize() {
        // Static registration is intentionally triggered during common initialization.
    }
}
