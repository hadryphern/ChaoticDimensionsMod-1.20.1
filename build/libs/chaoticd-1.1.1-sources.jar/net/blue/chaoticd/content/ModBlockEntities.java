package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.block.CrystalFurnaceBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Block entity registrations used by restored functional legacy blocks. */
public final class ModBlockEntities {
    public static final class_2591<CrystalFurnaceBlockEntity> CRYSTAL_FURNACE =
        class_2378.method_10230(
            class_7923.field_41181,
            new class_2960(ChaoticDimensions.MOD_ID, "crystal_furnace"),
            FabricBlockEntityTypeBuilder.create(
                CrystalFurnaceBlockEntity::new,
                ModBlocks.CRYSTAL_FURNACE
            ).build()
        );

    private ModBlockEntities() {
    }

    public static void initialize() {
        // Static field performs registry insertion.
    }
}
