package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.effect.SapphiricEffect;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Registers effects that are shared by the server and all connected clients. */
public final class ModEffects {
    public static final class_1291 SAPPHIRIC = class_2378.method_10230(class_7923.field_41174,
        new class_2960(ChaoticDimensions.MOD_ID, "sapphiric"), new SapphiricEffect());

    private ModEffects() {
    }

    public static void initialize() {
        // Referencing the class performs the registry registration above.
    }
}
