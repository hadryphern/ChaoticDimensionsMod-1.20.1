package net.blue.chaoticd.content.recipe;

import net.blue.chaoticd.content.ModItems;
import net.blue.chaoticd.content.ModRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

/** Two Sapphire Gems above a stick; results are born with both defining enchantments. */
public final class SapphireSwordRecipe extends class_1852 {
    public SapphireSwordRecipe(class_2960 id, class_7710 category) {
        super(id, category);
    }

    @Override
    public boolean matches(class_8566 inventory, class_1937 level) {
        if (inventory.method_17398() < 1 || inventory.method_17397() < 3) {
            return false;
        }
        for (int candidateColumn = 0; candidateColumn < inventory.method_17398(); candidateColumn++) {
            boolean matches = true;
            for (int x = 0; x < inventory.method_17398() && matches; x++) {
                for (int y = 0; y < inventory.method_17397(); y++) {
                    class_1799 stack = inventory.method_5438(x + y * inventory.method_17398());
                    if (x == candidateColumn && y < 2 && stack.method_31574(ModItems.SAPPHIRE_GEM)) {
                        continue;
                    }
                    if (x == candidateColumn && y == 2 && stack.method_31574(class_1802.field_8600)) {
                        continue;
                    }
                    if (!stack.method_7960()) {
                        matches = false;
                        break;
                    }
                }
            }
            if (matches) {
                return true;
            }
        }
        return false;
    }

    @Override
    public class_1799 assemble(class_8566 inventory, class_5455 registries) {
        return ModItems.createSapphireSword();
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width >= 1 && height >= 3;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipes.SAPPHIRE_SWORD;
    }
}
