package net.blue.chaoticd.content.recipe;

import net.blue.chaoticd.content.ModItems;
import net.blue.chaoticd.content.ModItems.SapphireToolType;
import net.blue.chaoticd.content.ModRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

/** Sapphire tool recipes whose crafted result starts with its intended enchantments. */
public final class SapphireToolRecipe extends class_1852 {
    public SapphireToolRecipe(class_2960 id, class_7710 category) {
        super(id, category);
    }

    @Override
    public boolean matches(class_8566 inventory, class_1937 level) {
        SapphireToolType type = type();
        return type != null && matchesPattern(inventory, type);
    }

    @Override
    public class_1799 assemble(class_8566 inventory, class_5455 registries) {
        SapphireToolType type = type();
        return type == null ? class_1799.field_8037 : ModItems.createSapphireTool(type);
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width >= 2 && height >= 3;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipes.SAPPHIRE_TOOL;
    }

    private SapphireToolType type() {
        return switch (method_8114().method_12832()) {
            case "sapphire_pickaxe" -> SapphireToolType.PICKAXE;
            case "sapphire_axe" -> SapphireToolType.AXE;
            case "sapphire_shovel" -> SapphireToolType.SHOVEL;
            case "sapphire_hoe" -> SapphireToolType.HOE;
            default -> null;
        };
    }

    private static boolean matchesPattern(class_8566 inventory, SapphireToolType type) {
        String[] pattern = switch (type) {
            case PICKAXE -> new String[] {"GGG", " S ", " S "};
            case AXE -> new String[] {"GG ", "GS ", " S "};
            case SHOVEL -> new String[] {"G", "S", "S"};
            case HOE -> new String[] {"GG ", " S ", " S "};
        };
        int width = pattern[0].length();
        for (int offsetX = 0; offsetX <= inventory.method_17398() - width; offsetX++) {
            if (matchesAt(inventory, pattern, offsetX)) {
                return true;
            }
        }
        return false;
    }

    private static boolean matchesAt(class_8566 inventory, String[] pattern, int offsetX) {
        for (int x = 0; x < inventory.method_17398(); x++) {
            for (int y = 0; y < inventory.method_17397(); y++) {
                char expected = x >= offsetX && x < offsetX + pattern[0].length() && y < pattern.length
                    ? pattern[y].charAt(x - offsetX) : ' ';
                class_1799 stack = inventory.method_5438(x + y * inventory.method_17398());
                if (expected == 'G' && stack.method_31574(ModItems.SAPPHIRE_GEM)) continue;
                if (expected == 'S' && stack.method_31574(class_1802.field_8600)) continue;
                if (expected == ' ' && stack.method_7960()) continue;
                return false;
            }
        }
        return true;
    }
}
