package net.blue.chaoticd.content.item;

import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

/** Shared material rules for every Sapphire tool and weapon. */
public final class SapphireTier implements class_1832 {
    public static final SapphireTier INSTANCE = new SapphireTier();

    private SapphireTier() {
    }

    @Override
    public int method_8025() {
        return 3000;
    }

    @Override
    public float method_8027() {
        return 12.0F;
    }

    @Override
    public float method_8028() {
        return 0.0F;
    }

    @Override
    public int method_8024() {
        return 4;
    }

    @Override
    public int method_8026() {
        return 25;
    }

    @Override
    public class_1856 method_8023() {
        return class_1856.method_8091(ModItems.SAPPHIRE_GEM);
    }
}
