package net.blue.chaoticd.content.item;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

/** Armor material with twice every base Emerald armor attribute. */
public enum RubyArmorMaterial implements class_1741 {
    INSTANCE;

    private static final int DURABILITY_MULTIPLIER = 148;

    @Override
    public int method_48402(class_1738.class_8051 type) {
        return switch (type) {
            case field_41937 -> 13 * DURABILITY_MULTIPLIER;
            case field_41936 -> 15 * DURABILITY_MULTIPLIER;
            case field_41935 -> 16 * DURABILITY_MULTIPLIER;
            case field_41934 -> 11 * DURABILITY_MULTIPLIER;
        };
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        return switch (type) {
            case field_41937 -> 12;
            case field_41936 -> 24;
            case field_41935 -> 32;
            case field_41934 -> 12;
        };
    }

    @Override
    public int method_7699() {
        return 60;
    }

    @Override
    public class_3414 method_7698() {
        return class_3417.field_21866;
    }

    @Override
    public class_1856 method_7695() {
        return class_1856.method_8091(ModItems.RUBY);
    }

    @Override
    public String method_7694() {
        return ChaoticDimensions.MOD_ID + ":ruby";
    }

    @Override
    public float method_7700() {
        return 12.0F;
    }

    @Override
    public float method_24355() {
        return 0.40F;
    }
}
