package net.blue.chaoticd.content.item;

import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

/** Tool material that is exactly twice the Emerald material attributes. */
public enum RubyTier implements class_1832 {
    INSTANCE;

    @Override
    public int method_8025() {
        return 8_124;
    }

    @Override
    public float method_8027() {
        return 36.0F;
    }

    @Override
    public float method_8028() {
        return 16.0F;
    }

    @Override
    public int method_8024() {
        return 5;
    }

    @Override
    public int method_8026() {
        return 60;
    }

    @Override
    public class_1856 method_8023() {
        return class_1856.method_8091(ModItems.RUBY);
    }
}
