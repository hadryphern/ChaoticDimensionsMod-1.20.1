package net.blue.chaoticd.content.item;

import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1890;
import net.minecraft.class_238;
import net.blue.chaoticd.content.ModCombatEnchantments;
import net.blue.chaoticd.content.ModEnchantments;
import net.blue.chaoticd.content.ModEffects;

/** 589-damage sword with a 24-block-radius damage wave after a direct melee hit. */
public final class SapphireSwordItem extends class_1829 {
    public static final int DIRECT_DAMAGE = 589;
    public static final float AREA_DAMAGE = 589.0F;
    public static final double AREA_RADIUS = 24.0D;

    public SapphireSwordItem(class_1792.class_1793 properties) {
        super(SapphireTier.INSTANCE, DIRECT_DAMAGE, -2.4F, properties);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        boolean used = super.method_7873(stack, target, attacker);
        if (attacker.method_37908().field_9236 || !used) {
            return used;
        }

        class_238 area = target.method_5829().method_1014(AREA_RADIUS);
        int sapphiricLevel = class_1890.method_8225(ModEnchantments.SAPPHIRIC, stack);
        float areaDamage = AREA_DAMAGE * ModCombatEnchantments.damageMultiplier(stack);
        for (class_1309 nearby : attacker.method_37908().method_8390(class_1309.class, area,
            candidate -> candidate != attacker && candidate != target && candidate.method_5805())) {
            // A magic source has no melee attacker, so Sapphiric never propagates via the area wave.
            nearby.method_5643(attacker.method_48923().method_48831(), areaDamage);
            if (sapphiricLevel >= 5) {
                nearby.method_37222(new class_1293(ModEffects.SAPPHIRIC, 20 * 45), attacker);
            }
        }
        return used;
    }

}
