package net.blue.chaoticd.content.item;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

/**
 * Armor material representing the direct progression after Netherite.
 *
 * <p>The base material values are configured at twice the equivalent
 * Netherite values:</p>
 *
 * <ul>
 *     <li>Twice the durability multiplier: 74 instead of 37.</li>
 *     <li>Twice the armor points for every piece.</li>
 *     <li>Twice the toughness: 6 instead of 3.</li>
 *     <li>Twice the knockback resistance: 0.20 instead of 0.10.</li>
 *     <li>Twice the enchantability: 30 instead of 15.</li>
 * </ul>
 */
public enum EmeraldArmorMaterial implements class_1741 {
    INSTANCE;

    private static final int DURABILITY_MULTIPLIER = 74;

    @Override
    public int method_48402(class_1738.class_8051 type) {
        return switch (type) {
            case field_41937 -> 13 * DURABILITY_MULTIPLIER;
            case field_41936 -> 15 * DURABILITY_MULTIPLIER;
            case field_41935 -> 16 * DURABILITY_MULTIPLIER;
            case field_41934 -> 11 * DURABILITY_MULTIPLIER;
        };
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        return switch (type) {
            case field_41937 -> 6;
            case field_41936 -> 12;
            case field_41935 -> 16;
            case field_41934 -> 6;
        };
    }

    @Override
    public int method_7699() {
        return 30;
    }

    @Override
    public class_3414 method_7698() {
        return class_3417.field_21866;
    }

    @Override
    public class_1856 method_7695() {
        return class_1856.method_8091(ModItems.EMERALD_INGOT);
    }

    @Override
    public String method_7694() {
        return ChaoticDimensions.MOD_ID + ":emerald";
    }

    @Override
    public float method_7700() {
        return 6.0F;
    }

    @Override
    public float method_24355() {
        return 0.20F;
    }
}
