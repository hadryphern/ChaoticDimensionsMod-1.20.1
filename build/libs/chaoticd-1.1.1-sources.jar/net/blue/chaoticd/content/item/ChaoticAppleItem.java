package net.blue.chaoticd.content.item;

import java.util.Map;
import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.worldgen.AuroraSafeArrival;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/** A one-way Aurora Dimension food. Every physical apple carries Curse of Vanishing. */
public final class ChaoticAppleItem extends class_1792 {
    private static final class_5321<class_1937> AURORA_DIMENSION = class_5321.method_29179(class_7924.field_41223,
        new class_2960(ChaoticDimensions.MOD_ID, "aurora_dimension"));

    public ChaoticAppleItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1799 method_7854() {
        class_1799 stack = super.method_7854();
        applyCurse(stack);
        return stack;
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 entity, int slot, boolean selected) {
        applyCurse(stack);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 entity) {
        class_1799 result = super.method_7861(stack, level, entity);
        if (!level.field_9236 && entity instanceof class_3222 player) {
            class_3218 aurora = player.field_13995.method_3847(AURORA_DIMENSION);
            if (aurora != null) {
                AuroraSafeArrival.find(aurora).ifPresentOrElse(
                    arrival -> player.method_14251(aurora, arrival.method_10263() + 0.5D, arrival.method_10264() + 0.1D,
                        arrival.method_10260() + 0.5D, player.method_36454(), player.method_36455()),
                    () -> player.method_7353(class_2561.method_43471("message.chaoticd.aurora_no_safe_arrival"), false));
            }
        }
        return result;
    }

    private static void applyCurse(class_1799 stack) {
        if (!class_1890.method_8222(stack).containsKey(class_1893.field_9109)) {
            class_1890.method_8214(Map.of(class_1893.field_9109, 1), stack);
        }
    }
}
