package net.blue.chaoticd.content.item;

import net.minecraft.class_1792;
import net.minecraft.class_1799;

/** Extremely rare protection required to survive the Shadow Dimension normally. */
public final class DeathTotemItem extends class_1792 {
    public DeathTotemItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
