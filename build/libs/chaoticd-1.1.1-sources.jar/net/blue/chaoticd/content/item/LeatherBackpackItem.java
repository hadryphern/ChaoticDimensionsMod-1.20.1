package net.blue.chaoticd.content.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_747;

/** A basic leather backpack that opens a normal three-row chest inventory. */
public final class LeatherBackpackItem extends class_1792 {
    public LeatherBackpackItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(
        class_1937 level,
        class_1657 player,
        class_1268 hand
    ) {
        class_1799 backpack = player.method_5998(hand);

        if (!level.field_9236) {
            BackpackContainer container = new BackpackContainer(backpack);
            player.method_17355(new class_747(
                (containerId, inventory, ignoredPlayer) ->
                    class_1707.method_19245(containerId, inventory, container),
                class_2561.method_43471("container.chaoticd.leather_backpack")
            ));
        }

        return class_1271.method_29237(backpack, level.field_9236);
    }
}
