package net.blue.chaoticd.content.item;

import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

/**
 * Tool tier representing the direct progression after Netherite.
 *
 * <p>The important material attributes are twice their Netherite equivalents:
 * 4062 durability, 18 mining speed, 8 attack bonus and 30 enchantability.</p>
 */
public enum EmeraldTier implements class_1832 {
    INSTANCE;

    @Override
    public int method_8025() {
        return 4_062;
    }

    @Override
    public float method_8027() {
        return 18.0F;
    }

    @Override
    public float method_8028() {
        return 8.0F;
    }

    @Override
    public int method_8024() {
        return 4;
    }

    @Override
    public int method_8026() {
        return 30;
    }

    @Override
    public class_1856 method_8023() {
        return class_1856.method_8091(ModItems.EMERALD_INGOT);
    }
}
