package net.blue.chaoticd.content.item;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.ModTags;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1672;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

/**
 * Aurora-themed Eye of Ender that locates the nearest Dream Fluid lake.
 *
 * <p>In the Overworld it searches for either the underground cavern or the
 * extremely high floating lake. In Aurora it searches for the original
 * floating Dream Fluid island.</p>
 */
public final class CrystalineSeeItem extends class_1792 {
    private static final int SEARCH_RADIUS_CHUNKS = 256;

    private static final class_5321<class_1937>
        AURORA_DIMENSION =
        class_5321.method_29179(
            class_7924.field_41223,
            new class_2960(
                ChaoticDimensions.MOD_ID,
                "aurora_dimension"
            )
        );

    public CrystalineSeeItem(
        class_1793 properties
    ) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(
        class_1937 level,
        class_1657 player,
        class_1268 hand
    ) {
        class_1799 stack =
            player.method_5998(hand);

        if (level.field_9236) {
            return class_1271.method_22427(
                stack
            );
        }

        class_3218 serverLevel =
            (class_3218) level;

        class_6862<class_3195> targetTag =
            structureTagFor(serverLevel);

        if (targetTag == null) {
            player.method_7353(
                class_2561.method_43471(
                    "message.chaoticd.crystaline_see_wrong_dimension"
                ),
                true
            );

            return class_1271.method_22431(
                stack
            );
        }

        class_2338 target =
            serverLevel.method_8487(
                targetTag,
                player.method_24515(),
                SEARCH_RADIUS_CHUNKS,
                false
            );

        if (target == null) {
            player.method_7353(
                class_2561.method_43471(
                    "message.chaoticd.crystaline_see_not_found"
                ),
                true
            );

            return class_1271.method_22431(
                stack
            );
        }

        class_1672 locator =
            new class_1672(
                serverLevel,
                player.method_23317(),
                player.method_23318() + 0.5D,
                player.method_23321()
            );

        class_1799 displayedItem =
            stack.method_7972();

        displayedItem.method_7939(1);

        locator.method_16933(displayedItem);
        locator.method_7478(target);

        serverLevel.method_8649(locator);

        serverLevel.method_43128(
            null,
            player.method_23317(),
            player.method_23318(),
            player.method_23321(),
            class_3417.field_15155,
            class_3419.field_15254,
            0.5F,
            0.4F
                / (
                    serverLevel.method_8409()
                        .method_43057()
                        * 0.4F
                    + 0.8F
                )
        );

        serverLevel.method_8444(
            null,
            1003,
            player.method_24515(),
            0
        );

        if (
            !player.method_31549()
                .field_7477
        ) {
            stack.method_7934(1);
        }

        player.method_7259(
            class_3468.field_15372.method_14956(this)
        );

        if (player instanceof class_3222) {
            player.method_23667(hand, true);
        }

        return class_1271.method_22428(
            stack
        );
    }

    private static class_6862<class_3195>
        structureTagFor(
            class_3218 level
        ) {
        if (
            level.method_27983()
                .equals(class_1937.field_25179)
        ) {
            return ModTags
                .DREAM_FLUID_OVERWORLD_STRUCTURES;
        }

        if (
            level.method_27983()
                .equals(AURORA_DIMENSION)
        ) {
            return ModTags
                .DREAM_FLUID_AURORA_STRUCTURES;
        }

        return null;
    }
}
