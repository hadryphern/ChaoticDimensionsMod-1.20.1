package net.blue.chaoticd.content.item;

import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

/** A persistent 27-slot container backed by the backpack ItemStack NBT. */
public final class BackpackContainer extends class_1277 {
    private static final String ITEMS_TAG = "BackpackItems";
    private final class_1799 backpack;
    private boolean loading;

    public BackpackContainer(class_1799 backpack) {
        super(27);
        this.backpack = backpack;
        this.loading = true;
        load();
        this.loading = false;
    }

    private void load() {
        class_2487 tag = backpack.method_7948();
        if (!tag.method_10573(ITEMS_TAG, class_2520.field_33259)) {
            return;
        }

        class_2499 items = tag.method_10554(ITEMS_TAG, class_2520.field_33260);
        for (int index = 0; index < items.size(); index++) {
            class_2487 itemTag = items.method_10602(index);
            int slot = itemTag.method_10571("Slot") & 255;
            if (slot >= 0 && slot < method_5439()) {
                super.method_5447(slot, class_1799.method_7915(itemTag));
            }
        }
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return !(stack.method_7909() instanceof LeatherBackpackItem);
    }

    @Override
    public void method_5431() {
        super.method_5431();
        if (!loading) {
            save();
        }
    }

    private void save() {
        class_2499 items = new class_2499();

        for (int slot = 0; slot < method_5439(); slot++) {
            class_1799 stack = method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }

            class_2487 itemTag = new class_2487();
            itemTag.method_10567("Slot", (byte)slot);
            stack.method_7953(itemTag);
            items.add(itemTag);
        }

        backpack.method_7948().method_10566(ITEMS_TAG, items);
    }
}
