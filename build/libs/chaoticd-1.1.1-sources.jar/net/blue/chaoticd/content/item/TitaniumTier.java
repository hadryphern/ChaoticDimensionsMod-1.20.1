package net.blue.chaoticd.content.item;

import net.blue.chaoticd.content.ModItems;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

/** Basic Titanium tool material restored from the legacy content set. */
public enum TitaniumTier implements class_1832 {
    INSTANCE;

    @Override
    public int method_8025() {
        return 2_500;
    }

    @Override
    public float method_8027() {
        return 10.0F;
    }

    @Override
    public float method_8028() {
        return 4.0F;
    }

    @Override
    public int method_8024() {
        return 4;
    }

    @Override
    public int method_8026() {
        return 18;
    }

    @Override
    public class_1856 method_8023() {
        return class_1856.method_8091(ModItems.TITANIUM_INGOT);
    }
}
