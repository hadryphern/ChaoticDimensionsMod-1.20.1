package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.block.AuroraGrassBlock;
import net.fabricmc.fabric.api.registry.CompostingChanceRegistry;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2397;
import net.minecraft.class_2431;
import net.minecraft.class_2465;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_6019;
import net.minecraft.class_7923;

/** Blocks exclusive to the high-altitude Pastel Aurora Skylands. */
public final class ModBlocks {
    public static final class_2248 PASTEL_SOIL = register("pastel_soil", new class_2248(class_4970.class_2251.method_9630(class_2246.field_10566)
        .method_31710(class_3620.field_16022).method_9626(class_2498.field_11529).method_26235((state, level, pos, type) -> false)));
    public static final class_2248 PASTEL_GRASS = register("pastel_grass", new AuroraGrassBlock(class_4970.class_2251.method_9630(class_2246.field_10219)
        .method_31710(class_3620.field_16030).method_9626(class_2498.field_11535).method_26235((state, level, pos, type) -> false)));
    public static final class_2248 PASTEL_AURORA_STONE = register("pastel_aurora_stone", new class_2248(class_4970.class_2251.method_9630(class_2246.field_10340)
        .method_31710(class_3620.field_16025).method_29292().method_26235((state, level, pos, type) -> false)));
    public static final class_2248 PASTEL_AURORA_LOG = register("pastel_aurora_log", new class_2465(class_4970.class_2251.method_9630(class_2246.field_10431)
        .method_31710(class_3620.field_16030)));
    public static final class_2248 PASTEL_AURORA_WOOD = register("pastel_aurora_wood", new class_2465(class_4970.class_2251.method_9630(class_2246.field_10126)
        .method_31710(class_3620.field_16030)));
    public static final class_2248 STRIPPED_PASTEL_AURORA_LOG = register("stripped_pastel_aurora_log", new class_2465(
        class_4970.class_2251.method_9630(class_2246.field_10519).method_31710(class_3620.field_16030)));
    public static final class_2248 STRIPPED_PASTEL_AURORA_WOOD = register("stripped_pastel_aurora_wood", new class_2465(
        class_4970.class_2251.method_9630(class_2246.field_10250).method_31710(class_3620.field_16030)));
    public static final class_2248 PASTEL_AURORA_PLANKS = register("pastel_aurora_planks", new class_2248(class_4970.class_2251.method_9630(class_2246.field_10161)
        .method_31710(class_3620.field_16030)));
    public static final class_2248 PASTEL_PINK_LEAVES = register("pastel_pink_leaves", leaves(class_3620.field_16030));
    public static final class_2248 PASTEL_PURPLE_LEAVES = register("pastel_purple_leaves", leaves(class_3620.field_16014));
    public static final class_2248 PASTEL_BLUE_LEAVES = register("pastel_blue_leaves", leaves(class_3620.field_16024));
    public static final class_2248 SAPPHIRE_ORE = register("sapphire_ore", new class_2431(class_4970.class_2251.method_9630(class_2246.field_10442)
        .method_31710(class_3620.field_16025).method_29292().method_26235((state, level, pos, type) -> false), class_6019.method_35017(3, 7)));
    public static final class_2248 ROSALITA_ORE = register("rosalita_ore", new class_2431(class_4970.class_2251.method_9630(class_2246.field_10013)
        .method_31710(class_3620.field_16025).method_29292().method_26235((state, level, pos, type) -> false), class_6019.method_35017(3, 7)));

    private ModBlocks() {
    }

    private static class_2397 leaves(class_3620 color) {
        return new class_2397(class_4970.class_2251.method_9630(class_2246.field_10503).method_31710(color));
    }

    private static class_2248 register(String id, class_2248 block) {
        class_2960 key = new class_2960(ChaoticDimensions.MOD_ID, id);
        class_2378.method_10230(class_7923.field_41175, key, block);
        class_2378.method_10230(class_7923.field_41178, key, new class_1747(block, new class_1792.class_1793()));
        return block;
    }

    public static void initialize() {
        StrippableBlockRegistry.register(PASTEL_AURORA_LOG, STRIPPED_PASTEL_AURORA_LOG);
        StrippableBlockRegistry.register(PASTEL_AURORA_WOOD, STRIPPED_PASTEL_AURORA_WOOD);

        FlammableBlockRegistry flammables = FlammableBlockRegistry.getDefaultInstance();
        flammables.add(PASTEL_AURORA_LOG, 5, 5);
        flammables.add(PASTEL_AURORA_WOOD, 5, 5);
        flammables.add(STRIPPED_PASTEL_AURORA_LOG, 5, 5);
        flammables.add(STRIPPED_PASTEL_AURORA_WOOD, 5, 5);
        flammables.add(PASTEL_AURORA_PLANKS, 5, 20);
        flammables.add(PASTEL_PINK_LEAVES, 30, 60);
        flammables.add(PASTEL_PURPLE_LEAVES, 30, 60);
        flammables.add(PASTEL_BLUE_LEAVES, 30, 60);

        CompostingChanceRegistry.INSTANCE.add(PASTEL_PINK_LEAVES, 0.3F);
        CompostingChanceRegistry.INSTANCE.add(PASTEL_PURPLE_LEAVES, 0.3F);
        CompostingChanceRegistry.INSTANCE.add(PASTEL_BLUE_LEAVES, 0.3F);
    }

}
