package net.blue.chaoticd.content;

import net.blue.chaoticd.ChaoticDimensions;
import net.blue.chaoticd.content.block.AuroraGrassBlock;
import net.blue.chaoticd.content.block.CrystalFurnaceBlock;
import net.blue.chaoticd.content.block.DreamFluidBlock;
import net.blue.chaoticd.content.block.ShadowGrassBlock;
import net.fabricmc.fabric.api.registry.CompostingChanceRegistry;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2304;
import net.minecraft.class_2356;
import net.minecraft.class_2378;
import net.minecraft.class_2397;
import net.minecraft.class_2431;
import net.minecraft.class_2465;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_6019;
import net.minecraft.class_7923;

/** Blocks belonging to the Aurora and Shadow dimensions. */
public final class ModBlocks {
    public static final class_2248 PASTEL_SOIL = register(
        "pastel_soil",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10566)
            .method_31710(class_3620.field_16022)
            .method_9626(class_2498.field_11529)
            .method_26235((state, level, pos, type) -> false))
    );

    public static final class_2248 PASTEL_GRASS = register(
        "pastel_grass",
        new AuroraGrassBlock(class_4970.class_2251.method_9630(class_2246.field_10219)
            .method_31710(class_3620.field_16030)
            .method_9626(class_2498.field_11535)
            .method_26235((state, level, pos, type) -> false))
    );

    public static final class_2248 PASTEL_AURORA_STONE = register(
        "pastel_aurora_stone",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10340)
            .method_31710(class_3620.field_16025)
            .method_29292()
            .method_26235((state, level, pos, type) -> false))
    );

    public static final class_2248 PASTEL_AURORA_LOG = register(
        "pastel_aurora_log",
        new class_2465(class_4970.class_2251.method_9630(class_2246.field_10431)
            .method_31710(class_3620.field_16030))
    );

    public static final class_2248 PASTEL_AURORA_WOOD = register(
        "pastel_aurora_wood",
        new class_2465(class_4970.class_2251.method_9630(class_2246.field_10126)
            .method_31710(class_3620.field_16030))
    );

    public static final class_2248 STRIPPED_PASTEL_AURORA_LOG = register(
        "stripped_pastel_aurora_log",
        new class_2465(class_4970.class_2251.method_9630(class_2246.field_10519)
            .method_31710(class_3620.field_16030))
    );

    public static final class_2248 STRIPPED_PASTEL_AURORA_WOOD = register(
        "stripped_pastel_aurora_wood",
        new class_2465(class_4970.class_2251.method_9630(class_2246.field_10250)
            .method_31710(class_3620.field_16030))
    );

    public static final class_2248 PASTEL_AURORA_PLANKS = register(
        "pastel_aurora_planks",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10161)
            .method_31710(class_3620.field_16030))
    );

    public static final class_2248 PASTEL_PINK_LEAVES = register(
        "pastel_pink_leaves",
        leaves(class_3620.field_16030)
    );

    public static final class_2248 PASTEL_PURPLE_LEAVES = register(
        "pastel_purple_leaves",
        leaves(class_3620.field_16014)
    );

    public static final class_2248 PASTEL_BLUE_LEAVES = register(
        "pastel_blue_leaves",
        leaves(class_3620.field_16024)
    );

    public static final class_2248 SAPPHIRE_ORE = register(
        "sapphire_ore",
        new class_2431(
            class_4970.class_2251.method_9630(class_2246.field_10442)
                .method_31710(class_3620.field_16025)
                .method_29292()
                .method_26235((state, level, pos, type) -> false),
            class_6019.method_35017(3, 7)
        )
    );

    public static final class_2248 ROSALITA_ORE = register(
        "rosalita_ore",
        new class_2431(
            class_4970.class_2251.method_9630(class_2246.field_10013)
                .method_31710(class_3620.field_16025)
                .method_29292()
                .method_26235((state, level, pos, type) -> false),
            class_6019.method_35017(3, 7)
        )
    );

    public static final class_2248 SHADOW_SOIL = register(
        "shadow_soil",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10566)
            .method_31710(class_3620.field_16009)
            .method_9626(class_2498.field_11529)
            .method_26235((state, level, pos, type) -> false))
    );

    public static final class_2248 SHADOW_GRASS = register(
        "shadow_grass",
        new ShadowGrassBlock(class_4970.class_2251.method_9630(class_2246.field_10219)
            .method_31710(class_3620.field_16009)
            .method_9626(class_2498.field_11535)
            .method_26235((state, level, pos, type) -> false))
    );

    public static final class_2248 SHADOW_STONE = register(
        "shadow_stone",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_28888)
            .method_31710(class_3620.field_16009)
            .method_29292()
            .method_26235((state, level, pos, type) -> false))
    );

    public static final class_2248 SHADOW_LOG = register(
        "shadow_log",
        new class_2465(class_4970.class_2251.method_9630(class_2246.field_10010)
            .method_31710(class_3620.field_16009))
    );

    public static final class_2248 SHADOW_WOOD = register(
        "shadow_wood",
        new class_2465(class_4970.class_2251.method_9630(class_2246.field_10178)
            .method_31710(class_3620.field_16009))
    );

    public static final class_2248 STRIPPED_SHADOW_LOG = register(
        "stripped_shadow_log",
        new class_2465(class_4970.class_2251.method_9630(class_2246.field_10244)
            .method_31710(class_3620.field_16009))
    );

    public static final class_2248 STRIPPED_SHADOW_WOOD = register(
        "stripped_shadow_wood",
        new class_2465(class_4970.class_2251.method_9630(class_2246.field_10374)
            .method_31710(class_3620.field_16009))
    );

    public static final class_2248 SHADOW_PLANKS = register(
        "shadow_planks",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10075)
            .method_31710(class_3620.field_16009))
    );

    public static final class_2248 SHADOW_LEAVES = register(
        "shadow_leaves",
        leaves(class_3620.field_16009)
    );



    public static final class_2248 RUBY_ORE = register(
        "ruby_ore",
        new class_2431(
            class_4970.class_2251.method_9630(class_2246.field_10442)
                .method_31710(class_3620.field_16020)
                .method_29292(),
            class_6019.method_35017(7, 12)
        )
    );

    public static final class_2248 RUBY_BLOCK = register(
        "ruby_block",
        new class_2248(
            class_4970.class_2251.method_9630(class_2246.field_10201)
                .method_31710(class_3620.field_16020)
                .method_29292()
        )
    );

    public static final class_2248 TITANIUM_ORE = register(
        "titanium_ore",
        new class_2431(
            class_4970.class_2251.method_9630(class_2246.field_10212)
                .method_31710(class_3620.field_16005)
                .method_29292(),
            class_6019.method_35017(2, 5)
        )
    );

    public static final class_2248 TITANIUM_BLOCK = register(
        "titanium_block",
        new class_2248(
            class_4970.class_2251.method_9630(class_2246.field_10085)
                .method_31710(class_3620.field_16005)
                .method_29292()
        )
    );

    public static final class_2248 CRYSTAL_DIRT = register(
        "crystal_dirt",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10566).method_31710(class_3620.field_16014))
    );

    public static final class_2248 CRYSTAL_GRASS_BLOCK = register(
        "crystal_grass_block",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10219).method_31710(class_3620.field_16014))
    );

    public static final class_2248 CRYSTAL_LOG = register(
        "crystal_log",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10431).method_31710(class_3620.field_16014))
    );

    public static final class_2248 CRYSTAL_PLANKS = register(
        "crystal_planks",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10161).method_31710(class_3620.field_16014))
    );

    public static final class_2248 CRYSTAL_LEAVES_1 = register(
        "crystal_leaves_1",
        leaves(class_3620.field_16014)
    );

    public static final class_2248 CRYSTAL_LEAVES_2 = register(
        "crystal_leaves_2",
        leaves(class_3620.field_16024)
    );

    public static final class_2248 CRYSTAL_LEAVES_3 = register(
        "crystal_leaves_3",
        leaves(class_3620.field_16030)
    );

    public static final class_2248 CRYSTAL_RED_PLANT = register(
        "crystal_red_plant",
        crystalFlower(class_3620.field_16020)
    );

    public static final class_2248 CRYSTAL_YELLOW_PLANT = register(
        "crystal_yellow_plant",
        crystalFlower(class_3620.field_16010)
    );

    public static final class_2248 CRYSTAL_BLUE_PLANT = register(
        "crystal_blue_plant",
        crystalFlower(class_3620.field_16024)
    );

    public static final class_2248 CRYSTAL_GREEN_PLANT = register(
        "crystal_green_plant",
        crystalFlower(class_3620.field_15995)
    );

    public static final class_2248 CRYSTAL_FURNACE = register(
        "crystal_furnace",
        new CrystalFurnaceBlock(class_4970.class_2251.method_9630(class_2246.field_10181))
    );

    public static final class_2248 CRYSTAL_CRAFTING_TABLE = register(
        "crystal_crafting_table",
        new class_2304(class_4970.class_2251.method_9630(class_2246.field_9980))
    );

    public static final class_2248 DREAM_FLUID = registerBlockOnly(
        "dream_fluid",
        new DreamFluidBlock(
            ModFluids.DREAM_FLUID,
            class_4970.class_2251.method_9630(class_2246.field_10164)
                .method_9631(state -> 12)
        )
    );

    private ModBlocks() {
    }

    private static class_2356 crystalFlower(class_3620 color) {
        return new class_2356(
            class_1294.field_5912,
            5,
            class_4970.class_2251.method_9630(class_2246.field_10182).method_31710(color)
        );
    }

    private static class_2397 leaves(class_3620 color) {
        return new class_2397(class_4970.class_2251.method_9630(class_2246.field_10503).method_31710(color));
    }

    private static class_2248 register(String id, class_2248 block) {
        class_2960 key = new class_2960(ChaoticDimensions.MOD_ID, id);
        class_2378.method_10230(class_7923.field_41175, key, block);
        class_2378.method_10230(class_7923.field_41178, key, new class_1747(block, new class_1792.class_1793()));
        return block;
    }

    private static class_2248 registerBlockOnly(String id, class_2248 block) {
        class_2960 key = new class_2960(ChaoticDimensions.MOD_ID, id);
        return class_2378.method_10230(class_7923.field_41175, key, block);
    }

    public static void initialize() {
        StrippableBlockRegistry.register(PASTEL_AURORA_LOG, STRIPPED_PASTEL_AURORA_LOG);
        StrippableBlockRegistry.register(PASTEL_AURORA_WOOD, STRIPPED_PASTEL_AURORA_WOOD);
        StrippableBlockRegistry.register(SHADOW_LOG, STRIPPED_SHADOW_LOG);
        StrippableBlockRegistry.register(SHADOW_WOOD, STRIPPED_SHADOW_WOOD);

        FlammableBlockRegistry flammables = FlammableBlockRegistry.getDefaultInstance();

        flammables.add(PASTEL_AURORA_LOG, 5, 5);
        flammables.add(PASTEL_AURORA_WOOD, 5, 5);
        flammables.add(STRIPPED_PASTEL_AURORA_LOG, 5, 5);
        flammables.add(STRIPPED_PASTEL_AURORA_WOOD, 5, 5);
        flammables.add(PASTEL_AURORA_PLANKS, 5, 20);
        flammables.add(PASTEL_PINK_LEAVES, 30, 60);
        flammables.add(PASTEL_PURPLE_LEAVES, 30, 60);
        flammables.add(PASTEL_BLUE_LEAVES, 30, 60);

        flammables.add(SHADOW_LOG, 5, 5);
        flammables.add(SHADOW_WOOD, 5, 5);
        flammables.add(STRIPPED_SHADOW_LOG, 5, 5);
        flammables.add(STRIPPED_SHADOW_WOOD, 5, 5);
        flammables.add(SHADOW_PLANKS, 5, 20);
        flammables.add(SHADOW_LEAVES, 30, 60);

        flammables.add(CRYSTAL_LOG, 5, 5);
        flammables.add(CRYSTAL_PLANKS, 5, 20);
        flammables.add(CRYSTAL_LEAVES_1, 30, 60);
        flammables.add(CRYSTAL_LEAVES_2, 30, 60);
        flammables.add(CRYSTAL_LEAVES_3, 30, 60);

        CompostingChanceRegistry.INSTANCE.add(PASTEL_PINK_LEAVES, 0.3F);
        CompostingChanceRegistry.INSTANCE.add(PASTEL_PURPLE_LEAVES, 0.3F);
        CompostingChanceRegistry.INSTANCE.add(PASTEL_BLUE_LEAVES, 0.3F);
        CompostingChanceRegistry.INSTANCE.add(CRYSTAL_LEAVES_1, 0.3F);
        CompostingChanceRegistry.INSTANCE.add(CRYSTAL_LEAVES_2, 0.3F);
        CompostingChanceRegistry.INSTANCE.add(CRYSTAL_LEAVES_3, 0.3F);
        CompostingChanceRegistry.INSTANCE.add(CRYSTAL_RED_PLANT, 0.65F);
        CompostingChanceRegistry.INSTANCE.add(CRYSTAL_YELLOW_PLANT, 0.65F);
        CompostingChanceRegistry.INSTANCE.add(CRYSTAL_BLUE_PLANT, 0.65F);
        CompostingChanceRegistry.INSTANCE.add(CRYSTAL_GREEN_PLANT, 0.65F);
    }
}
